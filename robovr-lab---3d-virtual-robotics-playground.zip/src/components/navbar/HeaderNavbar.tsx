import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Square,
  RotateCcw,
  Gauge,
  Layers,
  Code2,
  Boxes,
  Compass,
  Trophy,
  HelpCircle,
  Maximize2,
  Minimize2,
  Columns,
  Monitor,
  Cpu,
  Sparkles,
  Volume2,
  VolumeX,
  BookOpen,
  FolderDown,
  Palette,
} from 'lucide-react';
import { ArenaType, ExecutionState, SimulationSpeed } from '../../types/robot';
import { ARENAS } from '../../services/arenas/arenaData';
import { AppThemeId, APP_THEMES } from '../../types/theme';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { soundEffects } from '../../services/audio/soundEffects';

export type MobilePaneView = 'split' | 'code' | '3d';

interface HeaderNavbarProps {
  executionState: ExecutionState;
  onRun: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  onReset: () => void;
  speed: SimulationSpeed;
  onSpeedChange: (speed: SimulationSpeed) => void;
  currentArena: ArenaType;
  onArenaChange: (arena: ArenaType) => void;
  activeLanguage: 'block' | 'python';
  onLanguageChange: (lang: 'block' | 'python') => void;
  selectedMissionId?: string;
  onSelectMission: (missionId: string) => void;
  onOpenHelp: () => void;
  onOpenMissions: () => void;
  onOpenArduino: () => void;
  onOpenCustomizer: () => void;
  onOpenAdventure: () => void;
  onOpenProjectStorage: () => void;
  currentTheme: AppThemeId;
  onOpenThemeSelector: () => void;
  isSerialConnected?: boolean;
  mobilePane: MobilePaneView;
  onMobilePaneChange: (pane: MobilePaneView) => void;
}

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  executionState,
  onRun,
  onPause,
  onResume,
  onStop,
  onReset,
  speed,
  onSpeedChange,
  currentArena,
  onArenaChange,
  activeLanguage,
  onLanguageChange,
  selectedMissionId,
  onSelectMission,
  onOpenHelp,
  onOpenMissions,
  onOpenArduino,
  onOpenCustomizer,
  onOpenAdventure,
  onOpenProjectStorage,
  currentTheme,
  onOpenThemeSelector,
  isSerialConnected = false,
  mobilePane,
  onMobilePaneChange,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(() => soundEffects.isMuted());
  const themeConfig = APP_THEMES[currentTheme] || APP_THEMES.cyber;

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    soundEffects.playUiClick();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleToggleSound = () => {
    const newMuted = soundEffects.toggleMute();
    setIsMuted(newMuted);
  };

  return (
    <header className={`w-full ${themeConfig.colors.headerBg} border-b ${themeConfig.colors.headerBorder} text-slate-100 px-3 py-2 flex flex-col gap-2 shadow-lg select-none transition-colors duration-300`}>
      {/* Top Main Row */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Brand & Mission Badge */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg bg-gradient-to-tr ${themeConfig.colors.primaryGradient} flex items-center justify-center shadow-md text-white font-black text-sm tracking-tighter`}>
              VR
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white leading-tight flex items-center gap-1.5">
                RoboVR Lab
                <span className={`text-[10px] font-medium px-1.5 py-0.2 rounded ${themeConfig.colors.accentPill}`}>
                  STEM 3D
                </span>
              </h1>
              <p className="text-[10px] text-slate-300 flex items-center gap-1.5 leading-tight mt-0.5">
                <span className="text-slate-400 hidden lg:inline">Robotika STEM 3D •</span>
                <span className="text-amber-300 font-semibold">Dibuat oleh Nugroho Aji</span>
              </p>
            </div>
          </div>

          {/* Petualangan Robo (SD Story Tutorial) Button */}
          <button
            onClick={() => {
              soundEffects.playUiClick();
              onOpenAdventure();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold shadow-sm transition-all cursor-pointer active:scale-95"
            title="Petualangan Robo (Cerita Bergambar & Tutorial Interaktif SD)"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Petualangan Robo</span>
            <span className="sm:hidden">Cerita SD</span>
            <span className="px-1 py-0.2 rounded text-[9px] bg-amber-400/20 text-amber-200 border border-amber-400/30 hidden xl:inline">
              SD
            </span>
          </button>

          {/* Missions quick button */}
          <button
            onClick={onOpenMissions}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-medium transition-colors cursor-pointer"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Misi STEM</span>
          </button>

          {/* Robot Customizer button */}
          <button
            onClick={onOpenCustomizer}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-950/70 to-blue-950/70 hover:from-cyan-900 hover:to-blue-900 text-cyan-300 border border-cyan-500/40 text-xs font-semibold shadow-sm transition-all cursor-pointer active:scale-95"
            title="Kustomisasi Karakter Robot 3D (Warna, Bodi, Lampu Neon)"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Kustom Robot</span>
            <span className="sm:hidden">Robot</span>
          </button>
        </div>


        {/* Center: Execution Controls */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          {executionState === 'running' ? (
            <button
              onClick={onPause}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95"
              title="Jeda Simulasi"
            >
              <Pause className="w-3.5 h-3.5 fill-current" />
              <span>Jeda</span>
            </button>
          ) : executionState === 'paused' ? (
            <button
              onClick={onResume}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95"
              title="Lanjutkan Simulasi"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Lanjut</span>
            </button>
          ) : (
            <button
              onClick={onRun}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs shadow-md shadow-emerald-900/40 transition-all cursor-pointer active:scale-95"
              title="Jalankan Program Robot"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Jalankan</span>
            </button>
          )}

          <button
            onClick={onStop}
            disabled={executionState === 'idle' || executionState === 'completed'}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              executionState === 'running' || executionState === 'paused'
                ? 'bg-rose-600 hover:bg-rose-500 text-white cursor-pointer active:scale-95'
                : 'text-slate-600 cursor-not-allowed'
            }`}
            title="Berhenti Seketika"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">Stop</span>
          </button>

          <button
            onClick={onReset}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            title="Reset Posisi Robot & Hapus Jejak"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>

          {/* Speed Selector */}
          <div className="flex items-center pl-1 border-l border-slate-800 text-xs">
            <Gauge className="w-3.5 h-3.5 text-slate-400 ml-1 mr-1 hidden sm:block" />
            <div className="flex bg-slate-900 rounded-lg p-0.5">
              {([1, 2, 5, 10] as SimulationSpeed[]).map((s) => (
                <button
                  key={s}
                  onClick={() => onSpeedChange(s)}
                  className={`px-1.5 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                    speed === s ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Section: Selectors, Language, PWA & Fullscreen */}
        <div className="flex items-center gap-2">
          {/* Arena Selector */}
          <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800 text-xs">
            <Layers className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <select
              value={currentArena}
              onChange={(e) => onArenaChange(e.target.value as ArenaType)}
              className="bg-transparent text-slate-200 text-xs font-medium outline-none cursor-pointer pr-1 max-w-[120px] sm:max-w-none"
            >
              {Object.values(ARENAS).map((arena) => (
                <option key={arena.id} value={arena.id} className="bg-slate-900 text-slate-200">
                  {arena.name}
                </option>
              ))}
            </select>
          </div>

          {/* Language Switch: Block vs Python */}
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => onLanguageChange('block')}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeLanguage === 'block'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Boxes className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Blok</span>
            </button>
            <button
              onClick={() => onLanguageChange('python')}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeLanguage === 'python'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Python</span>
            </button>
          </div>

          {/* Save / Load Project to Disk Button */}
          <button
            onClick={() => {
              soundEffects.playUiClick();
              onOpenProjectStorage();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-950/50 hover:bg-indigo-900/60 text-indigo-300 border border-indigo-500/40 text-xs font-semibold shadow-sm transition-all cursor-pointer active:scale-95"
            title="Simpan Proyek ke Komputer (.robovr) atau Buka File Tugas Siswa"
          >
            <FolderDown className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Simpan / Buka Proyek</span>
            <span className="sm:hidden">File</span>
          </button>

          {/* Arduino Hardware Hub Button */}
          <button
            onClick={onOpenArduino}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              isSerialConnected
                ? 'bg-teal-950/60 border-teal-500/60 text-teal-300 shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-teal-300 border-teal-500/30'
            }`}
            title="Ekspor Kode Arduino & Driver L298N / L293D"
          >
            <Cpu className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">Arduino (L298N/L293D)</span>
            <span className="sm:hidden">Arduino</span>
            {isSerialConnected && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse ml-0.5" title="USB Serial Terhubung" />
            )}
          </button>

          {/* PWA Cross-Platform Install Button */}
          <PWAInstallButton />

          {/* Theme Selector Button */}
          <button
            onClick={() => {
              soundEffects.playUiClick();
              onOpenThemeSelector();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-pink-950/40 hover:bg-pink-900/50 text-pink-300 border border-pink-500/30 text-xs font-semibold shadow-sm transition-all cursor-pointer active:scale-95"
            title="Pilih Tema Tampilan (Fresh & Ceria untuk Anak-Anak)"
          >
            <Palette className="w-3.5 h-3.5 text-pink-400" />
            <span className="hidden sm:inline">Tema</span>
            <span className="text-xs hidden xl:inline">{themeConfig.iconEmoji}</span>
          </button>

          {/* Sound Effects SFX Toggle */}
          <button
            onClick={handleToggleSound}
            className={`flex items-center gap-1.5 p-1.5 rounded-lg border transition-all cursor-pointer ${
              isMuted
                ? 'bg-rose-950/40 border-rose-500/40 text-rose-300 hover:bg-rose-900/50'
                : 'bg-slate-800 hover:bg-slate-700 text-blue-300 border-blue-500/30 shadow-sm'
            }`}
            title={isMuted ? 'Suara Robot / SFX: Senyap (Bisu) — Klik untuk Aktifkan' : 'Suara Robot / SFX: Aktif — Klik untuk Bisu'}
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-blue-400" />
            )}
            <span className="text-[11px] font-semibold hidden xl:inline">
              {isMuted ? 'SFX Bisu' : 'SFX Aktif'}
            </span>
          </button>

          {/* Fullscreen Toggle (great for mobile, tablets, Chromebooks) */}
          <button
            onClick={toggleFullscreen}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
            title={isFullscreen ? 'Keluar Layar Penuh' : 'Layar Penuh (Fullscreen)'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Help Button */}
          <button
            onClick={() => {
              soundEffects.playUiClick();
              onOpenHelp();
            }}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Panduan Robotika & API Referensi"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile / Tablet Screen Mode Switcher (visible on smaller screens) */}
      <div className="flex md:hidden items-center justify-between pt-1 border-t border-slate-800/80 text-xs">
        <span className="text-[11px] text-slate-400 font-medium">Tampilan Perangkat:</span>
        <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800">
          <button
            onClick={() => onMobilePaneChange('code')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
              mobilePane === 'code' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Editor Kode
          </button>
          <button
            onClick={() => onMobilePaneChange('split')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
              mobilePane === 'split' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Split (50:50)
          </button>
          <button
            onClick={() => onMobilePaneChange('3d')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
              mobilePane === '3d' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Arena 3D
          </button>
        </div>
      </div>
    </header>
  );
};
