import React, { useState } from 'react';
import {
  Camera,
  Compass,
  Eye,
  PenTool,
  Radio,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Box,
  Layers,
  Crosshair,
  AlertTriangle,
} from 'lucide-react';
import { CameraViewMode, RobotTelemetry } from '../../types/robot';
import { soundEffects } from '../../services/audio/soundEffects';

interface RobotHUDProps {
  telemetry: RobotTelemetry;
  viewMode: CameraViewMode;
  onViewModeChange: (mode: CameraViewMode) => void;
  onClearTrails: () => void;
}

export const RobotHUD: React.FC<RobotHUDProps> = ({
  telemetry,
  viewMode,
  onViewModeChange,
  onClearTrails,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Compass cardinal direction
  const getCardinal = (heading: number) => {
    const norm = ((heading % 360) + 360) % 360;
    if (norm >= 315 || norm < 45) return 'Utara (N)';
    if (norm >= 45 && norm < 135) return 'Timur (E)';
    if (norm >= 135 && norm < 225) return 'Selatan (S)';
    return 'Barat (W)';
  };

  const isNearObstacle = telemetry.distanceMm < 250;
  const distanceCm = Math.round(telemetry.distanceMm / 10);

  return (
    <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-20 w-[96%] max-w-5xl transition-all duration-300 pointer-events-auto">
      {/* Collapse / Expand Toggle Button */}
      <div className="flex justify-center mb-1.5">
        <button
          onClick={() => {
            soundEffects.playUiClick();
            setIsCollapsed(!isCollapsed);
          }}
          className="group flex items-center gap-1.5 px-3 py-1 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-medium rounded-full shadow-lg border border-slate-700/80 transition-all cursor-pointer backdrop-blur-md active:scale-95"
          title={isCollapsed ? 'Tampilkan panel instrumen robot' : 'Sembunyikan instrumen agar arena lebih lega'}
        >
          {isCollapsed ? (
            <>
              <ChevronUp className="w-3.5 h-3.5 text-blue-400 group-hover:-translate-y-0.5 transition-transform" />
              <span>Tampilkan Telemetri & Kamera</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:translate-y-0.5 transition-transform" />
              <span>Sembunyikan Telemetri</span>
            </>
          )}
        </button>
      </div>

      {!isCollapsed && (
        <div className="bg-slate-950/90 backdrop-blur-md border border-slate-800/90 rounded-2xl p-2.5 sm:p-3 shadow-2xl text-slate-200">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-2.5">
            {/* 1. Camera View Mode Switcher */}
            <div className="flex items-center justify-between sm:justify-start gap-1.5 bg-slate-900/90 px-2 py-1.5 rounded-xl border border-slate-800/80 shrink-0">
              <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5 pr-1">
                <Camera className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="hidden sm:inline">Kamera:</span>
              </span>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    soundEffects.playCameraSwitch();
                    onViewModeChange('orbit');
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    viewMode === 'orbit'
                      ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400/50'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                  title="Sudut Pandang 3D Bebas (Orbit)"
                >
                  <Box className="w-3.5 h-3.5 shrink-0" />
                  <span>3D Orbit</span>
                </button>

                <button
                  onClick={() => {
                    soundEffects.playCameraSwitch();
                    onViewModeChange('top');
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    viewMode === 'top'
                      ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400/50'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                  title="Tampak Atas 2D (Top-down plan view)"
                >
                  <Layers className="w-3.5 h-3.5 shrink-0" />
                  <span>Atas (2D)</span>
                </button>

                <button
                  onClick={() => {
                    soundEffects.playCameraSwitch();
                    onViewModeChange('chase');
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    viewMode === 'chase'
                      ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400/50'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                  title="Kamera Ikuti Robot (Chase Cam)"
                >
                  <Crosshair className="w-3.5 h-3.5 shrink-0" />
                  <span>Ikuti</span>
                </button>
              </div>
            </div>

            {/* 2. Telemetry Cards (Horizontal Scrollable Strip on small viewports, balanced flex row on desktop) */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 lg:pb-0 scrollbar-thin scrollbar-thumb-slate-700/60">
              {/* Gyro / Heading Card */}
              <div className="bg-slate-900/85 hover:bg-slate-900 border border-slate-800/80 rounded-xl p-2 sm:px-2.5 sm:py-2 flex items-center gap-2 shrink-0 min-w-[125px] transition-colors">
                <div className="p-1.5 bg-blue-500/15 text-blue-400 rounded-lg shrink-0 border border-blue-500/20">
                  <Compass className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Heading</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="font-mono text-xs sm:text-sm font-bold text-white">
                      {telemetry.pose.heading.toFixed(0)}°
                    </span>
                    <span className="text-[9px] font-medium text-cyan-300 bg-cyan-950/70 border border-cyan-800/50 px-1 py-0.2 rounded truncate">
                      {getCardinal(telemetry.pose.heading)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Distance Sensor (Ultrasonic) */}
              <div
                className={`bg-slate-900/85 hover:bg-slate-900 border rounded-xl p-2 sm:px-2.5 sm:py-2 flex items-center gap-2 shrink-0 min-w-[135px] transition-colors ${
                  isNearObstacle ? 'border-rose-500/60 bg-rose-950/20' : 'border-slate-800/80'
                }`}
              >
                <div
                  className={`p-1.5 rounded-lg shrink-0 border transition-colors ${
                    isNearObstacle
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/30 animate-pulse'
                      : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20'
                  }`}
                >
                  <Radio className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Jarak</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="font-mono text-xs sm:text-sm font-bold text-white whitespace-nowrap">
                      {distanceCm} cm
                    </span>
                    {isNearObstacle ? (
                      <span className="text-[9px] font-bold text-rose-300 bg-rose-900/80 border border-rose-700/60 px-1 py-0.2 rounded uppercase animate-pulse">
                        Dekat!
                      </span>
                    ) : (
                      <span className="text-[9px] font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-1 py-0.2 rounded">
                        Aman
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Color Sensor */}
              <div className="bg-slate-900/85 hover:bg-slate-900 border border-slate-800/80 rounded-xl p-2 sm:px-2.5 sm:py-2 flex items-center gap-2 shrink-0 min-w-[125px] transition-colors">
                <div className="p-1.5 bg-indigo-500/15 text-indigo-400 rounded-lg shrink-0 border border-indigo-500/20">
                  <Eye className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Sensor Warna</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span
                      className="w-3 h-3 rounded-full border border-slate-500 shadow-sm shrink-0"
                      style={{ backgroundColor: telemetry.colorHex }}
                      title={`Kode Hex: ${telemetry.colorHex}`}
                    />
                    <span className="font-semibold text-white capitalize text-xs truncate">
                      {telemetry.detectedColor}
                    </span>
                  </div>
                </div>
              </div>

              {/* Pen Tool Status & Clear Action */}
              <div className="bg-slate-900/85 hover:bg-slate-900 border border-slate-800/80 rounded-xl p-2 sm:px-2.5 sm:py-2 flex items-center justify-between gap-2.5 shrink-0 min-w-[155px] transition-colors">
                <div className="flex items-center gap-2 min-w-0">
                  <div
                    className={`p-1.5 rounded-lg shrink-0 border ${
                      telemetry.penDown
                        ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700/60'
                    }`}
                  >
                    <PenTool className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Pena Robot</div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full inline-block shadow-sm shrink-0"
                        style={{ backgroundColor: telemetry.penColor }}
                      />
                      <span
                        className={`text-xs font-bold whitespace-nowrap ${
                          telemetry.penDown ? 'text-purple-300' : 'text-slate-400'
                        }`}
                      >
                        {telemetry.penDown ? 'TURUN' : 'NAIK'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Clear Trail Button */}
                <button
                  onClick={() => {
                    soundEffects.playUiClick();
                    onClearTrails();
                  }}
                  title="Hapus gambar jejak pena di lantai arena"
                  className="p-1.5 bg-slate-800/90 hover:bg-slate-700 active:bg-slate-600 text-slate-300 hover:text-white rounded-lg border border-slate-700/80 transition-all cursor-pointer active:scale-90 shrink-0 ml-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Collision Alert Badge if colliding */}
              {telemetry.isColliding && (
                <div className="bg-rose-950/80 border border-rose-500/80 rounded-xl px-2.5 py-1.5 flex items-center gap-1.5 text-rose-200 text-xs font-bold animate-bounce shrink-0">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>TABRAKAN!</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
