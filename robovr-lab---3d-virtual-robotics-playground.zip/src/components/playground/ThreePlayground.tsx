import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ArenaConfig, CameraViewMode, DEFAULT_ROBOT_CUSTOMIZATION, ExecutionState, PenTrailPoint, RobotCustomizationConfig, RobotTelemetry } from '../../types/robot';
import { ArenaSceneBuilder } from '../../services/three/arenaScene';
import { createRobot3DModel, Robot3DComponents } from '../../services/three/robotModel';
import { useResponsiveViewport3D } from '../../hooks/useResponsiveViewport3D';
import { soundEffects } from '../../services/audio/soundEffects';

interface ThreePlaygroundProps {
  arena: ArenaConfig;
  telemetry: RobotTelemetry;
  penTrails: PenTrailPoint[];
  executionState: ExecutionState;
  viewMode: CameraViewMode;
  onViewModeChange?: (mode: CameraViewMode) => void;
  customization?: RobotCustomizationConfig;
}

export const ThreePlayground: React.FC<ThreePlaygroundProps> = ({
  arena,
  telemetry,
  penTrails,
  executionState,
  viewMode,
  customization = DEFAULT_ROBOT_CUSTOMIZATION,
}) => {

  const mountRef = useRef<HTMLDivElement>(null);
  const viewport3D = useResponsiveViewport3D(mountRef);

  // Store persistent Three.js instances in refs to avoid recreating on props change
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const robotComponentsRef = useRef<Robot3DComponents | null>(null);
  const arenaBuilderRef = useRef<ArenaSceneBuilder | null>(null);

  const prevPoseRef = useRef({ x: telemetry.pose.x, y: telemetry.pose.y, heading: telemetry.pose.heading });
  const wheelAngleRef = useRef(0);
  const prevCollidingRef = useRef(false);

  // Setup Three.js scene once on mount
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a); // Deep modern slate
    scene.fog = new THREE.FogExp2(0x0f172a, 0.015);
    sceneRef.current = scene;

    // Camera with dynamic responsive initial FOV
    const initialFov = width / Math.max(height, 1) < 1.05 ? 60 : 45;
    const camera = new THREE.PerspectiveCamera(initialFov, width / height, 0.1, 120);
    camera.position.set(0, 24, 24);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI / 2 - 0.05; // Don't flip below floor
    controls.minDistance = 4;
    controls.maxDistance = 60;
    controlsRef.current = controls;

    // Studio Environment & Lighting
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Key Light
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
    keyLight.position.set(12, 22, 10);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 60;
      keyLight.shadow.camera.left = -16;
      keyLight.shadow.camera.right = 16;
      keyLight.shadow.camera.top = 16;
      keyLight.shadow.camera.bottom = -16;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    // Fill Light
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x1e293b, 1.2);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    // Build Arena
    const arenaBuilder = new ArenaSceneBuilder();
    arenaBuilder.buildArena(arena, renderer.capabilities.getMaxAnisotropy());
    scene.add(arenaBuilder.getGroup());
    arenaBuilderRef.current = arenaBuilder;

    // Build Robot 3D Model with Customization
    const robotComponents = createRobot3DModel(customization);
    scene.add(robotComponents.root);
    robotComponentsRef.current = robotComponents;

    // Position initial robot
    robotComponents.root.position.set(
      telemetry.pose.x / 100,
      0,
      -telemetry.pose.y / 100
    );
    robotComponents.root.rotation.y = -(telemetry.pose.heading * Math.PI) / 180;


    // Animation Loop
    let animationFrameId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      if (controlsRef.current) {
        controlsRef.current.update();
      }

      // Render
      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (rendererRef.current && container.contains(rendererRef.current.domElement)) {
        container.removeChild(rendererRef.current.domElement);
      }
      renderer.dispose();
    };
  }, []); // Run once on mount

  // Dynamically adjust Camera FOV, aspect ratio, projection matrix and renderer size based on responsive hook
  useEffect(() => {
    const camera = cameraRef.current;
    const renderer = rendererRef.current;
    if (!camera || !renderer) return;

    camera.fov = viewport3D.fov;
    camera.aspect = viewport3D.aspect;
    camera.updateProjectionMatrix();

    renderer.setSize(viewport3D.width, viewport3D.height);
  }, [viewport3D.fov, viewport3D.aspect, viewport3D.width, viewport3D.height]);

  // Dynamically adjust Robot scale based on responsive hook
  useEffect(() => {
    const robot = robotComponentsRef.current;
    if (!robot) return;
    const s = viewport3D.scaleMultiplier;
    robot.root.scale.set(s, s, s);
  }, [viewport3D.scaleMultiplier]);

  // Update arena when arena prop changes
  useEffect(() => {
    if (arenaBuilderRef.current && rendererRef.current) {
      arenaBuilderRef.current.buildArena(arena, rendererRef.current.capabilities.getMaxAnisotropy());
    }
  }, [arena]);

  // Re-create and update Robot model when customization changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (robotComponentsRef.current) {
      scene.remove(robotComponentsRef.current.root);
    }

    const newRobot = createRobot3DModel(customization);
    const s = viewport3D.scaleMultiplier;
    newRobot.root.scale.set(s, s, s);
    newRobot.root.position.set(telemetry.pose.x / 100, 0, -telemetry.pose.y / 100);
    newRobot.root.rotation.y = -(telemetry.pose.heading * Math.PI) / 180;
    scene.add(newRobot.root);
    robotComponentsRef.current = newRobot;
  }, [customization]);


  // Update pen trails in 3D scene
  useEffect(() => {
    if (arenaBuilderRef.current) {
      arenaBuilderRef.current.updatePenTrails(penTrails);
    }
  }, [penTrails]);

  // Update camera view mode using responsive distance factor
  useEffect(() => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    const robot = robotComponentsRef.current;
    if (!camera || !controls || !robot) return;

    const distFactor = viewport3D.cameraDistanceFactor;

    if (viewMode === 'top') {
      // Top-down bird's eye
      camera.position.set(0, 32 * distFactor, 0.001);
      controls.target.set(0, 0, 0);
      controls.update();
    } else if (viewMode === 'chase') {
      // Chase cam behind robot
      const rad = -(telemetry.pose.heading * Math.PI) / 180;
      const behindX = telemetry.pose.x / 100 - Math.sin(rad) * (6 * distFactor);
      const behindZ = -telemetry.pose.y / 100 - Math.cos(rad) * (6 * distFactor);
      camera.position.set(behindX, 4.5 * distFactor, behindZ);
      controls.target.set(telemetry.pose.x / 100, 0.5, -telemetry.pose.y / 100);
      controls.update();
    } else {
      // Orbit 3D perspective
      camera.position.set(0, 22 * distFactor, 22 * distFactor);
      controls.target.set(0, 0, 0);
      controls.update();
    }
  }, [viewMode, viewport3D.cameraDistanceFactor]);

  // Update Robot Pose & Articulations each telemetry change
  useEffect(() => {
    const robot = robotComponentsRef.current;
    if (!robot) return;

    // Target coordinates in 3D (1 unit = 100mm)
    const targetX = telemetry.pose.x / 100;
    const targetZ = -telemetry.pose.y / 100;
    const targetRotY = -(telemetry.pose.heading * Math.PI) / 180;

    // Calculate motion delta for wheel spinning
    const distMoved = Math.hypot(telemetry.pose.x - prevPoseRef.current.x, telemetry.pose.y - prevPoseRef.current.y);
    if (distMoved > 0.1) {
      wheelAngleRef.current += distMoved / 40;
      robot.leftWheel.rotation.x = wheelAngleRef.current;
      robot.rightWheel.rotation.x = wheelAngleRef.current;
    }

    prevPoseRef.current = {
      x: telemetry.pose.x,
      y: telemetry.pose.y,
      heading: telemetry.pose.heading,
    };

    robot.root.position.set(targetX, 0, targetZ);
    robot.root.rotation.y = targetRotY;

    // Chase Camera update during movement
    if (viewMode === 'chase' && cameraRef.current && controlsRef.current) {
      const rad = -(telemetry.pose.heading * Math.PI) / 180;
      const behindX = targetX - Math.sin(rad) * 6;
      const behindZ = targetZ - Math.cos(rad) * 6;
      cameraRef.current.position.set(behindX, 4.2, behindZ);
      controlsRef.current.target.set(targetX, 0.6, targetZ);
    }

    // Ultrasonic sensor beam visualizer
    if (robot.sensorBeam) {
      const beamDist = Math.max(0.5, Math.min(telemetry.distanceMm / 100, 15));
      robot.sensorBeam.scale.set(1, 1, beamDist / 2.5);
      // Warning color if obstacle close (< 25 cm)
      const mat = robot.sensorBeam.material as THREE.MeshBasicMaterial;
      if (telemetry.distanceMm < 250) {
        mat.color.setHex(0xef4444); // Red warning
        mat.opacity = 0.35;
      } else {
        mat.color.setHex(0x38bdf8); // Cyan normal
        mat.opacity = 0.18;
      }
    }

    // Pen Tool Up / Down mechanism
    if (robot.penMesh) {
      const marker = robot.penMesh.getObjectByName('penMarker') as THREE.Mesh;
      if (marker) {
        // Drop down flush with ground if penDown
        marker.position.y = telemetry.penDown ? -0.28 : -0.05;
        const markerMat = marker.material as THREE.MeshStandardMaterial;
        markerMat.color.set(telemetry.penColor);
      }
    }

    // Bottom Color Sensor lens glow
    if (robot.colorSensorLens) {
      const lensMat = robot.colorSensorLens.material as THREE.MeshBasicMaterial;
      lensMat.color.set(telemetry.colorHex);
    }

    // Status LED
    if (robot.statusLed) {
      const ledMat = robot.statusLed.material as THREE.MeshStandardMaterial;
      if (telemetry.isColliding) {
        ledMat.color.setHex(0xef4444);
        ledMat.emissive.setHex(0xef4444);
      } else if (executionState === 'running') {
        ledMat.color.setHex(0x22c55e);
        ledMat.emissive.setHex(0x22c55e);
      } else if (executionState === 'paused') {
        ledMat.color.setHex(0xf59e0b);
        ledMat.emissive.setHex(0xf59e0b);
      } else {
        ledMat.color.setHex(0x3b82f6);
        ledMat.emissive.setHex(0x3b82f6);
      }
    }

    // Audio collision feedback trigger on impact edge
    if (telemetry.isColliding && !prevCollidingRef.current) {
      soundEffects.playCollisionFeedback();
    }
    prevCollidingRef.current = telemetry.isColliding;
  }, [telemetry, executionState, viewMode]);

  // Ambient idle engine hum management in simulator lifecycle
  useEffect(() => {
    if (executionState === 'running') {
      soundEffects.stopIdleHum();
    } else {
      // Robot powered on in idle, paused, or stopped state
      soundEffects.startIdleHum();
    }

    return () => {
      soundEffects.stopIdleHum();
    };
  }, [executionState]);

  return (
    <div className="relative w-full h-full min-h-[300px] bg-slate-950 overflow-hidden select-none touch-none">
      {/* 3D WebGL Canvas Mount Container */}
      <div ref={mountRef} className="w-full h-full absolute inset-0 touch-none" />
    </div>
  );
};
