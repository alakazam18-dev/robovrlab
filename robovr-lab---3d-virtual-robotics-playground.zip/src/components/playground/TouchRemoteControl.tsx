import React, { useState } from 'react';
import {
  Gamepad2,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  RotateCw,
  Square,
  PenTool,
  X,
} from 'lucide-react';
import { RobotSimulationEngine } from '../../services/interpreter/asyncInterpreter';
import { RobotTelemetry } from '../../types/robot';
import { soundEffects } from '../../services/audio/soundEffects';

interface TouchRemoteControlProps {
  engine: RobotSimulationEngine | null;
  telemetry: RobotTelemetry;
}

export const TouchRemoteControl: React.FC<TouchRemoteControlProps> = ({ engine, telemetry }) => {
  const [isOpen, setIsOpen] = useState(false);

  if (!isOpen) {
    return (
      <button
        onClick={() => {
          soundEffects.playUiClick();
          setIsOpen(true);
        }}
        className="absolute top-3 right-3 z-30 flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-blue-400 hover:text-white border border-slate-700/80 shadow-lg text-xs font-medium cursor-pointer transition-all active:scale-95"
        title="Buka Remote Kontrol Manual (Touch / D-Pad)"
      >
        <Gamepad2 className="w-4 h-4 text-blue-400" />
        <span className="hidden sm:inline">Remote Manual</span>
      </button>
    );
  }

  const handleDrive = (dist: number) => {
    soundEffects.playMotorStep();
    if (!engine) return;
    if (dist > 0) engine.moveForward(dist);
    else engine.moveBackward(Math.abs(dist));
  };

  const handleTurn = (deg: number) => {
    soundEffects.playMotorStep();
    if (!engine) return;
    engine.turnAngle(deg);
  };

  const handleTogglePen = () => {
    soundEffects.playUiClick();
    if (!engine) return;
    engine.setPenDown(!telemetry.penDown);
  };

  const handleStop = () => {
    soundEffects.playUiClick();
    if (!engine) return;
    engine.stopRobot();
  };

  return (
    <div className="absolute top-3 right-3 z-30 bg-slate-900/95 border border-slate-700/90 rounded-2xl p-3 shadow-2xl text-slate-100 w-56 select-none animate-in fade-in zoom-in-95 duration-150">
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 font-bold text-white">
          <Gamepad2 className="w-4 h-4 text-blue-400" />
          <span>Remote D-Pad</span>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* D-Pad Buttons */}
      <div className="flex flex-col items-center gap-1.5 py-1">
        {/* Forward */}
        <button
          onClick={() => handleDrive(200)}
          className="w-12 h-11 bg-slate-800 hover:bg-blue-600 active:bg-blue-700 text-white rounded-xl flex items-center justify-center shadow transition-all cursor-pointer border border-slate-700 active:scale-95"
          title="Maju 20 cm"
        >
          <ChevronUp className="w-6 h-6" />
        </button>

        {/* Turn Left, Stop, Turn Right */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => handleTurn(-45)}
            className="w-12 h-11 bg-slate-800 hover:bg-blue-600 active:bg-blue-700 text-white rounded-xl flex items-center justify-center shadow transition-all cursor-pointer border border-slate-700 active:scale-95"
            title="Belok Kiri 45°"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          <button
            onClick={handleStop}
            className="w-12 h-11 bg-rose-600/80 hover:bg-rose-600 active:bg-rose-700 text-white rounded-xl flex items-center justify-center shadow transition-all cursor-pointer border border-rose-500/80 active:scale-95"
            title="Stop Motor"
          >
            <Square className="w-5 h-5 fill-current" />
          </button>
          <button
            onClick={() => handleTurn(45)}
            className="w-12 h-11 bg-slate-800 hover:bg-blue-600 active:bg-blue-700 text-white rounded-xl flex items-center justify-center shadow transition-all cursor-pointer border border-slate-700 active:scale-95"
            title="Belok Kanan 45°"
          >
            <RotateCw className="w-5 h-5" />
          </button>
        </div>

        {/* Backward */}
        <button
          onClick={() => handleDrive(-200)}
          className="w-12 h-11 bg-slate-800 hover:bg-blue-600 active:bg-blue-700 text-white rounded-xl flex items-center justify-center shadow transition-all cursor-pointer border border-slate-700 active:scale-95"
          title="Mundur 20 cm"
        >
          <ChevronDown className="w-6 h-6" />
        </button>
      </div>

      {/* Pen Toggle Action */}
      <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
        <span className="text-[11px] text-slate-400">Pena Gambar:</span>
        <button
          onClick={handleTogglePen}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
            telemetry.penDown
              ? 'bg-purple-600 text-white shadow'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <PenTool className="w-3.5 h-3.5" />
          <span>{telemetry.penDown ? 'TURUN' : 'NAIK'}</span>
        </button>
      </div>
    </div>
  );
};
