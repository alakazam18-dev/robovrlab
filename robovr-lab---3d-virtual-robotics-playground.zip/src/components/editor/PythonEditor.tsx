import React, { useState } from 'react';
import { Copy, Check, Sparkles, Code2, RefreshCw } from 'lucide-react';

interface PythonEditorProps {
  code: string;
  onChange: (newCode: string) => void;
  onSyncFromBlockly?: () => void;
  isReadOnly?: boolean;
}

export const PythonEditor: React.FC<PythonEditorProps> = ({
  code,
  onChange,
  onSyncFromBlockly,
  isReadOnly = false,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const insertSnippet = (snippet: string) => {
    onChange(code + (code.endsWith('\n') ? '' : '\n') + snippet + '\n');
  };

  const lineCount = code.split('\n').length;

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-900 text-slate-100 font-mono text-xs">
      {/* Top Helper Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-950 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-slate-200">main.py (Python VR Mode)</span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-sans font-medium">
            Async Interpreter Ready
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {onSyncFromBlockly && (
            <button
              onClick={onSyncFromBlockly}
              title="Sinkronkan ulang dari visual block"
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-sans transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Sync dari Blok</span>
            </button>
          )}

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-sans transition-colors cursor-pointer"
            title="Salin ke clipboard"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'Tersalin' : 'Salin'}</span>
          </button>
        </div>
      </div>

      {/* Quick Snippet Chips */}
      <div className="px-3 py-1.5 bg-slate-900 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[11px] font-sans">
        <span className="text-slate-400 text-[10px] flex items-center gap-1 shrink-0 font-medium">
          <Sparkles className="w-3 h-3 text-yellow-400" />
          Sisipkan:
        </span>
        <button
          onClick={() => insertSnippet('robot.move_forward(50, "cm")')}
          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded shrink-0 cursor-pointer font-mono text-[10px]"
        >
          move_forward(50, "cm")
        </button>
        <button
          onClick={() => insertSnippet('robot.turn_right(90)')}
          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded shrink-0 cursor-pointer font-mono text-[10px]"
        >
          turn_right(90)
        </button>
        <button
          onClick={() => insertSnippet('robot.pen_down()')}
          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-purple-300 rounded shrink-0 cursor-pointer font-mono text-[10px]"
        >
          pen_down()
        </button>
        <button
          onClick={() => insertSnippet('if robot.get_distance() < 25:\n    robot.turn_right(90)')}
          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded shrink-0 cursor-pointer font-mono text-[10px]"
        >
          if distance &lt; 25
        </button>
        <button
          onClick={() => insertSnippet('for i in range(4):\n    robot.move_forward(30, "cm")\n    robot.turn_right(90)')}
          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded shrink-0 cursor-pointer font-mono text-[10px]"
        >
          for range(4)
        </button>
      </div>

      {/* Code Text Area with Line Numbers */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Line numbers gutter */}
        <div className="w-12 bg-slate-950 py-3 pr-2 text-right text-slate-500 font-mono text-xs select-none border-r border-slate-800">
          {Array.from({ length: Math.max(lineCount, 15) }).map((_, i) => (
            <div key={i} className="leading-6">
              {i + 1}
            </div>
          ))}
        </div>

        {/* Text editor input */}
        <textarea
          value={code}
          onChange={(e) => onChange(e.target.value)}
          readOnly={isReadOnly}
          className="flex-1 bg-slate-900 text-slate-100 p-3 font-mono text-xs leading-6 outline-none resize-none overflow-auto border-none focus:ring-0 selection:bg-blue-600/40"
          spellCheck={false}
          autoCapitalize="off"
          autoComplete="off"
          placeholder="# Tuliskan kode Python robot di sini..."
        />
      </div>

      {/* Editor Footer Info */}
      <div className="px-3 py-1 bg-slate-950 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between font-sans">
        <span>Baris: {lineCount} | Python 3 Async Syntax</span>
        <span className="text-slate-400">Tekan "Jalankan (Run)" di atas untuk eksekusi simulasi</span>
      </div>
    </div>
  );
};
