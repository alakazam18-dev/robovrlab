import React, { useEffect, useRef, useState, useImperativeHandle, forwardRef } from 'react';
import * as Blockly from 'blockly/core';
import 'blockly/blocks';
import * as En from 'blockly/msg/en';
import { javascriptGenerator } from 'blockly/javascript';
import { registerRoboBlocks } from '../../services/blockly/customBlocks';
import { BLOCKLY_TOOLBOX } from '../../services/blockly/toolbox';
import { generatePythonCode } from '../../services/blockly/pythonGenerator';
import { registerContinuousToolbox } from '@blockly/continuous-toolbox';
import { Boxes, Sun, Moon, Trash2, RotateCcw } from 'lucide-react';
import { soundEffects } from '../../services/audio/soundEffects';

// Register Scratch-style Continuous Scrolling Toolbox plugin
registerContinuousToolbox();

// Set English messages for standard Blockly blocks
Blockly.setLocale(En as any);

export interface BlocklyEditorHandle {
  getWorkspaceJson: () => any;
  loadWorkspaceJson: (json: any) => boolean;
  loadStarterBlocks: () => void;
  clearWorkspace: () => void;
}

interface BlocklyEditorProps {
  onCodeChange: (jsCode: string, pythonCode: string) => void;
  initialMissionId?: string;
}

// High-contrast Theme with bold dark text for toolbox categories (Light Mode)
const robovrLightTheme = Blockly.Theme.defineTheme('robovrLight', {
  name: 'robovrLight',
  base: Blockly.Themes.Zelos,
  componentStyles: {
    workspaceBackgroundColour: '#f8fafc',
    toolboxBackgroundColour: '#f1f5f9',
    toolboxForegroundColour: '#0f172a',
    flyoutBackgroundColour: '#ffffff',
    flyoutForegroundColour: '#0f172a',
    flyoutOpacity: 0.98,
  },
});

// High-contrast Theme with bright text for dark workspace (Dark Mode - Default)
const robovrDarkTheme = Blockly.Theme.defineTheme('robovrDark', {
  name: 'robovrDark',
  base: Blockly.Themes.Zelos,
  componentStyles: {
    workspaceBackgroundColour: '#090d16',
    toolboxBackgroundColour: '#0f172a',
    toolboxForegroundColour: '#f8fafc',
    flyoutBackgroundColour: '#090d16',
    flyoutForegroundColour: '#f8fafc',
    flyoutOpacity: 0.98,
  },
});

export const BlocklyEditor = forwardRef<BlocklyEditorHandle, BlocklyEditorProps>(
  ({ onCodeChange, initialMissionId }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const workspaceRef = useRef<Blockly.WorkspaceSvg | null>(null);
    // Dark mode is default as requested
    const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
      try {
        const saved = localStorage.getItem('robovr_dark_mode');
        if (saved !== null) return saved === 'true';
      } catch {}
      return true; // Default to dark background
    });

  useEffect(() => {
    registerRoboBlocks();

    if (!containerRef.current) return;

    // Inject Blockly
    const workspace = Blockly.inject(containerRef.current, {
      toolbox: BLOCKLY_TOOLBOX,
      theme: isDarkMode ? robovrDarkTheme : robovrLightTheme,
      collapse: true,
      comments: true,
      disable: true,
      maxBlocks: Infinity,
      trashcan: true,
      horizontalLayout: false,
      toolboxPosition: 'start',
      plugins: {
        toolbox: 'ContinuousToolbox',
        flyoutsVerticalToolbox: 'ContinuousFlyout',
        metricsManager: 'ContinuousMetrics',
      },
      css: true,
      media: 'https://unpkg.com/blockly/media/',
      renderer: 'zelos', // Sleek modern rounded blocks (like Scratch / VEXcode VR)
      zoom: {
        controls: true,
        wheel: true,
        startScale: 0.85,
        maxScale: 2.0,
        minScale: 0.4,
        scaleSpeed: 1.1,
      },
      grid: {
        spacing: 25,
        length: 3,
        colour: isDarkMode ? '#1e293b' : '#cbd5e1',
        snap: true,
      },
    });

    workspaceRef.current = workspace;

    // Listener for block changes
    const changeListener = () => {
      try {
        const js = javascriptGenerator.workspaceToCode(workspace);
        const py = generatePythonCode(workspace);
        onCodeChange(js, py);
      } catch (err) {
        console.warn('Blockly generation error:', err);
      }
    };

    workspace.addChangeListener(changeListener);

    // Load initial starter block stack (Move forward 50 cm, Pen down, Turn right 90)
    loadStarterBlocks(workspace);

    // Resize handler
    const handleResize = () => {
      Blockly.svgResize(workspace);
    };
    window.addEventListener('resize', handleResize);

    const observer = new ResizeObserver(() => {
      Blockly.svgResize(workspace);
    });
    observer.observe(containerRef.current);

    return () => {
      window.removeEventListener('resize', handleResize);
      observer.disconnect();
      workspace.dispose();
    };
  }, []);

  const loadStarterBlocks = (ws: Blockly.WorkspaceSvg) => {
    ws.clear();
    // Create starter blocks programmatically
    const block1 = ws.newBlock('robot_set_speed');
    block1.setFieldValue('80', 'SPEED');
    block1.initSvg();
    block1.render();
    block1.moveBy(40, 30);

    const block2 = ws.newBlock('robot_pen_down');
    block2.initSvg();
    block2.render();

    const block3 = ws.newBlock('robot_drive_distance');
    block3.setFieldValue('forward', 'DIRECTION');
    block3.setFieldValue('50', 'DISTANCE');
    block3.setFieldValue('cm', 'UNIT');
    block3.initSvg();
    block3.render();

    const block4 = ws.newBlock('robot_turn_angle');
    block4.setFieldValue('right', 'DIRECTION');
    block4.setFieldValue('90', 'ANGLE');
    block4.initSvg();
    block4.render();

    // Connect them safely
    if (block1.nextConnection && block2.previousConnection) {
      block1.nextConnection.connect(block2.previousConnection);
    }
    if (block2.nextConnection && block3.previousConnection) {
      block2.nextConnection.connect(block3.previousConnection);
    }
    if (block3.nextConnection && block4.previousConnection) {
      block3.nextConnection.connect(block4.previousConnection);
    }

    // Trigger initial code generation
    const js = javascriptGenerator.workspaceToCode(ws);
    const py = generatePythonCode(ws);
    onCodeChange(js, py);
  };

    useImperativeHandle(ref, () => ({
      getWorkspaceJson: () => {
        if (!workspaceRef.current) return null;
        try {
          return Blockly.serialization.workspaces.save(workspaceRef.current);
        } catch (err) {
          console.error('Error saving Blockly workspace state:', err);
          return null;
        }
      },
      loadWorkspaceJson: (json: any) => {
        if (!workspaceRef.current) return false;
        try {
          workspaceRef.current.clear();
          if (json && Object.keys(json).length > 0) {
            Blockly.serialization.workspaces.load(json, workspaceRef.current);
          }
          const js = javascriptGenerator.workspaceToCode(workspaceRef.current);
          const py = generatePythonCode(workspaceRef.current);
          onCodeChange(js, py);
          return true;
        } catch (err) {
          console.error('Error restoring Blockly workspace state:', err);
          return false;
        }
      },
      loadStarterBlocks: () => {
        if (workspaceRef.current) {
          loadStarterBlocks(workspaceRef.current);
        }
      },
      clearWorkspace: () => {
        if (workspaceRef.current) {
          workspaceRef.current.clear();
          onCodeChange('', '');
        }
      },
    }));

    const handleReset = () => {
      soundEffects.playUiClick();
      if (workspaceRef.current) {
        loadStarterBlocks(workspaceRef.current);
      }
    };

    const handleClear = () => {
      soundEffects.playUiClick();
      if (workspaceRef.current) {
        workspaceRef.current.clear();
        onCodeChange('', '');
      }
    };

    const handleToggleCanvasBackground = () => {
      soundEffects.playUiClick();
      const nextMode = !isDarkMode;
      setIsDarkMode(nextMode);
      try {
        localStorage.setItem('robovr_dark_mode', String(nextMode));
      } catch {}
      if (workspaceRef.current) {
        workspaceRef.current.setTheme(nextMode ? robovrDarkTheme : robovrLightTheme);
      }
    };

    return (
      <div className={`relative w-full h-full min-h-[380px] flex flex-col ${isDarkMode ? 'blockly-dark-mode bg-slate-950' : 'bg-slate-50'}`}>
        {/* Top Toolbar */}
        <div className="flex items-center justify-between px-3 py-2 bg-slate-950 border-b border-slate-800 text-slate-200 select-none">
          <div className="flex items-center gap-2">
            <Boxes className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-xs text-white">Visual Block Editor (Scratch Model)</span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Latar Belakang / Theme Switcher */}
            <button
              onClick={handleToggleCanvasBackground}
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded text-[11px] font-sans transition-colors cursor-pointer"
              title="Ubah warna latar belakang kanvas (Terang / Gelap)"
            >
              {isDarkMode ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Latar Terang</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-blue-300" />
                  <span>Latar Gelap</span>
                </>
              )}
            </button>

            {/* Reset Starter Blocks */}
            <button
              onClick={handleReset}
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded text-[11px] font-sans transition-colors cursor-pointer"
              title="Muat ulang contoh blok awal"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Blok</span>
            </button>

            {/* Clear Workspace */}
            <button
              onClick={handleClear}
              className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-300 rounded text-[11px] font-sans transition-colors cursor-pointer"
              title="Hapus semua blok dari kanvas"
            >
              <Trash2 className="w-3 h-3" />
              <span>Bersihkan</span>
            </button>
          </div>
        </div>

        {/* Blockly Injection Mount */}
        <div ref={containerRef} className="w-full flex-1 relative overflow-hidden" />
      </div>
    );
  }
);
BlocklyEditor.displayName = 'BlocklyEditor';

