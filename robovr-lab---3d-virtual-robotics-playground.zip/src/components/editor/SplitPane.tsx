import React, { useState, useRef, useCallback } from 'react';
import { MobilePaneView } from '../navbar/HeaderNavbar';

interface SplitPaneProps {
  left: React.ReactNode;
  right: React.ReactNode;
  mobilePane?: MobilePaneView;
}

export const SplitPane: React.FC<SplitPaneProps> = ({ left, right, mobilePane = 'split' }) => {
  const [splitRatio, setSplitRatio] = useState<number>(50); // percentage (50% left, 50% right on desktop)
  const isDraggingRef = useRef<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const startDrag = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isDraggingRef.current = true;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';

    const onMouseMove = (moveEvent: MouseEvent) => {
      if (!isDraggingRef.current || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const currentX = moveEvent.clientX - rect.left;
      const percentage = (currentX / rect.width) * 100;
      // Clamp between 20% and 80%
      const clamped = Math.max(20, Math.min(80, percentage));
      setSplitRatio(clamped);
    };

    const onMouseUp = () => {
      isDraggingRef.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      // Trigger resize for Blockly and Three.js canvas
      window.dispatchEvent(new Event('resize'));
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  }, []);

  return (
    <div ref={containerRef} className="flex-1 w-full h-full flex flex-col md:flex-row overflow-hidden relative">
      {/* Left Pane (Code Editor) */}
      <div
        style={{
          width: undefined, // Handled by media query or style
        }}
        className={`w-full md:h-full relative overflow-hidden flex flex-col border-b md:border-b-0 md:border-r border-slate-800 transition-all ${
          mobilePane === 'code'
            ? 'h-full flex'
            : mobilePane === '3d'
            ? 'hidden md:flex'
            : 'h-1/2 flex'
        }`}
        {...(window.innerWidth >= 768 ? { style: { width: `${splitRatio}%` } } : {})}
      >
        {left}
      </div>

      {/* Resizable Divider Handle (Desktop) */}
      <div
        onMouseDown={startDrag}
        onDoubleClick={() => {
          setSplitRatio(50);
          window.dispatchEvent(new Event('resize'));
        }}
        title="Geser untuk mengatur lebar / Klik ganda untuk 50:50"
        className="hidden md:flex w-2.5 hover:w-3 bg-slate-900 hover:bg-blue-600 transition-colors cursor-col-resize items-center justify-center shrink-0 z-10 group"
      >
        <div className="w-1 h-8 rounded-full bg-slate-600 group-hover:bg-white" />
      </div>

      {/* Right Pane (3D Playground) */}
      <div
        className={`w-full md:h-full relative overflow-hidden flex flex-col transition-all ${
          mobilePane === '3d'
            ? 'h-full flex'
            : mobilePane === 'code'
            ? 'hidden md:flex'
            : 'h-1/2 flex'
        }`}
        {...(window.innerWidth >= 768 ? { style: { width: `${100 - splitRatio}%` } } : {})}
      >
        {right}
      </div>
    </div>
  );
};
