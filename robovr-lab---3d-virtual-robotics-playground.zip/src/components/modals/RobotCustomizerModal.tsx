import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  RobotBodyType,
  RobotCustomizationConfig,
  DEFAULT_ROBOT_CUSTOMIZATION,
} from '../../types/robot';
import { createRobot3DModel } from '../../services/three/robotModel';
import { soundEffects } from '../../services/audio/soundEffects';
import { X, Sparkles, Check, RotateCcw, Shield, Rocket, Car, Lightbulb } from 'lucide-react';

interface RobotCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentConfig: RobotCustomizationConfig;
  onSaveConfig: (config: RobotCustomizationConfig) => void;
}

const CHASSIS_COLORS = [
  { name: 'Dark Stealth', hex: '#1e293b' },
  { name: 'Cyber Cyan', hex: '#06b6d4' },
  { name: 'Electric Blue', hex: '#2563eb' },
  { name: 'Crimson Red', hex: '#dc2626' },
  { name: 'Emerald Green', hex: '#059669' },
  { name: 'Solar Amber', hex: '#d97706' },
  { name: 'Neon Violet', hex: '#7c3aed' },
  { name: 'Titanium White', hex: '#f1f5f9' },
];

const ACCENT_COLORS = [
  { name: 'Robotic Blue', hex: '#2563eb' },
  { name: 'Neon Cyan', hex: '#06b6d4' },
  { name: 'Racing Red', hex: '#ef4444' },
  { name: 'Cyber Green', hex: '#10b981' },
  { name: 'Sunburst Gold', hex: '#f59e0b' },
  { name: 'Deep Purple', hex: '#9333ea' },
  { name: 'Charcoal Black', hex: '#0f172a' },
  { name: 'Platinum Silver', hex: '#e2e8f0' },
];

const NEON_COLORS = [
  { name: 'Mati (Off)', hex: 'none' },
  { name: 'Electric Cyan', hex: '#00f5ff' },
  { name: 'Acid Lime', hex: '#39ff14' },
  { name: 'Neon Magenta', hex: '#ff007f' },
  { name: 'Cyber Gold', hex: '#ffd700' },
  { name: 'Ultra Violet', hex: '#b026ff' },
];

export const RobotCustomizerModal: React.FC<RobotCustomizerModalProps> = ({
  isOpen,
  onClose,
  currentConfig,
  onSaveConfig,
}) => {
  const [config, setConfig] = useState<RobotCustomizationConfig>(currentConfig);
  const previewMountRef = useRef<HTMLDivElement>(null);
  const previewSceneRef = useRef<THREE.Scene | null>(null);
  const previewRobotRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    setConfig(currentConfig);
  }, [currentConfig, isOpen]);

  // Setup 3D preview turntable inside modal
  useEffect(() => {
    if (!isOpen || !previewMountRef.current) return;

    const container = previewMountRef.current;
    const width = container.clientWidth || 320;
    const height = container.clientHeight || 280;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f1d);
    previewSceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 50);
    camera.position.set(2.8, 2.2, 3.4);
    camera.lookAt(0, 0.4, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2.0;
    controls.maxPolarAngle = Math.PI / 2 - 0.05;
    controls.minDistance = 2.0;
    controls.maxDistance = 6.0;

    // Lighting
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.HemisphereLight(0x38bdf8, 0x1e293b, 1.2);
    scene.add(fillLight);

    // Circular pedestal platform
    const platformGeo = new THREE.CylinderGeometry(1.5, 1.6, 0.1, 32);
    const platformMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.8,
      roughness: 0.2,
    });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.position.y = -0.05;
    platform.receiveShadow = true;
    scene.add(platform);

    // Glowing rim ring
    const ringGeo = new THREE.RingGeometry(1.45, 1.55, 32);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.y = 0.01;
    scene.add(ring);

    // Build robot
    const robot = createRobot3DModel(config);
    scene.add(robot.root);
    previewRobotRef.current = robot.root;

    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();
      container.innerHTML = '';
    };
  }, [isOpen]);

  // Update robot inside preview when config changes
  useEffect(() => {
    const scene = previewSceneRef.current;
    if (!scene || !isOpen) return;

    if (previewRobotRef.current) {
      scene.remove(previewRobotRef.current);
    }

    const newRobot = createRobot3DModel(config);
    scene.add(newRobot.root);
    previewRobotRef.current = newRobot.root;
  }, [config, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    soundEffects.playRobotBoot();
    onSaveConfig(config);
    try {
      localStorage.setItem('robovr_customization', JSON.stringify(config));
    } catch {}
    onClose();
  };

  const handleResetDefault = () => {
    soundEffects.playReset();
    setConfig(DEFAULT_ROBOT_CUSTOMIZATION);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Kustomisasi Karakter Robot 3D</h2>
              <p className="text-xs text-slate-400">Pilih tipe bodi, warna sasis, dan lampu neon sesuai gayamu</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Split view (Preview on left, controls on right) */}
        <div className="flex flex-col md:flex-row flex-1 overflow-y-auto">
          {/* Left: 3D Turntable Preview */}
          <div className="w-full md:w-5/12 bg-slate-950/80 border-b md:border-b-0 md:border-r border-slate-800 flex flex-col items-center justify-center p-4 relative min-h-[260px] md:min-h-[380px]">
            <div ref={previewMountRef} className="w-full h-full min-h-[240px] flex items-center justify-center" />
            <div className="absolute bottom-3 text-center pointer-events-none">
              <p className="text-[11px] text-slate-400 font-medium bg-slate-900/80 backdrop-blur px-3 py-1 rounded-full border border-slate-800 shadow">
                💡 Putar mouse / geser layar untuk melihat 360°
              </p>
            </div>
          </div>

          {/* Right: Controls Panel */}
          <div className="w-full md:w-7/12 p-5 space-y-5 overflow-y-auto">
            {/* 1. Tipe Bodi */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5 block">
                1. Tipe Bodi Robot (Chassis Model)
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  {
                    id: 'cyber' as RobotBodyType,
                    name: 'Cyber Cruiser',
                    desc: 'Aerodinamis & Spoiler',
                    icon: Car,
                  },
                  {
                    id: 'scout' as RobotBodyType,
                    name: 'Mars Scout',
                    desc: 'Antena Radar & Surya',
                    icon: Rocket,
                  },
                  {
                    id: 'tank' as RobotBodyType,
                    name: 'Heavy Tank',
                    desc: 'Tameng & Armor Depan',
                    icon: Shield,
                  },
                ].map((item) => {
                  const Icon = item.icon;
                  const isSelected = config.bodyType === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        soundEffects.playUiClick();
                        setConfig({ ...config, bodyType: item.id });
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-blue-600/20 border-blue-500 text-white shadow-md shadow-blue-500/10'
                          : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${isSelected ? 'text-blue-400' : 'text-slate-400'}`} />
                      <span className="text-xs font-bold leading-tight">{item.name}</span>
                      <span className="text-[10px] text-slate-400">{item.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Warna Sasis Utama */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5 block">
                2. Warna Bodi Utama (Hull Chassis)
              </label>
              <div className="flex flex-wrap gap-2.5">
                {CHASSIS_COLORS.map((col) => {
                  const isSelected = config.chassisColor.toLowerCase() === col.hex.toLowerCase();
                  return (
                    <button
                      key={col.hex}
                      onClick={() => {
                        soundEffects.playUiClick();
                        setConfig({ ...config, chassisColor: col.hex });
                      }}
                      title={col.name}
                      className={`relative w-9 h-9 rounded-xl border-2 flex items-center justify-center transition-all cursor-pointer ${
                        isSelected ? 'border-white scale-110 shadow-lg' : 'border-slate-700 hover:scale-105'
                      }`}
                      style={{ backgroundColor: col.hex }}
                    >
                      {isSelected && <Check className="w-4 h-4 text-white drop-shadow-md stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Warna Aksen Penutup Atas */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5 block">
                3. Warna Aksen Penutup Atas (Top Plate)
              </label>
              <div className="flex flex-wrap gap-2.5">
                {ACCENT_COLORS.map((col) => {
                  const isSelected = config.topPlateColor.toLowerCase() === col.hex.toLowerCase();
                  return (
                    <button
                      key={col.hex}
                      onClick={() => {
                        soundEffects.playUiClick();
                        setConfig({ ...config, topPlateColor: col.hex });
                      }}
                      title={col.name}
                      className={`relative w-9 h-9 rounded-xl border-2 flex items-center justify-center transition-all cursor-pointer ${
                        isSelected ? 'border-white scale-110 shadow-lg' : 'border-slate-700 hover:scale-105'
                      }`}
                      style={{ backgroundColor: col.hex }}
                    >
                      {isSelected && <Check className="w-4 h-4 text-white drop-shadow-md stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Lampu Neon Kolong (Underglow) */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                4. Lampu Neon Kolong Robot (Underglow)
              </label>
              <div className="flex flex-wrap gap-2.5">
                {NEON_COLORS.map((col) => {
                  const isSelected = config.neonUnderglowColor.toLowerCase() === col.hex.toLowerCase();
                  return (
                    <button
                      key={col.hex}
                      onClick={() => {
                        soundEffects.playUiClick();
                        setConfig({ ...config, neonUnderglowColor: col.hex });
                      }}
                      title={col.name}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-cyan-400 bg-cyan-500/20 text-white shadow-md shadow-cyan-500/20'
                          : 'border-slate-700 bg-slate-800/70 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {col.hex !== 'none' ? (
                        <span
                          className="w-3 h-3 rounded-full shadow-sm"
                          style={{ backgroundColor: col.hex, boxShadow: `0 0 6px ${col.hex}` }}
                        />
                      ) : (
                        <span className="w-3 h-3 rounded-full bg-slate-600" />
                      )}
                      <span>{col.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Lampu Sorot Depan (Headlights) */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <div>
                  <h4 className="text-xs font-bold text-white">Lampu Sorot Depan (Headlights)</h4>
                  <p className="text-[11px] text-slate-400">Pancaran cahaya ganda di depan robot</p>
                </div>
              </div>
              <button
                onClick={() => {
                  soundEffects.playUiClick();
                  setConfig({ ...config, headlightsEnabled: !config.headlightsEnabled });
                }}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                  config.headlightsEnabled ? 'bg-blue-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    config.headlightsEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900/90">
          <button
            onClick={handleResetDefault}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-medium transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Standar</span>
          </button>
          <div className="flex items-center gap-2.5">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-300 hover:bg-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30 transition-all cursor-pointer active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Terapkan & Simpan</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
