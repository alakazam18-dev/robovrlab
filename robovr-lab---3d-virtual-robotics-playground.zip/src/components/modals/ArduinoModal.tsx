import React, { useState } from 'react';
import {
  Cpu,
  X,
  Copy,
  Check,
  Download,
  Cable,
  Zap,
  Sliders,
  HelpCircle,
  Play,
  Square,
  PenTool,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { ArduinoPinConfig, DEFAULT_ARDUINO_CONFIG, L293D_IC_CONFIG, L293D_SHIELD_CONFIG, MotorDriverType } from '../../types/arduino';
import { generateArduinoSketch, getLiveSerialBridgeFirmware } from '../../services/arduino/arduinoGenerator';
import { serialBridge } from '../../services/arduino/webSerialBridge';

interface ArduinoModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCode: string;
  isPython: boolean;
  isSerialConnected: boolean;
  onConnectSerial: () => Promise<void>;
  onDisconnectSerial: () => Promise<void>;
}

export const ArduinoModal: React.FC<ArduinoModalProps> = ({
  isOpen,
  onClose,
  currentCode,
  isPython,
  isSerialConnected,
  onConnectSerial,
  onDisconnectSerial,
}) => {
  const [activeTab, setActiveTab] = useState<'code' | 'wiring' | 'serial' | 'pins'>('code');
  const [driverType, setDriverType] = useState<MotorDriverType>('L298N');
  const [config, setConfig] = useState<ArduinoPinConfig>(DEFAULT_ARDUINO_CONFIG);
  const [copied, setCopied] = useState(false);
  const [firmwareCopied, setFirmwareCopied] = useState(false);

  if (!isOpen) return null;

  const handleDriverChange = (type: MotorDriverType) => {
    setDriverType(type);
    if (type === 'L298N') setConfig(DEFAULT_ARDUINO_CONFIG);
    else if (type === 'L293D_SHIELD') setConfig(L293D_SHIELD_CONFIG);
    else setConfig(L293D_IC_CONFIG);
  };

  const generatedSketch = generateArduinoSketch(currentCode, config, isPython);
  const firmwareSketch = getLiveSerialBridgeFirmware(config);

  const handleCopyCode = (text: string, isFw = false) => {
    navigator.clipboard.writeText(text);
    if (isFw) {
      setFirmwareCopied(true);
      setTimeout(() => setFirmwareCopied(false), 2000);
    } else {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    const blob = new Blob([generatedSketch], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RoboVR_${driverType}_Robot.ino`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-xs select-none">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 text-teal-400 rounded-xl border border-teal-500/30">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Arduino & Driver Motor Bridge
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 font-semibold">
                  L298N & L293D
                </span>
              </h2>
              <p className="text-xs text-slate-400">Ekspor kode C++ (.ino) dan kendalikan robot fisik nyata via USB</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-900 px-6 gap-2 pt-2 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('code')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'code'
                ? 'border-teal-400 text-teal-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Kode Arduino (.ino)</span>
          </button>

          <button
            onClick={() => setActiveTab('wiring')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'wiring'
                ? 'border-teal-400 text-teal-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cable className="w-3.5 h-3.5" />
            <span>Skema Pinout & Rangkaian</span>
          </button>

          <button
            onClick={() => setActiveTab('serial')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'serial'
                ? 'border-teal-400 text-teal-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isSerialConnected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
            <span>Live USB Serial Control</span>
          </button>

          <button
            onClick={() => setActiveTab('pins')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'pins'
                ? 'border-teal-400 text-teal-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Kustomisasi Pin</span>
          </button>
        </div>

        {/* Tab 1: Code Generator */}
        {activeTab === 'code' && (
          <div className="p-6 flex-1 flex flex-col overflow-hidden space-y-4">
            {/* Driver Selector */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-medium">Pilih Driver Motor:</span>
                <div className="flex bg-slate-900 rounded-lg p-0.5 border border-slate-800">
                  <button
                    onClick={() => handleDriverChange('L298N')}
                    className={`px-3 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                      driverType === 'L298N' ? 'bg-teal-600 text-white shadow' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Modul L298N (Rekomendasi)
                  </button>
                  <button
                    onClick={() => handleDriverChange('L293D_SHIELD')}
                    className={`px-3 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                      driverType === 'L293D_SHIELD' ? 'bg-teal-600 text-white shadow' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Shield L293D (Adafruit)
                  </button>
                  <button
                    onClick={() => handleDriverChange('L293D_IC')}
                    className={`px-3 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                      driverType === 'L293D_IC' ? 'bg-teal-600 text-white shadow' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    IC L293D Standalone
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopyCode(generatedSketch)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Tersalin!' : 'Salin Kode C++'}</span>
                </button>

                <button
                  onClick={handleDownload}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File .ino</span>
                </button>
              </div>
            </div>

            {/* Code Box */}
            <div className="flex-1 overflow-auto rounded-xl border border-slate-800 bg-slate-950 p-4 font-mono text-xs leading-5 text-slate-200 relative selection:bg-teal-600/40">
              <pre>{generatedSketch}</pre>
            </div>

            <div className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Buka file <code>.ino</code> pada Arduino IDE dan tekan <strong>Upload (Ctrl+U)</strong> ke Arduino Uno/Nano.</span>
              <span className="text-teal-400 font-semibold">Kompatibel: Uno, Nano, Mega, ESP32</span>
            </div>
          </div>
        )}

        {/* Tab 2: Wiring Guide */}
        {activeTab === 'wiring' && (
          <div className="p-6 flex-1 overflow-y-auto space-y-5 text-xs">
            <div className="p-4 bg-teal-950/40 border border-teal-500/30 rounded-xl text-teal-200 flex items-start gap-3">
              <HelpCircle className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block mb-1">Panduan Rangkaian Hardware Robot Fisik:</strong>
                Gunakan tabel pinout berikut untuk menyambungkan kabel jumper dari pin digital Arduino Uno ke pin modul driver motor L298N atau shield L293D.
              </div>
            </div>

            {/* L298N Table */}
            <div>
              <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-400" />
                1. Rangkaian Modul Driver Motor L298N Dual H-Bridge
              </h3>
              <div className="border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-950 text-slate-300 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">Pin Modul L298N</th>
                      <th className="p-2.5">Pin Arduino Uno</th>
                      <th className="p-2.5">Fungsi / Deskripsi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                    <tr>
                      <td className="p-2 text-teal-300 font-bold">ENA (Lepas Jumper)</td>
                      <td className="p-2">Pin ~5 (PWM)</td>
                      <td className="p-2 font-sans text-slate-400">Pengatur Kecepatan Roda Kiri</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-teal-300 font-bold">IN1</td>
                      <td className="p-2">Pin 6</td>
                      <td className="p-2 font-sans text-slate-400">Arah Roda Kiri Maju</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-teal-300 font-bold">IN2</td>
                      <td className="p-2">Pin 7</td>
                      <td className="p-2 font-sans text-slate-400">Arah Roda Kiri Mundur</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-blue-300 font-bold">IN3</td>
                      <td className="p-2">Pin 8</td>
                      <td className="p-2 font-sans text-slate-400">Arah Roda Kanan Maju</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-blue-300 font-bold">IN4</td>
                      <td className="p-2">Pin 9</td>
                      <td className="p-2 font-sans text-slate-400">Arah Roda Kanan Mundur</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-blue-300 font-bold">ENB (Lepas Jumper)</td>
                      <td className="p-2">Pin ~10 (PWM)</td>
                      <td className="p-2 font-sans text-slate-400">Pengatur Kecepatan Roda Kanan</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-amber-300 font-bold">GND</td>
                      <td className="p-2">GND Arduino & (-) Baterai</td>
                      <td className="p-2 font-sans text-amber-200">Wajib Common Ground (Hubungkan GND baterai & Arduino)</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-rose-300 font-bold">+12V / VMS</td>
                      <td className="p-2">(+) Baterai 7.4V - 12V</td>
                      <td className="p-2 font-sans text-rose-200">Daya motor penggerak (gunakan baterai Li-ion 18650 x2)</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Sensors Table */}
            <div>
              <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-400" />
                2. Sensor Jarak Ultrasonik & Servo Pena
              </h3>
              <div className="border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-950 text-slate-300 font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">Komponen</th>
                      <th className="p-2.5">Pin Arduino Uno</th>
                      <th className="p-2.5">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                    <tr>
                      <td className="p-2 font-sans font-bold text-slate-200">HC-SR04 (Trig)</td>
                      <td className="p-2">Pin 11</td>
                      <td className="p-2 font-sans text-slate-400">Pemancar pulsa ultrasonik</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-sans font-bold text-slate-200">HC-SR04 (Echo)</td>
                      <td className="p-2">Pin 12</td>
                      <td className="p-2 font-sans text-slate-400">Penerima pantulan gelombang</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-sans font-bold text-slate-200">Servo SG90 (Pena)</td>
                      <td className="p-2">Pin ~3</td>
                      <td className="p-2 font-sans text-slate-400">Pengangkat / penurun spidol gambar</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-sans font-bold text-slate-200">Sensor Garis TCRT5000</td>
                      <td className="p-2">Pin A0</td>
                      <td className="p-2 font-sans text-slate-400">Pendeteksi warna/garis lantai (Down Eye)</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Web Serial Live USB */}
        {activeTab === 'serial' && (
          <div className="p-6 flex-1 overflow-y-auto space-y-5 text-xs">
            {/* Status card */}
            <div className={`p-4 rounded-xl border flex items-center justify-between gap-3 ${
              isSerialConnected
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : 'bg-slate-800/80 border-slate-700 text-slate-300'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`p-2.5 rounded-xl ${isSerialConnected ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
                  <Cable className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">
                    {isSerialConnected ? 'Arduino Terhubung via USB Serial' : 'Arduino Belum Terhubung'}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {isSerialConnected
                      ? 'Robot fisik siap merespons perintah real-time dari RoboVR Lab!'
                      : 'Sambungkan kabel USB Arduino ke laptop/PC dan tekan tombol Hubungkan.'}
                  </div>
                </div>
              </div>

              {isSerialConnected ? (
                <button
                  onClick={onDisconnectSerial}
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold text-xs shadow transition-all cursor-pointer"
                >
                  Putuskan USB
                </button>
              ) : (
                <button
                  onClick={onConnectSerial}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95 flex items-center gap-1.5"
                >
                  <Cable className="w-4 h-4" />
                  <span>Hubungkan USB Arduino</span>
                </button>
              )}
            </div>

            {/* Quick Test Manual Actions */}
            {isSerialConnected && (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <Play className="w-4 h-4 text-teal-400" />
                  Uji Gerak Robot Fisik Nyata:
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => serialBridge.sendCommand('FORWARD 150')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-teal-600 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Maju 15 cm
                  </button>
                  <button
                    onClick={() => serialBridge.sendCommand('BACKWARD 150')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-teal-600 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Mundur 15 cm
                  </button>
                  <button
                    onClick={() => serialBridge.sendCommand('LEFT 90')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-teal-600 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Putar Kiri 90°
                  </button>
                  <button
                    onClick={() => serialBridge.sendCommand('RIGHT 90')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-teal-600 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Putar Kanan 90°
                  </button>
                  <button
                    onClick={() => serialBridge.sendCommand('STOP')}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold transition-colors cursor-pointer"
                  >
                    Stop Motor
                  </button>
                  <button
                    onClick={() => serialBridge.sendCommand('PEN_DOWN')}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Pena Turun
                  </button>
                  <button
                    onClick={() => serialBridge.sendCommand('PEN_UP')}
                    className="px-3 py-1.5 bg-purple-800 hover:bg-purple-700 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Pena Naik
                  </button>
                </div>
              </div>
            )}

            {/* Instructions to flash Live Firmware */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">Firmware USB Live Control (Unggah 1x ke Arduino):</span>
                <button
                  onClick={() => handleCopyCode(firmwareSketch, true)}
                  className="flex items-center gap-1 text-[11px] text-teal-400 hover:text-teal-300 cursor-pointer"
                >
                  {firmwareCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{firmwareCopied ? 'Tersalin' : 'Salin Firmware'}</span>
                </button>
              </div>
              <div className="max-h-48 overflow-auto rounded-xl border border-slate-800 bg-slate-950 p-3 font-mono text-[11px] text-slate-300">
                <pre>{firmwareSketch}</pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Pin Customization */}
        {activeTab === 'pins' && (
          <div className="p-6 flex-1 overflow-y-auto space-y-4 text-xs">
            <p className="text-slate-400">
              Sesuaikan nomor pin digital Arduino jika rakitan robot fisik Anda menggunakan sambungan pin yang berbeda:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-teal-300">Pin Motor Kiri (L298N / L293D)</h4>
                <div className="flex items-center justify-between">
                  <span>ENA / PWM Pin:</span>
                  <input
                    type="number"
                    value={config.leftPwmPin}
                    onChange={(e) => setConfig({ ...config, leftPwmPin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>IN1 Pin (Maju):</span>
                  <input
                    type="number"
                    value={config.leftIn1Pin}
                    onChange={(e) => setConfig({ ...config, leftIn1Pin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>IN2 Pin (Mundur):</span>
                  <input
                    type="number"
                    value={config.leftIn2Pin}
                    onChange={(e) => setConfig({ ...config, leftIn2Pin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-blue-300">Pin Motor Kanan (L298N / L293D)</h4>
                <div className="flex items-center justify-between">
                  <span>ENB / PWM Pin:</span>
                  <input
                    type="number"
                    value={config.rightPwmPin}
                    onChange={(e) => setConfig({ ...config, rightPwmPin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>IN3 Pin (Maju):</span>
                  <input
                    type="number"
                    value={config.rightIn1Pin}
                    onChange={(e) => setConfig({ ...config, rightIn1Pin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>IN4 Pin (Mundur):</span>
                  <input
                    type="number"
                    value={config.rightIn2Pin}
                    onChange={(e) => setConfig({ ...config, rightIn2Pin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-emerald-300">Pin Sensor HC-SR04</h4>
                <div className="flex items-center justify-between">
                  <span>Trig Pin:</span>
                  <input
                    type="number"
                    value={config.trigPin}
                    onChange={(e) => setConfig({ ...config, trigPin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>Echo Pin:</span>
                  <input
                    type="number"
                    value={config.echoPin}
                    onChange={(e) => setConfig({ ...config, echoPin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-purple-300">Pin Servo & Sensor Garis</h4>
                <div className="flex items-center justify-between">
                  <span>Servo Pin (Pena):</span>
                  <input
                    type="number"
                    value={config.servoPin}
                    onChange={(e) => setConfig({ ...config, servoPin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>Sensor Garis (A0):</span>
                  <input
                    type="number"
                    value={config.sensorPin}
                    onChange={(e) => setConfig({ ...config, sensorPin: Number(e.target.value) })}
                    className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded text-center font-mono font-bold text-white outline-none focus:border-teal-400"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 text-xs text-slate-400 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-teal-400" />
            <span>Driver Aktif: <strong>{driverType === 'L298N' ? 'L298N Dual H-Bridge' : driverType === 'L293D_SHIELD' ? 'L293D Shield (AFMotor)' : 'IC L293D Standalone'}</strong></span>
          </span>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
