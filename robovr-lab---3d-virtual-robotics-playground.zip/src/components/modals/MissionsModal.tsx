import React from 'react';
import { Trophy, X, ArrowRight, CheckCircle2, Compass, Sparkles } from 'lucide-react';
import { SAMPLE_MISSIONS } from '../../services/missions/sampleMissions';
import { Mission } from '../../types/robot';

interface MissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMission: (mission: Mission) => void;
  currentMissionId?: string;
}

export const MissionsModal: React.FC<MissionsModalProps> = ({
  isOpen,
  onClose,
  onSelectMission,
  currentMissionId,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs select-none">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Tantangan & Misi Edukasi STEM</h2>
              <p className="text-xs text-slate-400">Pilih skenario pembelajaran coding dan algoritma robotika</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Missions list */}
        <div className="p-6 overflow-y-auto space-y-3.5 flex-1">
          {SAMPLE_MISSIONS.map((mission) => {
            const isSelected = mission.id === currentMissionId;
            return (
              <div
                key={mission.id}
                onClick={() => {
                  onSelectMission(mission);
                  onClose();
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-blue-950/40 border-blue-500 shadow-md ring-1 ring-blue-500'
                    : 'bg-slate-800/70 border-slate-700 hover:bg-slate-800 hover:border-slate-600'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {mission.badge}
                      </span>
                      <h3 className="font-bold text-sm text-white">{mission.title}</h3>
                    </div>
                    <p className="text-xs text-slate-300">{mission.description}</p>
                    <div className="text-[11px] text-blue-300 pt-1 flex items-center gap-1 font-medium">
                      <Compass className="w-3.5 h-3.5" />
                      <span>Tujuan: {mission.goalExplanation}</span>
                    </div>
                  </div>

                  <div className="shrink-0 flex items-center gap-1 text-xs font-semibold text-blue-400 pt-1">
                    <span>Mulai</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 text-xs text-slate-400 flex items-center justify-between">
          <span>Tips: Anda dapat beralih antara Blockly dan Python kapan saja.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
