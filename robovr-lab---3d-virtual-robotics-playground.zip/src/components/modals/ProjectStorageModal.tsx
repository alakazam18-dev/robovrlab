import React, { useState, useRef } from 'react';
import {
  X,
  Download,
  Upload,
  FolderOpen,
  FileCode2,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Layers,
  Save,
  Laptop,
} from 'lucide-react';
import { ArenaType, RobotCustomizationConfig } from '../../types/robot';
import { ARENAS } from '../../services/arenas/arenaData';
import {
  exportProjectToFile,
  importProjectFromFile,
  RoboVRProjectFile,
} from '../../services/storage/projectFileManager';
import { soundEffects } from '../../services/audio/soundEffects';

interface ProjectStorageModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentArenaId: ArenaType;
  activeLanguage: 'block' | 'python';
  pythonCode: string;
  robotCustomization: RobotCustomizationConfig;
  getWorkspaceJson: () => any;
  onLoadProject: (project: RoboVRProjectFile) => void;
}

export const ProjectStorageModal: React.FC<ProjectStorageModalProps> = ({
  isOpen,
  onClose,
  currentArenaId,
  activeLanguage,
  pythonCode,
  robotCustomization,
  getWorkspaceJson,
  onLoadProject,
}) => {
  const [activeTab, setActiveTab] = useState<'save' | 'load'>('save');
  const [projectName, setProjectName] = useState<string>(() => {
    const arenaName = ARENAS[currentArenaId]?.name || 'Robotika';
    const dateStr = new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
    });
    return `Tugas ${arenaName} - ${dateStr}`;
  });

  const [downloadSuccessMessage, setDownloadSuccessMessage] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [loadedPreview, setLoadedPreview] = useState<RoboVRProjectFile | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleExport = () => {
    try {
      soundEffects.playSuccessChime();
      const blocklyState = getWorkspaceJson();
      const savedFileName = exportProjectToFile(projectName, {
        arenaId: currentArenaId,
        activeLanguage,
        blocklyState,
        pythonCode,
        robotCustomization,
      });

      setDownloadSuccessMessage(`File "${savedFileName}" berhasil diunduh ke folder Download komputermu!`);
      setTimeout(() => {
        setDownloadSuccessMessage(null);
      }, 6000);
    } catch (err: any) {
      setUploadError(err.message || 'Gagal menyimpan proyek ke file.');
    }
  };

  const handleProcessFile = async (file: File) => {
    setUploadError(null);
    setLoadedPreview(null);
    try {
      const project = await importProjectFromFile(file);
      setLoadedPreview(project);
      soundEffects.playUiClick();
    } catch (err: any) {
      soundEffects.playCollisionFeedback();
      setUploadError(err.message || 'Gagal membaca file proyek.');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  const handleApplyLoadedProject = () => {
    if (!loadedPreview) return;
    soundEffects.playSuccessChime();
    onLoadProject(loadedPreview);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Laptop className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                Simpan & Buka Proyek (.robovr)
                <span className="px-1.5 py-0.2 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Lokal PC
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Simpan hasil karya robotika ke komputer atau muat tugas siswa dari file
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEffects.playUiClick();
              onClose();
            }}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/40">
          <button
            onClick={() => {
              soundEffects.playUiClick();
              setActiveTab('save');
            }}
            className={`flex-1 py-2.5 px-4 text-xs font-semibold flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'save'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Simpan ke Komputer (.robovr)</span>
          </button>
          <button
            onClick={() => {
              soundEffects.playUiClick();
              setActiveTab('load');
            }}
            className={`flex-1 py-2.5 px-4 text-xs font-semibold flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'load'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <FolderOpen className="w-4 h-4" />
            <span>Buka File Proyek</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {activeTab === 'save' ? (
            <div className="space-y-4">
              {/* Project Name Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Nama Proyek / Tugas Siswa:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Contoh: Tugas Labirin Budi - Kelas 5A"
                    className="flex-1 bg-slate-950 border border-slate-700 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 outline-none transition-colors"
                  />
                  <span className="text-xs text-slate-400 font-mono">.robovr</span>
                </div>
              </div>

              {/* What will be saved overview */}
              <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-3.5 space-y-2 text-xs">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Isi yang Akan Disimpan dalam File:
                </span>
                <div className="grid grid-cols-2 gap-2 text-slate-400 text-[11px]">
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>Seluruh Balok Visual Blockly</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>Kode Program Python</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>Pilihan Arena 3D ({ARENAS[currentArenaId]?.name})</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>Kustomisasi Karakter Robot 3D</span>
                  </div>
                </div>
              </div>

              {/* Success Notification */}
              {downloadSuccessMessage && (
                <div className="flex items-center gap-2 p-3 bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{downloadSuccessMessage}</span>
                </div>
              )}

              {/* Download Action Button */}
              <button
                onClick={handleExport}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-950/60 transition-all cursor-pointer active:scale-98"
              >
                <Download className="w-4 h-4" />
                <span>Unduh File Proyek (.robovr)</span>
              </button>

              <p className="text-[11px] text-slate-400 text-center leading-relaxed">
                File tersimpan di perangkat lokal komputermu tanpa perlu akun atau internet. Kamu bisa mengirimkannya ke gurumu atau membukanya kembali kapan saja!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Drop / Select Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                  isDragging
                    ? 'border-indigo-400 bg-indigo-950/40'
                    : 'border-slate-700 hover:border-indigo-500/60 bg-slate-950/40 hover:bg-slate-950/70'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".robovr,.json"
                  onChange={handleFileInputChange}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-3 shadow-inner">
                  <Upload className="w-6 h-6" />
                </div>
                <h3 className="text-xs sm:text-sm font-bold text-white">
                  Pilih File Proyek (.robovr atau .json)
                </h3>
                <p className="text-[11px] text-slate-400 mt-1 max-w-sm">
                  Klik di sini untuk menjelajah file dari laptop/komputer, atau seret & lepas file ke kotak ini
                </p>
              </div>

              {/* Error Message */}
              {uploadError && (
                <div className="flex items-center gap-2 p-3 bg-rose-950/40 border border-rose-500/40 text-rose-300 rounded-xl text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{uploadError}</span>
                </div>
              )}

              {/* Preview of Loaded Project */}
              {loadedPreview && (
                <div className="bg-slate-950 rounded-xl border border-indigo-500/40 p-4 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <FileCode2 className="w-4 h-4 text-indigo-400" />
                        {loadedPreview.name}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        Disimpan pada: {new Date(loadedPreview.savedAt).toLocaleString('id-ID')}
                      </p>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      Format Valid
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                    <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Arena Target:</span>
                      <span className="font-semibold">{ARENAS[loadedPreview.arenaId]?.name || loadedPreview.arenaId}</span>
                    </div>
                    <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Bahasa Pemrograman:</span>
                      <span className="font-semibold uppercase">{loadedPreview.activeLanguage}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleApplyLoadedProject}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer active:scale-98"
                  >
                    <FolderOpen className="w-4 h-4" />
                    <span>Muat Proyek Ini ke Simulator Sekarang</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
