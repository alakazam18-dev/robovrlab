import React from 'react';
import { X, Palette, Check, Sparkles } from 'lucide-react';
import { AppThemeId, APP_THEMES } from '../../types/theme';
import { soundEffects } from '../../services/audio/soundEffects';

interface ThemeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: AppThemeId;
  onSelectTheme: (theme: AppThemeId) => void;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  isOpen,
  onClose,
  currentTheme,
  onSelectTheme,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-500 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-pink-500/20">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                Tema Tampilan RoboVR
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Fresh & Edukatif
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Pilih tema warna favoritmu agar suasana belajar coding robot selalu seru!
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEffects.playUiClick();
              onClose();
            }}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content: Theme Cards */}
        <div className="p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-h-[75vh] overflow-y-auto">
          {Object.values(APP_THEMES).map((theme) => {
            const isSelected = currentTheme === theme.id;
            return (
              <div
                key={theme.id}
                onClick={() => {
                  soundEffects.playSuccessChime();
                  onSelectTheme(theme.id);
                }}
                className={`group relative rounded-2xl p-4 border transition-all cursor-pointer flex flex-col justify-between overflow-hidden ${
                  isSelected
                    ? 'bg-slate-800/90 border-indigo-500 shadow-lg shadow-indigo-950/80 scale-[1.02]'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                }`}
              >
                {/* Top Theme Banner Bar */}
                <div
                  className={`h-2.5 -mx-4 -mt-4 mb-3 bg-gradient-to-r ${theme.colors.primaryGradient}`}
                />

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl select-none">{theme.iconEmoji}</span>
                      <div>
                        <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                          {theme.name}
                        </h3>
                        <span className="text-[10px] font-semibold text-slate-400">
                          {theme.badge}
                        </span>
                      </div>
                    </div>

                    {isSelected ? (
                      <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold shadow">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </span>
                    ) : (
                      <span className="w-6 h-6 rounded-full border border-slate-700 group-hover:border-slate-500" />
                    )}
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {theme.description}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-medium">Pratinjau Nuansa:</span>
                  <div className="flex items-center gap-1.5">
                    <div className={`w-3.5 h-3.5 rounded-full bg-gradient-to-r ${theme.colors.primaryGradient} shadow-xs`} />
                    <span className="font-semibold text-slate-200">
                      {isSelected ? 'Sedang Aktif' : 'Klik untuk Pilih'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-amber-300">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Tema akan tersimpan otomatis di perangkatmu</span>
          </div>

          <button
            onClick={() => {
              soundEffects.playUiClick();
              onClose();
            }}
            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
