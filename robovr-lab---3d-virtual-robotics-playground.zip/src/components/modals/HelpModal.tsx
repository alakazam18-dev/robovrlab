import React from 'react';
import { HelpCircle, X, BookOpen, Cpu, Radio, Eye, PenTool } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs select-none">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Panduan Platform & Referensi API RoboVR</h2>
              <p className="text-xs text-slate-400">Daftar perintah pemrograman robot visual Blockly dan Python</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Hardware & Sensor Architecture */}
          <div>
            <h3 className="text-sm font-bold text-blue-300 mb-2.5 flex items-center gap-1.5">
              <Cpu className="w-4 h-4" />
              1. Anatomi Robot Virtual & Sensor
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="font-semibold text-white flex items-center gap-1.5 mb-1">
                  <Radio className="w-4 h-4 text-emerald-400" />
                  Sensor Jarak (Ultrasonic Sonar)
                </div>
                <p className="text-slate-300">
                  Terletak di bumper depan robot. Memancarkan gelombang untuk mengukur jarak (dalam cm) ke dinding atau rintangan di depannya hingga jangkauan 250 cm.
                </p>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="font-semibold text-white flex items-center gap-1.5 mb-1">
                  <Eye className="w-4 h-4 text-indigo-400" />
                  Sensor Warna (Optical Down Eye)
                </div>
                <p className="text-slate-300">
                  Mengarah ke lantai arena. Mendeteksi warna permukaan lantai secara real-time seperti <code>red</code>, <code>green</code>, <code>blue</code>, <code>yellow</code>, <code>black</code>, atau <code>white</code>.
                </p>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="font-semibold text-white flex items-center gap-1.5 mb-1">
                  <PenTool className="w-4 h-4 text-purple-400" />
                  Pena Gambar (Pen Tool)
                </div>
                <p className="text-slate-300">
                  Pena di tengah chassis dapat diturunkan untuk melukis garis warna di lantai arena saat robot bergerak. Sangat ideal untuk materi geometri dan visual arts.
                </p>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="font-semibold text-white flex items-center gap-1.5 mb-1">
                  <Cpu className="w-4 h-4 text-amber-400" />
                  Sensor Gyro (Inertial Heading)
                </div>
                <p className="text-slate-300">
                  Mengukur orientasi sudut hadap robot dari 0° sampai 360° (0° = Utara, 90° = Timur, 180° = Selatan, 270° = Barat).
                </p>
              </div>
            </div>
          </div>

          {/* API Commands Table */}
          <div>
            <h3 className="text-sm font-bold text-blue-300 mb-2.5">
              2. Referensi Perintah Python & Blok
            </h3>
            <div className="border border-slate-700 rounded-xl overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-950 text-slate-300 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Fungsi Python</th>
                    <th className="p-2.5">Padanan Blok</th>
                    <th className="p-2.5">Penjelasan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 bg-slate-900/60 font-mono text-[11px]">
                  <tr>
                    <td className="p-2.5 text-blue-300">robot.move_forward(50, "cm")</td>
                    <td className="p-2.5 font-sans text-slate-300">Maju [50] cm</td>
                    <td className="p-2.5 font-sans text-slate-400">Maju lurus sejauh 50 cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-blue-300">robot.turn_right(90)</td>
                    <td className="p-2.5 font-sans text-slate-300">Belok Kanan [90]°</td>
                    <td className="p-2.5 font-sans text-slate-400">Memutar robot 90 derajat searah jarum jam</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-blue-300">robot.turn_left(90)</td>
                    <td className="p-2.5 font-sans text-slate-300">Belok Kiri [90]°</td>
                    <td className="p-2.5 font-sans text-slate-400">Memutar robot 90 derajat berlawanan arah jarum jam</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-purple-300">robot.pen_down()</td>
                    <td className="p-2.5 font-sans text-slate-300">Turunkan Pena</td>
                    <td className="p-2.5 font-sans text-slate-400">Mulai menggambar jejak garis di lantai arena</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-purple-300">robot.set_pen_color("red")</td>
                    <td className="p-2.5 font-sans text-slate-300">Atur Warna Pena [Merah]</td>
                    <td className="p-2.5 font-sans text-slate-400">Ubah warna tinta pena (red, blue, green, yellow, dll)</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-emerald-300">robot.get_distance()</td>
                    <td className="p-2.5 font-sans text-slate-300">Jarak Halangan Depan</td>
                    <td className="p-2.5 font-sans text-slate-400">Mengembalikan jarak objek di depan dalam satuan cm</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-emerald-300">robot.get_color()</td>
                    <td className="p-2.5 font-sans text-slate-300">Sensor Bawah Melihat Warna</td>
                    <td className="p-2.5 font-sans text-slate-400">Mengembalikan nama warna lantai yang dideteksi</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 text-amber-300">robot.sleep(1)</td>
                    <td className="p-2.5 font-sans text-slate-300">Tunggu [1] detik</td>
                    <td className="p-2.5 font-sans text-slate-400">Menunda eksekusi selama n detik</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Developer Credit */}
          <div className="p-4 bg-gradient-to-r from-indigo-950/70 via-slate-900 to-blue-950/70 rounded-xl border border-indigo-500/30 flex items-start gap-3.5 shadow-inner">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center justify-center text-sm font-black shrink-0">
              NA
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">Pengembang & Konseptor Platform:</span>
                <span className="font-extrabold text-amber-300 text-xs sm:text-sm">Nugroho Aji</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] bg-blue-500/20 text-blue-300 border border-blue-500/30 font-semibold">
                  Guru SD
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                Email: <code className="text-amber-200 bg-amber-950/40 px-1 py-0.5 rounded">nugrohoaji85@guru.sd.belajar.id</code>
              </p>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                Platform RoboVR Lab dirancang dan didedikasikan secara khusus untuk menghadirkan laboratorium simulasi robotika 3D yang interaktif, mudah dipahami, dan menyenangkan bagi siswa-siswi sekolah dasar di Indonesia.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 text-xs text-slate-400 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Mengerti
          </button>
        </div>
      </div>
    </div>
  );
};
