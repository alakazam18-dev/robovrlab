import React, { useState } from 'react';
import {
  X,
  BookOpen,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Play,
  Lightbulb,
  Compass,
  Trophy,
  Volume2,
} from 'lucide-react';
import { ROBO_STORY_CHAPTERS, StoryChapter } from '../../services/story/storyData';
import { ArenaType } from '../../types/robot';
import { ARENAS } from '../../services/arenas/arenaData';
import { soundEffects } from '../../services/audio/soundEffects';

interface RoboAdventureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadChapterCode: (chapter: StoryChapter) => void;
  currentArenaId: ArenaType;
}

// Cute SVG Mascot Avatar Component
const RoboMascotSvg: React.FC<{ mood: StoryChapter['mascotMood'] }> = ({ mood }) => {
  const getEyeExpression = () => {
    switch (mood) {
      case 'excited':
        return (
          <>
            <circle cx="38" cy="42" r="7" fill="#38bdf8" className="animate-pulse" />
            <circle cx="62" cy="42" r="7" fill="#38bdf8" className="animate-pulse" />
            <path d="M48 56 Q50 64 52 56" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M35 32 L42 36" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M65 32 L58 36" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
          </>
        );
      case 'thinking':
        return (
          <>
            <circle cx="38" cy="40" r="6" fill="#fbbf24" />
            <ellipse cx="62" cy="42" rx="7" ry="5" fill="#fbbf24" />
            <line x1="33" y1="33" x2="43" y2="33" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="56" y1="31" x2="68" y2="35" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M44 58 Q50 56 56 58" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </>
        );
      case 'detective':
        return (
          <>
            <circle cx="38" cy="42" r="6" fill="#34d399" />
            {/* Monocle / Detective Magnifier */}
            <circle cx="62" cy="42" r="10" stroke="#f59e0b" strokeWidth="3" fill="#34d399" fillOpacity="0.3" />
            <line x1="70" y1="50" x2="78" y2="58" stroke="#f59e0b" strokeWidth="3.5" strokeLinecap="round" />
            <path d="M42 58 Q50 63 58 58" stroke="#34d399" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </>
        );
      case 'astronaut':
        return (
          <>
            {/* Astronaut helmet glow */}
            <ellipse cx="50" cy="48" rx="36" ry="28" fill="none" stroke="#60a5fa" strokeWidth="2" strokeDasharray="4 2" />
            <circle cx="38" cy="42" r="7" fill="#60a5fa" />
            <circle cx="62" cy="42" r="7" fill="#60a5fa" />
            <path d="M40 57 Q50 64 60 57" stroke="#60a5fa" strokeWidth="3" strokeLinecap="round" fill="none" />
          </>
        );
      default: // happy
        return (
          <>
            <circle cx="38" cy="42" r="6" fill="#60a5fa" />
            <circle cx="62" cy="42" r="6" fill="#60a5fa" />
            <path d="M40 56 Q50 65 60 56" stroke="#60a5fa" strokeWidth="3" strokeLinecap="round" fill="none" />
          </>
        );
    }
  };

  return (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 flex-shrink-0 drop-shadow-xl select-none">
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {/* Antenna */}
        <line x1="50" y1="20" x2="50" y2="10" stroke="#94a3b8" strokeWidth="3" strokeLinecap="round" />
        <circle cx="50" cy="8" r="5" fill="#f43f5e" className="animate-ping origin-center" />
        <circle cx="50" cy="8" r="5" fill="#f43f5e" />

        {/* Outer Head Body */}
        <rect x="18" y="18" width="64" height="56" rx="16" fill="#1e293b" stroke="#3b82f6" strokeWidth="3.5" />

        {/* Visor Screen */}
        <rect x="25" y="27" width="50" height="38" rx="10" fill="#090d16" stroke="#334155" strokeWidth="1.5" />

        {/* Visor Glare */}
        <path d="M30 31 L45 31 L32 45 Z" fill="#ffffff" fillOpacity="0.1" />

        {/* Eyes & Mouth Expression */}
        {getEyeExpression()}

        {/* Cheeks blush */}
        <circle cx="30" cy="51" r="3" fill="#f43f5e" fillOpacity="0.5" />
        <circle cx="70" cy="51" r="3" fill="#f43f5e" fillOpacity="0.5" />

        {/* Ears / Wheels Side Brackets */}
        <rect x="11" y="32" width="7" height="28" rx="3.5" fill="#475569" stroke="#64748b" strokeWidth="1.5" />
        <rect x="82" y="32" width="7" height="28" rx="3.5" fill="#475569" stroke="#64748b" strokeWidth="1.5" />

        {/* Neck joint */}
        <rect x="42" y="74" width="16" height="6" rx="2" fill="#64748b" />

        {/* Chest mini crest */}
        <path d="M36 80 L64 80 L58 96 L42 96 Z" fill="#0f172a" stroke="#3b82f6" strokeWidth="2" />
        <circle cx="50" cy="88" r="3" fill="#38bdf8" />
      </svg>
    </div>
  );
};

export const RoboAdventureModal: React.FC<RoboAdventureModalProps> = ({
  isOpen,
  onClose,
  onLoadChapterCode,
  currentArenaId,
}) => {
  const [selectedChapterIndex, setSelectedChapterIndex] = useState<number>(0);

  if (!isOpen) return null;

  const currentChapter = ROBO_STORY_CHAPTERS[selectedChapterIndex];
  const targetArena = ARENAS[currentChapter.arenaId];

  const handleApplyCode = () => {
    soundEffects.playSuccessChime();
    onLoadChapterCode(currentChapter);
  };

  const handleNext = () => {
    soundEffects.playUiClick();
    if (selectedChapterIndex < ROBO_STORY_CHAPTERS.length - 1) {
      setSelectedChapterIndex(selectedChapterIndex + 1);
    }
  };

  const handlePrev = () => {
    soundEffects.playUiClick();
    if (selectedChapterIndex > 0) {
      setSelectedChapterIndex(selectedChapterIndex - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-900 border border-indigo-500/30 rounded-2xl shadow-2xl shadow-indigo-950/80 overflow-hidden text-slate-100">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 border-b border-indigo-500/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white shadow-md shadow-amber-500/30">
              <BookOpen className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">Petualangan Robo</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  SD / Kelas Robotika
                </span>
              </div>
              <p className="text-xs text-slate-400">Cerita Bergambar & Tutorial Langkah-demi-Langkah Siswa Sekolah Dasar</p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEffects.playUiClick();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chapter Stepper Tab */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-950/70 border-b border-slate-800 overflow-x-auto scrollbar-none">
          {ROBO_STORY_CHAPTERS.map((ch, idx) => {
            const isSelected = idx === selectedChapterIndex;
            return (
              <button
                key={ch.id}
                onClick={() => {
                  soundEffects.playUiClick();
                  setSelectedChapterIndex(idx);
                }}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/30 border border-blue-400/50 scale-[1.02]'
                    : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-700/50'
                }`}
              >
                <span
                  className={`w-5 h-5 rounded-full text-[11px] flex items-center justify-center font-bold ${
                    isSelected ? 'bg-white text-indigo-700' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  {ch.chapterNumber}
                </span>
                <span>Bab {ch.chapterNumber}: {ch.title.split('&')[0].replace('Bangkitlah, ', '')}</span>
              </button>
            );
          })}
        </div>

        {/* Main Content Modal Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Top Story Hero Card with Mascot */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-950/70 via-slate-900 to-blue-950/60 border border-indigo-500/30 p-4 sm:p-5 flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 shadow-inner">
            {/* Mascot Visual */}
            <div className="flex flex-col items-center">
              <RoboMascotSvg mood={currentChapter.mascotMood} />
              <div className="mt-1 flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-500/30">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Sahabat Robo</span>
              </div>
            </div>

            {/* Story & Speech Bubble */}
            <div className="flex-1 space-y-3 text-center sm:text-left">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">
                  Bab {currentChapter.chapterNumber} dari 5
                </span>
                <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 flex items-center gap-1">
                  <Compass className="w-3 h-3 text-indigo-400" />
                  {currentChapter.conceptBadge}
                </span>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  {currentChapter.title}
                </h3>
                <p className="text-xs sm:text-sm text-indigo-200/90 font-medium mt-0.5">
                  {currentChapter.subtitle}
                </p>
              </div>

              {/* Robo's Speech Bubble */}
              <div className="relative bg-slate-800/90 border border-blue-500/30 rounded-2xl p-3 sm:p-4 text-xs sm:text-sm text-blue-100 shadow-sm leading-relaxed">
                <div className="font-semibold text-amber-300 flex items-center gap-1.5 mb-1 text-[11px]">
                  <span>💬 Kata Si Robo:</span>
                </div>
                "{currentChapter.mascotQuote}"
              </div>

              {/* Narrative Story Description */}
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {currentChapter.storyText}
              </p>
            </div>
          </div>

          {/* Two-Column Detail: Learning Goals & Setup Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Learning Goals Card */}
            <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>Target Belajar Komputasi Siswa</span>
              </div>
              <ul className="space-y-2">
                {currentChapter.learningGoals.map((goal, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{goal}</span>
                  </li>
                ))}
              </ul>

              {/* Kid Tip */}
              <div className="pt-2 border-t border-slate-800/80 text-xs text-amber-200/90 font-medium bg-amber-950/20 p-2.5 rounded-lg border border-amber-500/20">
                {currentChapter.kidTip}
              </div>
            </div>

            {/* Arena & Code Action Card */}
            <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-4 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-white uppercase tracking-wider">
                  <span className="flex items-center gap-1.5">
                    <Compass className="w-4 h-4 text-blue-400" />
                    Arena Simulasi 3D Rekomendasi
                  </span>
                  <span className="text-[10px] font-normal text-slate-400">Otomatis Terpilih</span>
                </div>

                <div className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="w-10 h-10 rounded-lg bg-indigo-950 border border-indigo-500/30 flex items-center justify-center text-lg">
                    {currentChapter.arenaId === 'mars_rover'
                      ? '🚀'
                      : currentChapter.arenaId === 'maze'
                      ? '🧱'
                      : currentChapter.arenaId === 'color_track'
                      ? '🚦'
                      : currentChapter.arenaId === 'art'
                      ? '🎨'
                      : '🏁'}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{targetArena?.name || 'Arena Robo'}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{targetArena?.description}</p>
                  </div>
                </div>
              </div>

              {/* Action Button: Load Chapter Starter Blocks */}
              <div className="pt-2">
                <button
                  onClick={handleApplyCode}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-950/60 transition-all cursor-pointer active:scale-98"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Pasang Kode Bab Ini ke Kanvas & Mulai!</span>
                </button>
                <p className="text-[10px] text-center text-slate-400 mt-1.5">
                  Balok kode akan langsung tersusun di editor Blockly Anda.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls (Prev & Next Chapter navigation) */}
        <div className="flex items-center justify-between px-5 py-3 bg-slate-950 border-t border-slate-800 text-xs">
          <button
            onClick={handlePrev}
            disabled={selectedChapterIndex === 0}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
              selectedChapterIndex === 0
                ? 'text-slate-600 cursor-not-allowed'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Bab Sebelumnya</span>
          </button>

          <span className="text-slate-400 font-medium">
            Halaman {selectedChapterIndex + 1} dari {ROBO_STORY_CHAPTERS.length}
          </span>

          <button
            onClick={handleNext}
            disabled={selectedChapterIndex === ROBO_STORY_CHAPTERS.length - 1}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
              selectedChapterIndex === ROBO_STORY_CHAPTERS.length - 1
                ? 'text-slate-600 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow'
            }`}
          >
            <span>Bab Berikutnya</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
