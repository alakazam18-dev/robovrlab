import * as Blockly from 'blockly/core';
import { javascriptGenerator, Order } from 'blockly/javascript';

// Theme Colors
const COLOR_DRIVE = '#2563eb'; // Blue
const COLOR_PEN = '#9333ea';   // Purple
const COLOR_SENSOR = '#059669';// Emerald / Green
const COLOR_TIME = '#ea580c';  // Orange

let isRegistered = false;

export function registerRoboBlocks() {
  if (isRegistered) return;
  isRegistered = true;

  // 1. Move Forward / Backward by distance
  Blockly.Blocks['robot_drive_distance'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('🚗')
        .appendField(
          new Blockly.FieldDropdown([
            ['Maju (Forward)', 'forward'],
            ['Mundur (Backward)', 'backward'],
          ]),
          'DIRECTION'
        )
        .appendField('sejauh')
        .appendField(new Blockly.FieldNumber(20, 1, 5000), 'DISTANCE')
        .appendField(
          new Blockly.FieldDropdown([
            ['cm', 'cm'],
            ['mm', 'mm'],
          ]),
          'UNIT'
        );
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_DRIVE);
      this.setTooltip('Menggerakkan robot maju atau mundur sejauh jarak tertentu');
    },
  };

  javascriptGenerator.forBlock['robot_drive_distance'] = function (block) {
    const direction = block.getFieldValue('DIRECTION');
    const distance = block.getFieldValue('DISTANCE');
    const unit = block.getFieldValue('UNIT');
    const distMm = unit === 'cm' ? Number(distance) * 10 : Number(distance);
    const method = direction === 'forward' ? 'moveForward' : 'moveBackward';
    return `await robot.${method}(${distMm});\n`;
  };

  // 2. Turn Left / Right by degrees
  Blockly.Blocks['robot_turn_angle'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('🔄 Belok')
        .appendField(
          new Blockly.FieldDropdown([
            ['Kanan (Right) ↷', 'right'],
            ['Kiri (Left) ↶', 'left'],
          ]),
          'DIRECTION'
        )
        .appendField('sebesar')
        .appendField(new Blockly.FieldNumber(90, 1, 3600), 'ANGLE')
        .appendField('derajat (°)');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_DRIVE);
      this.setTooltip('Memutar orientasi robot ke kanan atau ke kiri sebesar sudut tertentu');
    },
  };

  javascriptGenerator.forBlock['robot_turn_angle'] = function (block) {
    const direction = block.getFieldValue('DIRECTION');
    const angle = Number(block.getFieldValue('ANGLE'));
    const finalAngle = direction === 'right' ? angle : -angle;
    return `await robot.turnAngle(${finalAngle});\n`;
  };

  // 3. Set Robot Speed
  Blockly.Blocks['robot_set_speed'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('⚡ Atur Kecepatan')
        .appendField(new Blockly.FieldNumber(75, 10, 100), 'SPEED')
        .appendField('%');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_DRIVE);
      this.setTooltip('Mengatur kecepatan motor penggerak robot (10% - 100%)');
    },
  };

  javascriptGenerator.forBlock['robot_set_speed'] = function (block) {
    const speed = block.getFieldValue('SPEED');
    return `robot.setSpeed(${speed});\n`;
  };

  // 4. Drive Continuous
  Blockly.Blocks['robot_drive_continuous'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('🚙 Mulai Jalan')
        .appendField(
          new Blockly.FieldDropdown([
            ['Maju Terus', 'forward'],
            ['Mundur Terus', 'backward'],
          ]),
          'DIRECTION'
        );
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_DRIVE);
      this.setTooltip('Menjalankan robot terus-menerus hingga ada perintah berhenti');
    },
  };

  javascriptGenerator.forBlock['robot_drive_continuous'] = function (block) {
    const dir = block.getFieldValue('DIRECTION');
    return `robot.startDriving('${dir}');\n`;
  };

  // 5. Stop Robot
  Blockly.Blocks['robot_stop'] = {
    init: function () {
      this.appendDummyInput().appendField('🛑 Berhenti (Stop)');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_DRIVE);
      this.setTooltip('Menghentikan semua motor roda robot seketika');
    },
  };

  javascriptGenerator.forBlock['robot_stop'] = function () {
    return `robot.stop();\n`;
  };

  // 6. Pen Down
  Blockly.Blocks['robot_pen_down'] = {
    init: function () {
      this.appendDummyInput().appendField('🖊️ Turunkan Pena (Pen Down)');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_PEN);
      this.setTooltip('Menurunkan pena ke lantai arena untuk mulai menggambar jejak');
    },
  };

  javascriptGenerator.forBlock['robot_pen_down'] = function () {
    return `robot.setPenDown(true);\n`;
  };

  // 7. Pen Up
  Blockly.Blocks['robot_pen_up'] = {
    init: function () {
      this.appendDummyInput().appendField('🖊️ Naikkan Pena (Pen Up)');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_PEN);
      this.setTooltip('Menaikkan pena sehingga tidak menggambar saat robot bergerak');
    },
  };

  javascriptGenerator.forBlock['robot_pen_up'] = function () {
    return `robot.setPenDown(false);\n`;
  };

  // 8. Set Pen Color
  Blockly.Blocks['robot_set_pen_color'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('🎨 Atur Warna Pena')
        .appendField(
          new Blockly.FieldDropdown([
            ['🔴 Merah (Red)', 'red'],
            ['🔵 Biru (Blue)', 'blue'],
            ['🟢 Hijau (Green)', 'green'],
            ['🟡 Kuning (Yellow)', 'yellow'],
            ['🟣 Ungu (Purple)', 'purple'],
            ['⚫ Hitam (Black)', 'black'],
            ['🟠 Oranye (Orange)', 'orange'],
          ]),
          'COLOR'
        );
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_PEN);
      this.setTooltip('Memilih warna tinta pena gambar robot');
    },
  };

  javascriptGenerator.forBlock['robot_set_pen_color'] = function (block) {
    const color = block.getFieldValue('COLOR');
    return `robot.setPenColor('${color}');\n`;
  };

  // 9. Clear Pen Canvas
  Blockly.Blocks['robot_clear_pen'] = {
    init: function () {
      this.appendDummyInput().appendField('🧹 Hapus Jejak Gambar (Clear Pen)');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_PEN);
      this.setTooltip('Membersihkan semua jejak garis pena yang telah digambar');
    },
  };

  javascriptGenerator.forBlock['robot_clear_pen'] = function () {
    return `robot.clearPenTrails();\n`;
  };

  // 10. Sensor: Get Distance (cm)
  Blockly.Blocks['robot_get_distance'] = {
    init: function () {
      this.appendDummyInput().appendField('📡 Jarak Halangan Depan (cm)');
      this.setOutput(true, 'Number');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Mengembalikan nilai jarak sensor ultrasonik depan dalam centimeter (cm)');
    },
  };

  javascriptGenerator.forBlock['robot_get_distance'] = function () {
    return ['robot.getDistanceCm()', Order.FUNCTION_CALL];
  };

  // 11. Sensor: Obstacle condition (less than X cm)
  Blockly.Blocks['robot_obstacle_detected'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('⚠️ Halangan Terdeteksi <')
        .appendField(new Blockly.FieldNumber(25, 5, 200), 'THRESHOLD')
        .appendField('cm');
      this.setOutput(true, 'Boolean');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Benar (true) jika terdapat dinding atau rintangan lebih dekat dari batas jarak');
    },
  };

  javascriptGenerator.forBlock['robot_obstacle_detected'] = function (block) {
    const threshold = block.getFieldValue('THRESHOLD');
    return [`(robot.getDistanceCm() < ${threshold})`, Order.LOGICAL_AND];
  };

  // 12. Sensor: Get Gyro Heading
  Blockly.Blocks['robot_get_heading'] = {
    init: function () {
      this.appendDummyInput().appendField('🧭 Sudut Orientasi / Gyro (°)');
      this.setOutput(true, 'Number');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Mengembalikan sudut hadap robot dari sensor gyro (0° hingga 360°)');
    },
  };

  javascriptGenerator.forBlock['robot_get_heading'] = function () {
    return ['robot.getHeadingDegrees()', Order.FUNCTION_CALL];
  };

  // 13. Sensor: Color Detection
  Blockly.Blocks['robot_detect_color'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('👁️ Sensor Bawah Melihat Warna')
        .appendField(
          new Blockly.FieldDropdown([
            ['Merah (Red)', 'red'],
            ['Hijau (Green)', 'green'],
            ['Biru (Blue)', 'blue'],
            ['Kuning (Yellow)', 'yellow'],
            ['Hitam (Black)', 'black'],
            ['Putih (White)', 'white'],
          ]),
          'TARGET_COLOR'
        );
      this.setOutput(true, 'Boolean');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Benar (true) jika sensor optik bawah mendeteksi warna lantai yang dipilih');
    },
  };

  javascriptGenerator.forBlock['robot_detect_color'] = function (block) {
    const target = block.getFieldValue('TARGET_COLOR');
    return [`(robot.getDetectedColor() === '${target}')`, Order.LOGICAL_AND];
  };

  // 14. Delay / Wait seconds
  Blockly.Blocks['robot_wait_seconds'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('⏳ Tunggu')
        .appendField(new Blockly.FieldNumber(1, 0.1, 60), 'SECONDS')
        .appendField('detik');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_TIME);
      this.setTooltip('Menghentikan eksekusi kode sejenak selama sekian detik');
    },
  };

  javascriptGenerator.forBlock['robot_wait_seconds'] = function (block) {
    const secs = block.getFieldValue('SECONDS');
    return `await robot.sleep(${secs});\n`;
  };

  // 15. Wait Until (Tunggu Sampai Kondisi Terpenuhi)
  Blockly.Blocks['robot_wait_until'] = {
    init: function () {
      this.appendValueInput('CONDITION')
        .setCheck('Boolean')
        .appendField('⏳ Tunggu sampai');
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(COLOR_TIME);
      this.setTooltip('Menunggu sampai kondisi bernilai True sebelum melanjutkan ke blok berikutnya');
    },
  };

  javascriptGenerator.forBlock['robot_wait_until'] = function (block) {
    const condition = javascriptGenerator.valueToCode(block, 'CONDITION', Order.NONE) || 'true';
    return `while (!(${condition})) {\n  await robot.sleep(0.05);\n}\n`;
  };

  // 16. Sensor Compare (Jarak sensor dengan operator pembanding)
  Blockly.Blocks['robot_sensor_compare'] = {
    init: function () {
      this.appendDummyInput()
        .appendField('📡 Jarak sensor')
        .appendField(
          new Blockly.FieldDropdown([
            ['< (Kurang dari)', '<'],
            ['<= (Kurang atau sama)', '<='],
            ['> (Lebih dari)', '>'],
            ['>= (Lebih atau sama)', '>='],
            ['== (Sama dengan)', '==='],
          ]),
          'OP'
        )
        .appendField(new Blockly.FieldNumber(25, 1, 2500), 'VALUE')
        .appendField('cm');
      this.setOutput(true, 'Boolean');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Memeriksa apakah jarak sensor memenuhi batas pembanding');
    },
  };

  javascriptGenerator.forBlock['robot_sensor_compare'] = function (block) {
    const op = block.getFieldValue('OP');
    const val = block.getFieldValue('VALUE');
    return [`(robot.getDistanceCm() ${op} ${val})`, Order.RELATIONAL];
  };

  // 17. Reporter: Nilai Jarak Sensor (Number)
  Blockly.Blocks['robot_distance_value'] = {
    init: function () {
      this.appendDummyInput().appendField('📏 Nilai Jarak Sensor (cm)');
      this.setOutput(true, 'Number');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Mengembalikan nilai angka jarak sensor dalam cm untuk variabel atau matematika');
    },
  };

  javascriptGenerator.forBlock['robot_distance_value'] = function () {
    return ['robot.getDistanceCm()', Order.FUNCTION_CALL];
  };

  // 18. Reporter: Nilai Warna Terdeteksi (String)
  Blockly.Blocks['robot_color_value'] = {
    init: function () {
      this.appendDummyInput().appendField('🎨 Warna Terdeteksi');
      this.setOutput(true, 'String');
      this.setColour(COLOR_SENSOR);
      this.setTooltip('Mengembalikan teks nama warna yang dideteksi oleh sensor optik bawah');
    },
  };

  javascriptGenerator.forBlock['robot_color_value'] = function () {
    return ['robot.getDetectedColor()', Order.FUNCTION_CALL];
  };
}

