import * as Blockly from 'blockly/core';

/**
 * Custom clean Python code generator from Blockly workspace.
 * Generates educational Python code mirroring VEX VR / Python robotics.
 */
export function generatePythonCode(workspace: Blockly.WorkspaceSvg): string {
  const topBlocks = workspace.getTopBlocks(true);
  if (!topBlocks || topBlocks.length === 0) {
    return `# RoboVR Python Program\n# Tambahkan blok pada editor visual untuk membuat program robot.\n\nrobot.stop()\n`;
  }

  const lines: string[] = [
    '# RoboVR STEM Robotics Program',
    '# Dihasilkan dari Visual Blocks / Python Editor',
    '',
  ];

  for (const block of topBlocks) {
    lines.push(generateBlockPython(block, 0));
  }

  return lines.join('\n');
}

function generateBlockPython(block: Blockly.Block | null, indentLevel: number): string {
  if (!block) return '';
  const indent = '    '.repeat(indentLevel);
  let code = '';

  switch (block.type) {
    case 'robot_drive_distance': {
      const dir = block.getFieldValue('DIRECTION');
      const dist = block.getFieldValue('DISTANCE');
      const unit = block.getFieldValue('UNIT');
      const fn = dir === 'forward' ? 'move_forward' : 'move_backward';
      code = `${indent}robot.${fn}(${dist}, "${unit}")\n`;
      break;
    }
    case 'robot_turn_angle': {
      const dir = block.getFieldValue('DIRECTION');
      const angle = block.getFieldValue('ANGLE');
      const fn = dir === 'right' ? 'turn_right' : 'turn_left';
      code = `${indent}robot.${fn}(${angle})\n`;
      break;
    }
    case 'robot_set_speed': {
      const speed = block.getFieldValue('SPEED');
      code = `${indent}robot.set_speed(${speed})\n`;
      break;
    }
    case 'robot_drive_continuous': {
      const dir = block.getFieldValue('DIRECTION');
      code = `${indent}robot.drive_${dir}()\n`;
      break;
    }
    case 'robot_stop': {
      code = `${indent}robot.stop()\n`;
      break;
    }
    case 'robot_pen_down': {
      code = `${indent}robot.pen_down()\n`;
      break;
    }
    case 'robot_pen_up': {
      code = `${indent}robot.pen_up()\n`;
      break;
    }
    case 'robot_set_pen_color': {
      const color = block.getFieldValue('COLOR');
      code = `${indent}robot.set_pen_color("${color}")\n`;
      break;
    }
    case 'robot_clear_pen': {
      code = `${indent}robot.clear_pen()\n`;
      break;
    }
    case 'robot_wait_seconds': {
      const secs = block.getFieldValue('SECONDS');
      code = `${indent}robot.sleep(${secs})\n`;
      break;
    }
    case 'robot_wait_until': {
      const condBlock = block.getInputTargetBlock('CONDITION');
      const cond = condBlock ? generateExpressionPython(condBlock) : 'True';
      code = `${indent}while not (${cond}):\n${indent}    robot.sleep(0.05)\n`;
      break;
    }
    case 'controls_repeat_ext': {
      const timesBlock = block.getInputTargetBlock('TIMES');
      const times = timesBlock ? timesBlock.getFieldValue('NUM') || '4' : '4';
      const body = block.getInputTargetBlock('DO');
      code = `${indent}for step in range(${times}):\n`;
      if (body) {
        code += generateBlockPython(body, indentLevel + 1);
      } else {
        code += `${indent}    pass\n`;
      }
      break;
    }
    case 'controls_whileUntil': {
      const mode = block.getFieldValue('MODE');
      const condBlock = block.getInputTargetBlock('BOOL');
      let condition = condBlock ? generateExpressionPython(condBlock) : 'True';
      if (mode === 'UNTIL') {
        condition = `not (${condition})`;
      }
      const body = block.getInputTargetBlock('DO');
      code = `${indent}while ${condition}:\n`;
      if (body) {
        code += generateBlockPython(body, indentLevel + 1);
      } else {
        code += `${indent}    pass\n`;
      }
      break;
    }
    case 'controls_if': {
      const hasElse = block.getInput('ELSE');
      const condBlock = block.getInputTargetBlock('IF0');
      const cond = condBlock ? generateExpressionPython(condBlock) : 'True';
      const thenBlock = block.getInputTargetBlock('DO0');
      code = `${indent}if ${cond}:\n`;
      if (thenBlock) {
        code += generateBlockPython(thenBlock, indentLevel + 1);
      } else {
        code += `${indent}    pass\n`;
      }
      if (hasElse) {
        const elseBlock = block.getInputTargetBlock('ELSE');
        code += `${indent}else:\n`;
        if (elseBlock) {
          code += generateBlockPython(elseBlock, indentLevel + 1);
        } else {
          code += `${indent}    pass\n`;
        }
      }
      break;
    }
    // Variables
    case 'variables_set': {
      const varName = block.getField('VAR')?.getText() || 'x';
      const valBlock = block.getInputTargetBlock('VALUE');
      const valStr = valBlock ? generateExpressionPython(valBlock) : '0';
      code = `${indent}${varName} = ${valStr}\n`;
      break;
    }
    case 'math_change': {
      const varName = block.getField('VAR')?.getText() || 'x';
      const deltaBlock = block.getInputTargetBlock('DELTA');
      const deltaStr = deltaBlock ? generateExpressionPython(deltaBlock) : '1';
      code = `${indent}${varName} += ${deltaStr}\n`;
      break;
    }
    // Procedures (Modular functions)
    case 'procedures_defnoreturn':
    case 'procedures_defreturn': {
      const funcName = block.getFieldValue('NAME') || 'fungsi_kustom';
      const body = block.getInputTargetBlock('STACK');
      code = `${indent}def ${funcName}():\n`;
      if (body) {
        code += generateBlockPython(body, indentLevel + 1);
      } else {
        code += `${indent}    pass\n`;
      }
      const returnBlock = block.getInputTargetBlock('RETURN');
      if (returnBlock) {
        code += `${indent}    return ${generateExpressionPython(returnBlock)}\n`;
      }
      break;
    }
    case 'procedures_callnoreturn': {
      const funcName = block.getFieldValue('NAME') || 'fungsi_kustom';
      code = `${indent}${funcName}()\n`;
      break;
    }
    default: {
      code = `${indent}# [blok: ${block.type}]\n`;
      break;
    }
  }

  // Chain to next block in the stack
  const nextBlock = block.getNextBlock();
  if (nextBlock) {
    code += generateBlockPython(nextBlock, indentLevel);
  }

  return code;
}

function generateExpressionPython(block: Blockly.Block): string {
  switch (block.type) {
    case 'robot_get_distance':
      return 'robot.get_distance()';
    case 'robot_distance_value':
      return 'robot.get_distance()';
    case 'robot_obstacle_detected': {
      const th = block.getFieldValue('THRESHOLD') || 25;
      return `robot.get_distance() < ${th}`;
    }
    case 'robot_sensor_compare': {
      const op = block.getFieldValue('OP') || '<';
      const val = block.getFieldValue('VALUE') || 25;
      const pyOp = op === '===' ? '==' : op;
      return `robot.get_distance() ${pyOp} ${val}`;
    }
    case 'robot_get_heading':
      return 'robot.get_heading()';
    case 'robot_detect_color': {
      const color = block.getFieldValue('TARGET_COLOR');
      return `robot.get_color() == "${color}"`;
    }
    case 'robot_color_value':
      return 'robot.get_color()';
    case 'logic_boolean':
      return block.getFieldValue('BOOL') === 'TRUE' ? 'True' : 'False';
    case 'math_number':
      return block.getFieldValue('NUM') || '0';
    case 'variables_get':
      return block.getField('VAR')?.getText() || 'x';
    case 'procedures_callreturn': {
      const funcName = block.getFieldValue('NAME') || 'fungsi_kustom';
      return `${funcName}()`;
    }
    case 'logic_operation': {
      const op = block.getFieldValue('OP') === 'OR' ? 'or' : 'and';
      const a = block.getInputTargetBlock('A');
      const b = block.getInputTargetBlock('B');
      const aStr = a ? generateExpressionPython(a) : 'True';
      const bStr = b ? generateExpressionPython(b) : 'True';
      return `(${aStr} ${op} ${bStr})`;
    }
    case 'logic_negate': {
      const target = block.getInputTargetBlock('BOOL');
      const tStr = target ? generateExpressionPython(target) : 'False';
      return `not (${tStr})`;
    }
    case 'logic_compare': {
      const op = block.getFieldValue('OP');
      const left = block.getInputTargetBlock('A');
      const right = block.getInputTargetBlock('B');
      const leftStr = left ? generateExpressionPython(left) : '0';
      const rightStr = right ? generateExpressionPython(right) : '0';
      const opMap: Record<string, string> = {
        EQ: '==',
        NEQ: '!=',
        LT: '<',
        LTE: '<=',
        GT: '>',
        GTE: '>=',
      };
      return `${leftStr} ${opMap[op] || '=='} ${rightStr}`;
    }
    case 'math_arithmetic': {
      const op = block.getFieldValue('OP');
      const a = block.getInputTargetBlock('A');
      const b = block.getInputTargetBlock('B');
      const aStr = a ? generateExpressionPython(a) : '0';
      const bStr = b ? generateExpressionPython(b) : '0';
      const opMap: Record<string, string> = {
        ADD: '+',
        MINUS: '-',
        MULTIPLY: '*',
        DIVIDE: '/',
        POWER: '**',
      };
      return `(${aStr} ${opMap[op] || '+'} ${bStr})`;
    }
    case 'math_modulo': {
      const dividend = block.getInputTargetBlock('DIVIDEND');
      const divisor = block.getInputTargetBlock('DIVISOR');
      const dStr = dividend ? generateExpressionPython(dividend) : '0';
      const divStr = divisor ? generateExpressionPython(divisor) : '1';
      return `(${dStr} % ${divStr})`;
    }
    default:
      return 'True';
  }
}
