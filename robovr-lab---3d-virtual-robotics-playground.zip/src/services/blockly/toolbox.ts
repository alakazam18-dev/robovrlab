export const BLOCKLY_TOOLBOX = {
  kind: 'categoryToolbox',
  contents: [
    {
      kind: 'category',
      name: 'Gerak',
      colour: '#4C97FF', // Scratch Motion Blue
      contents: [
        {
          kind: 'block',
          type: 'robot_drive_distance',
          fields: { DIRECTION: 'forward', DISTANCE: 20, UNIT: 'cm' },
        },
        {
          kind: 'block',
          type: 'robot_turn_angle',
          fields: { DIRECTION: 'right', ANGLE: 90 },
        },
        {
          kind: 'block',
          type: 'robot_set_speed',
          fields: { SPEED: 75 },
        },
        {
          kind: 'block',
          type: 'robot_drive_continuous',
          fields: { DIRECTION: 'forward' },
        },
        {
          kind: 'block',
          type: 'robot_stop',
        },
      ],
    },
    {
      kind: 'category',
      name: 'Pena',
      colour: '#9966FF', // Scratch Looks & Pen Purple
      contents: [
        {
          kind: 'block',
          type: 'robot_pen_down',
        },
        {
          kind: 'block',
          type: 'robot_pen_up',
        },
        {
          kind: 'block',
          type: 'robot_set_pen_color',
          fields: { COLOR: 'red' },
        },
        {
          kind: 'block',
          type: 'robot_clear_pen',
        },
      ],
    },
    {
      kind: 'category',
      name: 'Sensor',
      colour: '#5CB1D6', // Scratch Sensing Cyan/Teal
      contents: [
        {
          kind: 'block',
          type: 'robot_get_distance',
        },
        {
          kind: 'block',
          type: 'robot_sensor_compare',
          fields: { OP: '<', VALUE: 25 },
        },
        {
          kind: 'block',
          type: 'robot_obstacle_detected',
          fields: { THRESHOLD: 25 },
        },
        {
          kind: 'block',
          type: 'robot_get_heading',
        },
        {
          kind: 'block',
          type: 'robot_detect_color',
          fields: { TARGET_COLOR: 'blue' },
        },
        {
          kind: 'block',
          type: 'robot_distance_value',
        },
        {
          kind: 'block',
          type: 'robot_color_value',
        },
      ],
    },
    {
      kind: 'category',
      name: 'Kontrol',
      colour: '#FFAB19', // Scratch Control Amber
      contents: [
        {
          kind: 'block',
          type: 'robot_wait_seconds',
          fields: { SECONDS: 1 },
        },
        {
          kind: 'block',
          type: 'robot_wait_until',
        },
        {
          kind: 'block',
          type: 'controls_repeat_ext',
          inputs: {
            TIMES: {
              shadow: {
                type: 'math_number',
                fields: { NUM: 4 },
              },
            },
          },
        },
        {
          kind: 'block',
          type: 'controls_whileUntil',
        },
        {
          kind: 'block',
          type: 'controls_if',
        },
      ],
    },
    {
      kind: 'category',
      name: 'Operator',
      colour: '#59C059', // Scratch Operators Green
      contents: [
        {
          kind: 'block',
          type: 'logic_compare',
        },
        {
          kind: 'block',
          type: 'logic_operation',
        },
        {
          kind: 'block',
          type: 'logic_negate',
        },
        {
          kind: 'block',
          type: 'logic_boolean',
        },
        {
          kind: 'block',
          type: 'math_number',
          fields: { NUM: 50 },
        },
        {
          kind: 'block',
          type: 'math_arithmetic',
        },
        {
          kind: 'block',
          type: 'math_single',
        },
        {
          kind: 'block',
          type: 'math_round',
        },
        {
          kind: 'block',
          type: 'math_modulo',
        },
        {
          kind: 'block',
          type: 'math_random_int',
          inputs: {
            FROM: {
              shadow: {
                type: 'math_number',
                fields: { NUM: 1 },
              },
            },
            TO: {
              shadow: {
                type: 'math_number',
                fields: { NUM: 100 },
              },
            },
          },
        },
      ],
    },
    {
      kind: 'category',
      name: 'Variabel',
      custom: 'VARIABLE',
      colour: '#FF8C1A', // Scratch Variables Orange
    },
    {
      kind: 'category',
      name: 'Fungsi',
      custom: 'PROCEDURE',
      colour: '#FF6680', // Scratch My Blocks Pink
    },
  ],
};
