export class WebSerialBridge {
  private port: any = null;
  private writer: any = null;
  private reader: any = null;
  private isConnected: boolean = false;
  private onStatusChange?: (connected: boolean, portName?: string) => void;
  private onDataReceived?: (data: string) => void;

  public isSupported(): boolean {
    return typeof navigator !== 'undefined' && 'serial' in navigator;
  }

  public setCallbacks(
    onStatus: (connected: boolean, portName?: string) => void,
    onData?: (data: string) => void
  ) {
    this.onStatusChange = onStatus;
    this.onDataReceived = onData;
  }

  public async connect(baudRate: number = 115200): Promise<boolean> {
    if (!this.isSupported()) {
      throw new Error('Web Serial API tidak didukung pada peramban ini. Gunakan Google Chrome, Microsoft Edge, atau Opera.');
    }

    try {
      // Prompt user to pick Arduino USB port
      const nav = navigator as any;
      this.port = await nav.serial.requestPort();
      await this.port.open({ baudRate });

      const textEncoder = new TextEncoderStream();
      textEncoder.readable.pipeTo(this.port.writable);
      this.writer = textEncoder.writable.getWriter();

      this.isConnected = true;
      if (this.onStatusChange) {
        this.onStatusChange(true, 'Arduino Terhubung (USB)');
      }

      this.readLoop();
      return true;
    } catch (err: any) {
      this.isConnected = false;
      if (this.onStatusChange) {
        this.onStatusChange(false);
      }
      throw err;
    }
  }

  public async sendCommand(command: string): Promise<void> {
    if (!this.isConnected || !this.writer) return;
    try {
      await this.writer.write(command + '\n');
    } catch (err) {
      console.warn('Gagal mengirim data serial ke Arduino:', err);
    }
  }

  public async disconnect(): Promise<void> {
    try {
      if (this.reader) {
        await this.reader.cancel();
      }
      if (this.writer) {
        await this.writer.close();
      }
      if (this.port) {
        await this.port.close();
      }
    } catch (err) {
      console.warn('Error saat menutup port serial:', err);
    } finally {
      this.isConnected = false;
      this.port = null;
      this.writer = null;
      this.reader = null;
      if (this.onStatusChange) {
        this.onStatusChange(false);
      }
    }
  }

  public getConnected(): boolean {
    return this.isConnected;
  }

  private async readLoop() {
    while (this.port && this.port.readable && this.isConnected) {
      const textDecoder = new TextDecoderStream();
      this.port.readable.pipeTo(textDecoder.writable);
      this.reader = textDecoder.readable.getReader();

      try {
        while (true) {
          const { value, done } = await this.reader.read();
          if (done) break;
          if (value && this.onDataReceived) {
            this.onDataReceived(value);
          }
        }
      } catch (err) {
        console.warn('Serial read error:', err);
        break;
      } finally {
        this.reader?.releaseLock();
      }
    }
  }
}

export const serialBridge = new WebSerialBridge();
