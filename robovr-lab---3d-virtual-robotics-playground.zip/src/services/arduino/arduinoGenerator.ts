import { ArduinoPinConfig } from '../../types/arduino';

/**
 * Generates ready-to-compile Arduino .ino sketch from Python or Blockly robot commands.
 * Supports L298N driver and L293D (Shield / Standalone IC).
 */
export function generateArduinoSketch(
  code: string,
  config: ArduinoPinConfig,
  isPython: boolean = true
): string {
  if (config.driverType === 'L293D_SHIELD') {
    return generateL293DShieldSketch(code, config, isPython);
  } else if (config.driverType === 'L293D_IC') {
    return generateL293DICSketch(code, config, isPython);
  } else {
    return generateL298NSketch(code, config, isPython);
  }
}

/**
 * Generates L298N Dual H-Bridge Arduino Sketch
 */
function generateL298NSketch(code: string, cfg: ArduinoPinConfig, isPython: boolean): string {
  const parsedCommands = parseCommandsToArduino(code, isPython);

  return `/*
 * ==============================================================
 *  RoboVR Lab - Arduino Robot Firmware
 *  Hardware: Arduino Uno / Nano
 *  Motor Driver: L298N Dual H-Bridge Module
 * ==============================================================
 */

#include <Servo.h>

// --- PIN ASSIGNMENT (L298N) ---
const int PIN_ENA = ${cfg.leftPwmPin};   // PWM Kecepatan Motor Kiri
const int PIN_IN1 = ${cfg.leftIn1Pin};   // Arah Motor Kiri 1
const int PIN_IN2 = ${cfg.leftIn2Pin};   // Arah Motor Kiri 2

const int PIN_ENB = ${cfg.rightPwmPin};  // PWM Kecepatan Motor Kanan
const int PIN_IN3 = ${cfg.rightIn1Pin};  // Arah Motor Kanan 1
const int PIN_IN4 = ${cfg.rightIn2Pin};  // Arah Motor Kanan 2

// --- SENSOR & ACTUATOR PINS ---
const int PIN_TRIG = ${cfg.trigPin};     // HC-SR04 Ultrasonic Trigger
const int PIN_ECHO = ${cfg.echoPin};     // HC-SR04 Ultrasonic Echo
const int PIN_LINE = ${cfg.sensorPin};   // Sensor Garis / Warna Optik
const int PIN_SERVO = ${cfg.servoPin};   // SG90 Servo Pena Gambar

Servo penServo;
int robotSpeed = 200; // Nilai PWM 0 - 255 (Default ~78%)

void setup() {
  Serial.begin(${cfg.baudRate});
  
  // Konfigurasi Pin Motor
  pinMode(PIN_ENA, OUTPUT);
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  
  pinMode(PIN_ENB, OUTPUT);
  pinMode(PIN_IN3, OUTPUT);
  pinMode(PIN_IN4, OUTPUT);
  
  // Konfigurasi Sensor
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LINE, INPUT);

  // Konfigurasi Servo Pena
  penServo.attach(PIN_SERVO);
  penUp(); // Pena dinaikkan saat awal

  stopRobot();
  delay(1000); // Jeda persiapan 1 detik
  
  Serial.println(F("[RoboVR Lab] Arduino + Driver L298N Siap!"));

  // --- EKSEKUSI PROGRAM ROBOT DARI ROBOVR ---
${parsedCommands}
}

void loop() {
  // Mode Standby setelah instruksi setup selesai
  // Anda juga dapat mengirim perintah via Serial Monitor: F, B, L, R, S
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    if (cmd == 'F') moveForward(200);
    else if (cmd == 'B') moveBackward(200);
    else if (cmd == 'L') turnLeft(90);
    else if (cmd == 'R') turnRight(90);
    else if (cmd == 'S') stopRobot();
    else if (cmd == 'D') penDown();
    else if (cmd == 'U') penUp();
  }
}

// =================== FUNGSI MOTOR PENGGERAK ===================

void setSpeed(int percent) {
  robotSpeed = map(constrain(percent, 0, 100), 0, 100, 80, 255);
}

void moveForward(int distanceMm) {
  analogWrite(PIN_ENA, robotSpeed);
  analogWrite(PIN_ENB, robotSpeed);
  digitalWrite(PIN_IN1, HIGH);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, HIGH);
  digitalWrite(PIN_IN4, LOW);
  
  // Kalibrasi durasi berdasarkan jarak (estimasi ~2.5 ms per mm)
  int duration = distanceMm * 2.5;
  delay(duration);
  stopRobot();
  delay(100);
}

void moveBackward(int distanceMm) {
  analogWrite(PIN_ENA, robotSpeed);
  analogWrite(PIN_ENB, robotSpeed);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, HIGH);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, HIGH);
  
  int duration = distanceMm * 2.5;
  delay(duration);
  stopRobot();
  delay(100);
}

void turnRight(int angleDeg) {
  analogWrite(PIN_ENA, robotSpeed);
  analogWrite(PIN_ENB, robotSpeed);
  digitalWrite(PIN_IN1, HIGH);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, HIGH);
  
  // Kalibrasi putaran poros robot (~6.0 ms per derajat)
  int duration = angleDeg * 6.0;
  delay(duration);
  stopRobot();
  delay(100);
}

void turnLeft(int angleDeg) {
  analogWrite(PIN_ENA, robotSpeed);
  analogWrite(PIN_ENB, robotSpeed);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, HIGH);
  digitalWrite(PIN_IN3, HIGH);
  digitalWrite(PIN_IN4, LOW);
  
  int duration = angleDeg * 6.0;
  delay(duration);
  stopRobot();
  delay(100);
}

void stopRobot() {
  analogWrite(PIN_ENA, 0);
  analogWrite(PIN_ENB, 0);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, LOW);
}

// =================== FUNGSI SENSOR & PENA ===================

long getDistanceCm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  
  long duration = pulseIn(PIN_ECHO, HIGH, 30000); // Timeout 30ms (~5 meter)
  if (duration == 0) return 250; // Tidak ada pantulan
  return duration * 0.034 / 2; // Hitung cm
}

void penDown() {
  penServo.write(45); // Sudut servo saat pena menyentuh lantai
  delay(300);
}

void penUp() {
  penServo.write(110); // Sudut servo saat pena terangkat
  delay(300);
}
`;
}

/**
 * Generates L293D Motor Shield (Adafruit AFMotor Library) Arduino Sketch
 */
function generateL293DShieldSketch(code: string, cfg: ArduinoPinConfig, isPython: boolean): string {
  const parsedCommands = parseCommandsToArduino(code, isPython);

  return `/*
 * ==============================================================
 *  RoboVR Lab - Arduino Robot Firmware
 *  Hardware: Arduino Uno
 *  Motor Driver: L293D Motor Shield (Adafruit AFMotor)
 * ==============================================================
 */

#include <AFMotor.h>
#include <Servo.h>

// Motor 1 (Kiri) dan Motor 2 (Kanan) pada Shield L293D
AF_DCMotor motorLeft(1);
AF_DCMotor motorRight(2);

// Servo 1 pada header shield (Pin 10 / 9)
Servo penServo;
const int PIN_SERVO = ${cfg.servoPin};

// Ultrasonic Sensor HC-SR04
const int PIN_TRIG = ${cfg.trigPin}; // A0
const int PIN_ECHO = ${cfg.echoPin}; // A1

int robotSpeed = 200;

void setup() {
  Serial.begin(${cfg.baudRate});
  
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);

  penServo.attach(PIN_SERVO);
  penUp();

  motorLeft.setSpeed(robotSpeed);
  motorRight.setSpeed(robotSpeed);
  stopRobot();

  delay(1000);
  Serial.println(F("[RoboVR Lab] Arduino + Shield L293D Siap!"));

  // --- EKSEKUSI PROGRAM ROBOT DARI ROBOVR ---
${parsedCommands}
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    if (cmd == 'F') moveForward(200);
    else if (cmd == 'B') moveBackward(200);
    else if (cmd == 'L') turnLeft(90);
    else if (cmd == 'R') turnRight(90);
    else if (cmd == 'S') stopRobot();
    else if (cmd == 'D') penDown();
    else if (cmd == 'U') penUp();
  }
}

void setSpeed(int percent) {
  robotSpeed = map(constrain(percent, 0, 100), 0, 100, 80, 255);
  motorLeft.setSpeed(robotSpeed);
  motorRight.setSpeed(robotSpeed);
}

void moveForward(int distanceMm) {
  motorLeft.run(FORWARD);
  motorRight.run(FORWARD);
  delay(distanceMm * 2.5);
  stopRobot();
  delay(100);
}

void moveBackward(int distanceMm) {
  motorLeft.run(BACKWARD);
  motorRight.run(BACKWARD);
  delay(distanceMm * 2.5);
  stopRobot();
  delay(100);
}

void turnRight(int angleDeg) {
  motorLeft.run(FORWARD);
  motorRight.run(BACKWARD);
  delay(angleDeg * 6.0);
  stopRobot();
  delay(100);
}

void turnLeft(int angleDeg) {
  motorLeft.run(BACKWARD);
  motorRight.run(FORWARD);
  delay(angleDeg * 6.0);
  stopRobot();
  delay(100);
}

void stopRobot() {
  motorLeft.run(RELEASE);
  motorRight.run(RELEASE);
}

long getDistanceCm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long d = pulseIn(PIN_ECHO, HIGH, 30000);
  if (d == 0) return 250;
  return d * 0.034 / 2;
}

void penDown() {
  penServo.write(45);
  delay(300);
}

void penUp() {
  penServo.write(110);
  delay(300);
}
`;
}

/**
 * Generates L293D Standalone IC Arduino Sketch
 */
function generateL293DICSketch(code: string, cfg: ArduinoPinConfig, isPython: boolean): string {
  const parsedCommands = parseCommandsToArduino(code, isPython);

  return `/*
 * ==============================================================
 *  RoboVR Lab - Arduino Robot Firmware
 *  Hardware: Arduino Uno / Nano
 *  Motor Driver: L293D IC Standalone (Dual H-Bridge)
 * ==============================================================
 */

#include <Servo.h>

const int PIN_EN1 = ${cfg.leftPwmPin};   // Pin 1 IC L293D (PWM Kiri)
const int PIN_IN1 = ${cfg.leftIn1Pin};   // Pin 2 IC L293D
const int PIN_IN2 = ${cfg.leftIn2Pin};   // Pin 7 IC L293D

const int PIN_EN2 = ${cfg.rightPwmPin};  // Pin 9 IC L293D (PWM Kanan)
const int PIN_IN3 = ${cfg.rightIn1Pin};  // Pin 10 IC L293D
const int PIN_IN4 = ${cfg.rightIn2Pin};  // Pin 15 IC L293D

const int PIN_TRIG = ${cfg.trigPin};
const int PIN_ECHO = ${cfg.echoPin};
const int PIN_SERVO = ${cfg.servoPin};

Servo penServo;
int robotSpeed = 200;

void setup() {
  Serial.begin(${cfg.baudRate});
  
  pinMode(PIN_EN1, OUTPUT);
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  
  pinMode(PIN_EN2, OUTPUT);
  pinMode(PIN_IN3, OUTPUT);
  pinMode(PIN_IN4, OUTPUT);

  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);

  penServo.attach(PIN_SERVO);
  penUp();

  stopRobot();
  delay(1000);

  // --- EKSEKUSI PROGRAM ROBOT DARI ROBOVR ---
${parsedCommands}
}

void loop() {}

void setSpeed(int percent) {
  robotSpeed = map(constrain(percent, 0, 100), 0, 100, 80, 255);
}

void moveForward(int distanceMm) {
  analogWrite(PIN_EN1, robotSpeed);
  analogWrite(PIN_EN2, robotSpeed);
  digitalWrite(PIN_IN1, HIGH);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, HIGH);
  digitalWrite(PIN_IN4, LOW);
  delay(distanceMm * 2.5);
  stopRobot();
  delay(100);
}

void moveBackward(int distanceMm) {
  analogWrite(PIN_EN1, robotSpeed);
  analogWrite(PIN_EN2, robotSpeed);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, HIGH);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, HIGH);
  delay(distanceMm * 2.5);
  stopRobot();
  delay(100);
}

void turnRight(int angleDeg) {
  analogWrite(PIN_EN1, robotSpeed);
  analogWrite(PIN_EN2, robotSpeed);
  digitalWrite(PIN_IN1, HIGH);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, HIGH);
  delay(angleDeg * 6.0);
  stopRobot();
  delay(100);
}

void turnLeft(int angleDeg) {
  analogWrite(PIN_EN1, robotSpeed);
  analogWrite(PIN_EN2, robotSpeed);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, HIGH);
  digitalWrite(PIN_IN3, HIGH);
  digitalWrite(PIN_IN4, LOW);
  delay(angleDeg * 6.0);
  stopRobot();
  delay(100);
}

void stopRobot() {
  analogWrite(PIN_EN1, 0);
  analogWrite(PIN_EN2, 0);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, LOW);
}

void penDown() {
  penServo.write(45);
  delay(300);
}

void penUp() {
  penServo.write(110);
  delay(300);
}
`;
}

/**
 * Translates student robot script into C++ statements for Arduino setup()
 */
function parseCommandsToArduino(script: string, isPython: boolean): string {
  const lines = script.split('\n');
  const cppLines: string[] = [];

  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || line.startsWith('//')) continue;

    // move_forward / moveForward
    const fwdMatch = line.match(/(?:robot\.)?(?:move_forward|moveForward)\s*\(\s*([^,\)]+)(?:,\s*["'](cm|mm)["'])?\s*\)/);
    if (fwdMatch) {
      const dist = fwdMatch[1];
      const unit = fwdMatch[2] || 'cm';
      const mmVal = unit === 'cm' ? `(${dist}) * 10` : dist;
      cppLines.push(`  moveForward(${mmVal});`);
      continue;
    }

    // move_backward / moveBackward
    const bwdMatch = line.match(/(?:robot\.)?(?:move_backward|moveBackward)\s*\(\s*([^,\)]+)(?:,\s*["'](cm|mm)["'])?\s*\)/);
    if (bwdMatch) {
      const dist = bwdMatch[1];
      const unit = bwdMatch[2] || 'cm';
      const mmVal = unit === 'cm' ? `(${dist}) * 10` : dist;
      cppLines.push(`  moveBackward(${mmVal});`);
      continue;
    }

    // turn_right / turnRight
    const rightMatch = line.match(/(?:robot\.)?(?:turn_right|turnRight)\s*\(\s*([^)]+)\s*\)/);
    if (rightMatch) {
      cppLines.push(`  turnRight(${rightMatch[1]});`);
      continue;
    }

    // turn_left / turnLeft
    const leftMatch = line.match(/(?:robot\.)?(?:turn_left|turnLeft)\s*\(\s*([^)]+)\s*\)/);
    if (leftMatch) {
      cppLines.push(`  turnLeft(${leftMatch[1]});`);
      continue;
    }

    // set_speed / setSpeed
    const speedMatch = line.match(/(?:robot\.)?(?:set_speed|setSpeed)\s*\(\s*([^)]+)\s*\)/);
    if (speedMatch) {
      cppLines.push(`  setSpeed(${speedMatch[1]});`);
      continue;
    }

    // pen_down / penDown
    if (line.includes('pen_down') || line.includes('penDown') || line.includes('setPenDown(true)')) {
      cppLines.push(`  penDown();`);
      continue;
    }

    // pen_up / penUp
    if (line.includes('pen_up') || line.includes('penUp') || line.includes('setPenDown(false)')) {
      cppLines.push(`  penUp();`);
      continue;
    }

    // stop
    if (line.includes('robot.stop()') || line.includes('robot.stop();')) {
      cppLines.push(`  stopRobot();`);
      continue;
    }

    // sleep / delay
    const sleepMatch = line.match(/(?:robot\.|time\.)?sleep\s*\(\s*([^)]+)\s*\)/);
    if (sleepMatch) {
      cppLines.push(`  delay((${sleepMatch[1]}) * 1000);`);
      continue;
    }

    // for loop: for i in range(4):
    const forMatch = line.match(/for\s+([a-zA-Z_]\w*)\s+in\s+range\(([^)]+)\):/);
    if (forMatch) {
      cppLines.push(`  for (int ${forMatch[1]} = 0; ${forMatch[1]} < ${forMatch[2]}; ${forMatch[1]}++) {`);
      continue;
    }

    // Closing brackets or basic JS
    if (line === '}' || line === '{') {
      cppLines.push(`  ${line}`);
      continue;
    }
  }

  if (cppLines.length === 0) {
    return '  // Tambahkan perintah gerak robot di editor\n  moveForward(300);\n  turnRight(90);\n  stopRobot();';
  }

  return cppLines.join('\n');
}

/**
 * Returns complete interactive Dual-Mode Arduino Firmware for Web Serial USB Control
 */
export function getLiveSerialBridgeFirmware(config: ArduinoPinConfig): string {
  return `/*
 * ==============================================================
 *  RoboVR Lab - Direct Web Serial Live Control Firmware
 *  Unggah kode ini ke Arduino Uno/Nano untuk menghubungkan
 *  robot fisik secara langsung via kabel USB / Bluetooth ke browser!
 * ==============================================================
 */

#include <Servo.h>

const int PIN_ENA = ${config.leftPwmPin};
const int PIN_IN1 = ${config.leftIn1Pin};
const int PIN_IN2 = ${config.leftIn2Pin};
const int PIN_ENB = ${config.rightPwmPin};
const int PIN_IN3 = ${config.rightIn1Pin};
const int PIN_IN4 = ${config.rightIn2Pin};
const int PIN_SERVO = ${config.servoPin};
const int PIN_TRIG = ${config.trigPin};
const int PIN_ECHO = ${config.echoPin};

Servo penServo;
int currentSpeed = 200;

void setup() {
  Serial.begin(${config.baudRate});
  
  pinMode(PIN_ENA, OUTPUT);
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_ENB, OUTPUT);
  pinMode(PIN_IN3, OUTPUT);
  pinMode(PIN_IN4, OUTPUT);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);

  penServo.attach(PIN_SERVO);
  penServo.write(110); // Pen Up
  
  analogWrite(PIN_ENA, 0);
  analogWrite(PIN_ENB, 0);

  Serial.println(F("ROBOVR_READY"));
}

void loop() {
  if (Serial.available() > 0) {
    String cmd = Serial.readStringUntil('\\n');
    cmd.trim();
    
    if (cmd.startsWith("FORWARD")) {
      int dist = cmd.substring(8).toInt();
      if (dist == 0) dist = 200;
      drive(1, 1, dist * 2.5);
      Serial.println(F("OK"));
    } else if (cmd.startsWith("BACKWARD")) {
      int dist = cmd.substring(9).toInt();
      if (dist == 0) dist = 200;
      drive(-1, -1, dist * 2.5);
      Serial.println(F("OK"));
    } else if (cmd.startsWith("LEFT")) {
      int deg = cmd.substring(5).toInt();
      if (deg == 0) deg = 90;
      drive(-1, 1, deg * 6.0);
      Serial.println(F("OK"));
    } else if (cmd.startsWith("RIGHT")) {
      int deg = cmd.substring(6).toInt();
      if (deg == 0) deg = 90;
      drive(1, -1, deg * 6.0);
      Serial.println(F("OK"));
    } else if (cmd == "STOP") {
      stopWheels();
      Serial.println(F("OK"));
    } else if (cmd == "PEN_DOWN") {
      penServo.write(45);
      Serial.println(F("OK"));
    } else if (cmd == "PEN_UP") {
      penServo.write(110);
      Serial.println(F("OK"));
    } else if (cmd == "PING_DISTANCE") {
      long d = readSonar();
      Serial.print(F("DIST:"));
      Serial.println(d);
    }
  }
}

void drive(int leftDir, int rightDir, int durationMs) {
  analogWrite(PIN_ENA, currentSpeed);
  analogWrite(PIN_ENB, currentSpeed);

  digitalWrite(PIN_IN1, leftDir > 0 ? HIGH : LOW);
  digitalWrite(PIN_IN2, leftDir < 0 ? HIGH : LOW);
  digitalWrite(PIN_IN3, rightDir > 0 ? HIGH : LOW);
  digitalWrite(PIN_IN4, rightDir < 0 ? HIGH : LOW);

  delay(durationMs);
  stopWheels();
}

void stopWheels() {
  analogWrite(PIN_ENA, 0);
  analogWrite(PIN_ENB, 0);
  digitalWrite(PIN_IN1, LOW);
  digitalWrite(PIN_IN2, LOW);
  digitalWrite(PIN_IN3, LOW);
  digitalWrite(PIN_IN4, LOW);
}

long readSonar() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long dur = pulseIn(PIN_ECHO, HIGH, 30000);
  if (dur == 0) return 250;
  return dur * 0.034 / 2;
}
`;
}
