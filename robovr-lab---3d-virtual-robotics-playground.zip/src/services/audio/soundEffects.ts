/**
 * Web Audio API Sound Synthesizer for RoboVR Virtual Robotics.
 * 100% offline, procedural sound effects for motors, ultrasonic sensors,
 * optical color detector, servo pen, collisions, telemetry boot, and UI feedback.
 */

class SoundEffectsService {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMutedState: boolean = false;
  private volumeLevel: number = 0.5; // 0.0 to 1.0

  // Continuous motor sound state
  private motorOsc1: OscillatorNode | null = null;
  private motorOsc2: OscillatorNode | null = null;
  private motorGain: GainNode | null = null;
  private motorFilter: BiquadFilterNode | null = null;
  private isMotorRunning: boolean = false;
  private currentMotorPitch: number = 110; // Hz

  // Idle standby generator / engine hum state
  private idleOsc1: OscillatorNode | null = null;
  private idleOsc2: OscillatorNode | null = null;
  private idleGain: GainNode | null = null;
  private idleFilter: BiquadFilterNode | null = null;
  private isIdleHumming: boolean = false;

  // Rate limiting / throttling for repetitive sensor triggers
  private lastSonarPingTime: number = 0;
  private lastColorChimeTime: number = 0;
  private lastCollisionTime: number = 0;

  constructor() {
    // Read persisted audio settings from localStorage
    try {
      const savedMute = localStorage.getItem('robovr_sfx_muted');
      if (savedMute !== null) {
        this.isMutedState = savedMute === 'true';
      }
      const savedVol = localStorage.getItem('robovr_sfx_volume');
      if (savedVol !== null) {
        const v = parseFloat(savedVol);
        if (!isNaN(v) && v >= 0 && v <= 1) {
          this.volumeLevel = v;
        }
      }
    } catch {}

    // Attach passive gesture listener to unlock AudioContext cleanly
    if (typeof window !== 'undefined') {
      const unlockAudio = () => {
        this.ensureContext();
        window.removeEventListener('pointerdown', unlockAudio);
        window.removeEventListener('keydown', unlockAudio);
      };
      window.addEventListener('pointerdown', unlockAudio, { passive: true });
      window.addEventListener('keydown', unlockAudio, { passive: true });
    }
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();

      // Master output gain
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(
        this.isMutedState ? 0 : this.volumeLevel,
        this.ctx.currentTime
      );
      this.masterGain.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    return this.ctx;
  }

  public isMuted(): boolean {
    return this.isMutedState;
  }

  public setMuted(muted: boolean): void {
    this.isMutedState = muted;
    try {
      localStorage.setItem('robovr_sfx_muted', String(muted));
    } catch {}

    if (this.ctx && this.masterGain) {
      this.masterGain.gain.setValueAtTime(
        muted ? 0 : this.volumeLevel,
        this.ctx.currentTime
      );
    }

    if (muted) {
      if (this.isMotorRunning) this.stopMotor();
      if (this.isIdleHumming) this.stopIdleHum();
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMutedState);
    if (!this.isMutedState) {
      this.playUiClick();
    }
    return this.isMutedState;
  }

  public getVolume(): number {
    return this.volumeLevel;
  }

  public setVolume(vol: number): void {
    const clamped = Math.max(0, Math.min(1, vol));
    this.volumeLevel = clamped;
    try {
      localStorage.setItem('robovr_sfx_volume', clamped.toFixed(2));
    } catch {}

    if (this.ctx && this.masterGain && !this.isMutedState) {
      this.masterGain.gain.setValueAtTime(clamped, this.ctx.currentTime);
    }
  }

  // ==========================================
  // MOTOR CONTINUOUS AUDIO SYNTHESIS
  // ==========================================

  /**
   * Starts or updates continuous motor hum, pitched according to robot speed.
   */
  public startMotor(speedPercent: number = 75, multiplier: number = 1): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    // Pitch calculation: base gear hum ~85Hz to 180Hz based on speed% and multiplier
    const targetFreq = 80 + (speedPercent / 100) * 80 * Math.min(multiplier, 2);

    if (this.isMotorRunning && this.motorOsc1 && this.motorOsc2 && this.motorGain) {
      // Smoothly glide pitch
      const now = ctx.currentTime;
      this.motorOsc1.frequency.linearRampToValueAtTime(targetFreq, now + 0.1);
      this.motorOsc2.frequency.linearRampToValueAtTime(targetFreq * 1.5, now + 0.1);
      return;
    }

    try {
      const now = ctx.currentTime;
      this.motorFilter = ctx.createBiquadFilter();
      this.motorFilter.type = 'lowpass';
      this.motorFilter.frequency.setValueAtTime(550, now);

      this.motorGain = ctx.createGain();
      this.motorGain.gain.setValueAtTime(0.001, now);
      // Soft ramp up
      this.motorGain.gain.linearRampToValueAtTime(0.18, now + 0.08);

      // Dual oscillator for rich DC gear motor texture
      this.motorOsc1 = ctx.createOscillator();
      this.motorOsc1.type = 'sawtooth';
      this.motorOsc1.frequency.setValueAtTime(targetFreq, now);

      this.motorOsc2 = ctx.createOscillator();
      this.motorOsc2.type = 'triangle';
      this.motorOsc2.frequency.setValueAtTime(targetFreq * 1.5, now);

      this.motorOsc1.connect(this.motorFilter);
      this.motorOsc2.connect(this.motorFilter);
      this.motorFilter.connect(this.motorGain);
      this.motorGain.connect(this.masterGain);

      this.motorOsc1.start(now);
      this.motorOsc2.start(now);
      this.isMotorRunning = true;
      this.currentMotorPitch = targetFreq;
    } catch {
      this.isMotorRunning = false;
    }
  }

  public stopMotor(): void {
    if (!this.isMotorRunning || !this.ctx || !this.motorGain) {
      this.isMotorRunning = false;
      return;
    }

    try {
      const now = this.ctx.currentTime;
      this.motorGain.gain.linearRampToValueAtTime(0.001, now + 0.08);

      const osc1 = this.motorOsc1;
      const osc2 = this.motorOsc2;
      setTimeout(() => {
        try {
          osc1?.stop();
          osc2?.stop();
          osc1?.disconnect();
          osc2?.disconnect();
        } catch {}
      }, 100);

      this.motorOsc1 = null;
      this.motorOsc2 = null;
      this.motorFilter = null;
      this.motorGain = null;
      this.isMotorRunning = false;
    } catch {
      this.isMotorRunning = false;
    }
  }

  // ==========================================
  // IDLE STANDBY ENGINE HUM
  // ==========================================

  /**
   * Starts a very subtle, low-frequency standby hum for the robot chassis.
   * Simulates active power/generator & servo readiness.
   */
  public startIdleHum(): void {
    if (this.isMutedState || this.isMotorRunning || this.isIdleHumming) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    try {
      const now = ctx.currentTime;
      this.idleFilter = ctx.createBiquadFilter();
      this.idleFilter.type = 'lowpass';
      this.idleFilter.frequency.setValueAtTime(160, now);

      this.idleGain = ctx.createGain();
      this.idleGain.gain.setValueAtTime(0.0001, now);
      // Gentle soft fade in to keep it unobtrusive
      this.idleGain.gain.linearRampToValueAtTime(0.045, now + 0.3);

      this.idleOsc1 = ctx.createOscillator();
      this.idleOsc1.type = 'triangle';
      this.idleOsc1.frequency.setValueAtTime(55, now); // Low sub drone

      this.idleOsc2 = ctx.createOscillator();
      this.idleOsc2.type = 'sine';
      this.idleOsc2.frequency.setValueAtTime(110, now); // Harmonic standby tone

      this.idleOsc1.connect(this.idleFilter);
      this.idleOsc2.connect(this.idleFilter);
      this.idleFilter.connect(this.idleGain);
      this.idleGain.connect(this.masterGain);

      this.idleOsc1.start(now);
      this.idleOsc2.start(now);
      this.isIdleHumming = true;
    } catch {
      this.isIdleHumming = false;
    }
  }

  public stopIdleHum(): void {
    if (!this.isIdleHumming || !this.ctx || !this.idleGain) {
      this.isIdleHumming = false;
      return;
    }

    try {
      const now = this.ctx.currentTime;
      this.idleGain.gain.linearRampToValueAtTime(0.0001, now + 0.15);

      const osc1 = this.idleOsc1;
      const osc2 = this.idleOsc2;
      setTimeout(() => {
        try {
          osc1?.stop();
          osc2?.stop();
          osc1?.disconnect();
          osc2?.disconnect();
        } catch {}
      }, 180);

      this.idleOsc1 = null;
      this.idleOsc2 = null;
      this.idleFilter = null;
      this.idleGain = null;
      this.isIdleHumming = false;
    } catch {
      this.isIdleHumming = false;
    }
  }

  // ==========================================
  // DISCRETE ROBOT SOUND EFFECTS
  // ==========================================

  /**
   * Robot Activation / Boot Chirp (ascending futuristic two-tone)
   */
  public playRobotBoot(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);
    osc.frequency.exponentialRampToValueAtTime(1320, now + 0.16);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.2, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  /**
   * Robot Halt / Shutdown Sound (descending power-down tone)
   */
  public playRobotHalt(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    this.stopMotor();

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(500, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.22);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.26);
  }

  /**
   * Reset / Teleport Swoosh Sound
   */
  public playReset(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    this.stopMotor();

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(900, now + 0.18);

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(400, now);
    filter.frequency.exponentialRampToValueAtTime(1400, now + 0.18);
    filter.Q.setValueAtTime(3, now);

    gain.gain.setValueAtTime(0.01, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  /**
   * Mechanical Pen Servo Movement (Down vs Up)
   */
  public playPenServo(down: boolean): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'square';
    if (down) {
      // Down: mechanical descent chirp (720Hz -> 360Hz)
      osc.frequency.setValueAtTime(720, now);
      osc.frequency.exponentialRampToValueAtTime(360, now + 0.09);
    } else {
      // Up: ascend click (360Hz -> 820Hz)
      osc.frequency.setValueAtTime(360, now);
      osc.frequency.exponentialRampToValueAtTime(820, now + 0.09);
    }

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.12, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  /**
   * Ultrasonic Distance Ping (sonar radar pulse)
   * Pitch scales with distance (closer obstacle = higher pitch, 880Hz to 1600Hz)
   */
  public playSonarPing(distanceCm: number): void {
    if (this.isMutedState) return;
    const nowMs = performance.now();
    // Throttle sonar pings so they don't spam during rapid loops
    if (nowMs - this.lastSonarPingTime < 350) return;
    this.lastSonarPingTime = nowMs;

    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    // Map 0-250cm to 1600Hz -> 600Hz
    const clampedDist = Math.max(5, Math.min(250, distanceCm));
    const freq = 1600 - (clampedDist / 250) * 900;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.14);
  }

  /**
   * Optical Color Sensor Chime (musical chime when entering colored zones)
   */
  public playColorChime(colorName: string): void {
    if (this.isMutedState) return;
    const nowMs = performance.now();
    if (nowMs - this.lastColorChimeTime < 400) return;
    this.lastColorChimeTime = nowMs;

    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    // Harmonic bell frequency notes
    const freqMap: Record<string, number> = {
      merah: 523.25, // C5
      red: 523.25,
      hijau: 659.25, // E5
      green: 659.25,
      biru: 783.99, // G5
      blue: 783.99,
      kuning: 880.0, // A5
      yellow: 880.0,
      hitam: 392.0, // G4
      black: 392.0,
      putih: 1046.5, // C6
      white: 1046.5,
    };

    const freq = freqMap[colorName.toLowerCase()] || 659.25;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.18, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.38);
  }

  /**
   * Obstacle Collision Bump & Alert Beep
   */
  public playCollisionBump(): void {
    if (this.isMutedState) return;
    const nowMs = performance.now();
    if (nowMs - this.lastCollisionTime < 600) return;
    this.lastCollisionTime = nowMs;

    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;

    // 1. Heavy physical impact thud (low drop)
    const impactOsc = ctx.createOscillator();
    const impactGain = ctx.createGain();
    impactOsc.type = 'triangle';
    impactOsc.frequency.setValueAtTime(140, now);
    impactOsc.frequency.exponentialRampToValueAtTime(38, now + 0.18);

    impactGain.gain.setValueAtTime(0.35, now);
    impactGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

    impactOsc.connect(impactGain);
    impactGain.connect(this.masterGain);
    impactOsc.start(now);
    impactOsc.stop(now + 0.24);

    // 2. High warning alert beep (staccato)
    const alertOsc = ctx.createOscillator();
    const alertGain = ctx.createGain();
    alertOsc.type = 'square';
    alertOsc.frequency.setValueAtTime(880, now + 0.05);

    alertGain.gain.setValueAtTime(0.001, now);
    alertGain.gain.setValueAtTime(0.12, now + 0.05);
    alertGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    alertOsc.connect(alertGain);
    alertGain.connect(this.masterGain);
    alertOsc.start(now + 0.05);
    alertOsc.stop(now + 0.2);
  }

  /**
   * Victory / Mission Success Fanfare (celebratory 4-note arpeggio C5 -> E5 -> G5 -> C6)
   */
  public playMissionSuccess(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    const startTime = ctx.currentTime;

    notes.forEach((freq, idx) => {
      const noteTime = startTime + idx * 0.11;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.001, noteTime);
      gain.gain.linearRampToValueAtTime(0.22, noteTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.32);

      osc.connect(gain);
      gain.connect(this.masterGain!);

      osc.start(noteTime);
      osc.stop(noteTime + 0.35);
    });
  }

  /**
   * Tactile UI Click / Button Tap Sound
   */
  public playUiClick(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1100, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.03);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.04);
  }

  /**
   * Short motor nudge buzz (e.g. for remote control d-pad step)
   */
  public playMotorStep(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, now);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(450, now);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.1);
  }

  /**
   * Collision Feedback with dual mechanical impact & alert resonance
   */
  public playCollisionFeedback(intensity: number = 1.0): void {
    this.playCollisionBump();
  }

  /**
   * Sparkling success completion chime for mission milestone
   */
  public playSuccessChime(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    // Pentatonic chime bell: E5 -> G#5 -> B5 -> E6
    const freqs = [659.25, 830.61, 987.77, 1318.51];
    const now = ctx.currentTime;

    freqs.forEach((freq, i) => {
      const noteTime = now + i * 0.08;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.001, noteTime);
      gain.gain.linearRampToValueAtTime(0.18, noteTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.45);

      osc.connect(gain);
      gain.connect(this.masterGain!);

      osc.start(noteTime);
      osc.stop(noteTime + 0.5);
    });
  }

  /**
   * Clean camera perspective switch swoop
   */
  public playCameraSwitch(): void {
    if (this.isMutedState) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(740, now + 0.06);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(900, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.07, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(now);
    osc.stop(now + 0.09);
  }
}

export const soundEffects = new SoundEffectsService();
