import { ArenaType } from '../../types/robot';

export interface StoryChapter {
  id: string;
  chapterNumber: number;
  title: string;
  subtitle: string;
  mascotMood: 'happy' | 'thinking' | 'excited' | 'detective' | 'astronaut';
  mascotQuote: string;
  storyText: string;
  conceptBadge: string;
  arenaId: ArenaType;
  learningGoals: string[];
  kidTip: string;
  starterBlocksJson: any;
}

export const ROBO_STORY_CHAPTERS: StoryChapter[] = [
  {
    id: 'ch1_bangkit',
    chapterNumber: 1,
    title: 'Bangkitlah, Si Robo!',
    subtitle: 'Langkah Pertama Menuju Dunia Robotika',
    mascotMood: 'happy',
    mascotQuote: 'Halo kawan cilik! Aku Robo. Hari ini adalah hari pertamaku aktif di laboratorium sekolahmu. Ayo bantu aku melangkah!',
    storyText:
      'Di laboratorium komputer sekolah, sebuah robot kecil lucu dengan dua roda dan lampu neon biru baru saja dinyalakan. Robot ini bernama Robo! Agar Robo bisa berjalan, ia membutuhkan instruksi program dari kita. Komputer menjalankan instruksi langkah demi langkah, persis seperti resep kue! Mari ajari Robo mengatur kecepatan motornya, maju lurus, lalu berbelok!',
    conceptBadge: 'Algoritma Berurutan (Sequencing)',
    arenaId: 'grid',
    learningGoals: [
      'Memahami bahwa robot bekerja menurut urutan instruksi dari atas ke bawah',
      'Mengatur kecepatan motor robot (%)',
      'Menggerakkan robot maju sejauh jarak tertentu (cm)',
      'Memutar orientasi robot ke kanan atau ke kiri (derajat)',
    ],
    kidTip: '💡 Tips Robo: 90 derajat sama dengan sudut siku-siku di pojok bukumu!',
    starterBlocksJson: {
      blocks: {
        languageVersion: 0,
        blocks: [
          {
            type: 'robot_set_speed',
            id: 'ch1_b1',
            x: 40,
            y: 30,
            fields: { SPEED: 80 },
            next: {
              block: {
                type: 'robot_drive_distance',
                id: 'ch1_b2',
                fields: { DIRECTION: 'forward', DISTANCE: 60, UNIT: 'cm' },
                next: {
                  block: {
                    type: 'robot_turn_angle',
                    id: 'ch1_b3',
                    fields: { DIRECTION: 'right', ANGLE: 90 },
                    next: {
                      block: {
                        type: 'robot_drive_distance',
                        id: 'ch1_b4',
                        fields: { DIRECTION: 'forward', DISTANCE: 40, UNIT: 'cm' },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
      },
    },
  },
  {
    id: 'ch2_kuas_ajaib',
    chapterNumber: 2,
    title: 'Kuas Ajaib & Persegi Warna-Warni',
    subtitle: 'Belajar Perulangan (Loop) Sambil Melukis Geometri',
    mascotMood: 'excited',
    mascotQuote: 'Tengok bagian bawah bodiku! Ada pena gambar ajaib. Ayo kita buat gambar persegi rapi untuk pameran kelas!',
    storyText:
      'Guru seni meminta seluruh siswa membuat gambar bentuk geometri. Untungnya, Robo memiliki pena kuas di bawah sasisnya yang bisa dinaikkan atau diturunkan! Untuk menggambar persegi, robot harus maju dan belok sebanyak 4 kali. Daripada menyusun 8 balok kode yang sama, kita bisa memakai blok "Ulangi 4 kali". Keren dan hemat waktu, kan?',
    conceptBadge: 'Perulangan (Loop / Iteration)',
    arenaId: 'art',
    learningGoals: [
      'Menurunkan dan menaikkan pena (Pen Down / Pen Up)',
      'Memilih warna tinta pena yang cerah',
      'Menggunakan blok "Ulangi (Repeat)" untuk mengurangi pengulangan kode manual',
      'Memahami geometri sudut bangun datar 4 sisi (4 x 90° = 360°)',
    ],
    kidTip: '🎨 Coba ganti angka ulangi menjadi 3 dan sudut menjadi 120° untuk membuat Segitiga Sama Sisi!',
    starterBlocksJson: {
      blocks: {
        languageVersion: 0,
        blocks: [
          {
            type: 'robot_set_speed',
            id: 'ch2_b1',
            x: 40,
            y: 30,
            fields: { SPEED: 75 },
            next: {
              block: {
                type: 'robot_set_pen_color',
                id: 'ch2_b2',
                fields: { COLOR: 'blue' },
                next: {
                  block: {
                    type: 'robot_pen_down',
                    id: 'ch2_b3',
                    next: {
                      block: {
                        type: 'controls_repeat_ext',
                        id: 'ch2_b4',
                        inputs: {
                          TIMES: {
                            shadow: {
                              type: 'math_number',
                              id: 'ch2_b5',
                              fields: { NUM: 4 },
                            },
                          },
                          DO: {
                            block: {
                              type: 'robot_drive_distance',
                              id: 'ch2_b6',
                              fields: { DIRECTION: 'forward', DISTANCE: 50, UNIT: 'cm' },
                              next: {
                                block: {
                                  type: 'robot_turn_angle',
                                  id: 'ch2_b7',
                                  fields: { DIRECTION: 'right', ANGLE: 90 },
                                },
                              },
                            },
                          },
                        },
                        next: {
                          block: {
                            type: 'robot_pen_up',
                            id: 'ch2_b8',
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
      },
    },
  },
  {
    id: 'ch3_radar_kelelawar',
    chapterNumber: 3,
    title: 'Radar Kelelawar Ultrasonik',
    subtitle: 'Mendeteksi Halangan & Menghindar Otomatis',
    mascotMood: 'thinking',
    mascotQuote: 'Awas ada balok di depan! Tenang, telinga ultrasonikku bisa mendengar pantulan suara sebelum menabrak!',
    storyText:
      'Di arena halangan terdapat kotak-kotak rintangan yang berserakan. Bagaimana cara robot tidak menabrak tanpa kita kendalikan dengan remote? Jawabannya adalah Sensor Jarak Ultrasonik! Sensor ini memancarkan suara berfrekuensi tinggi (seperti radar kelelawar di gua gelap). Jika jarak benda di depan kurang dari 25 cm, Robo akan langsung berbelok menghindar!',
    conceptBadge: 'Kondisi Logika (If-Else Decision)',
    arenaId: 'maze',
    learningGoals: [
      'Memahami cara kerja sensor ultrasonik pemancar dan penerima gema',
      'Menggunakan blok logika "Jika (If) ... Maka (Else)"',
      'Memprogram robot agar mandiri menghindari rintangan',
      'Memahami batasan jarak aman dalam satuan centimeter (cm)',
    ],
    kidTip: '🦇 Jika robot masih menabrak, coba tambahkan batas jarak aman dari 25 cm menjadi 35 cm!',
    starterBlocksJson: {
      blocks: {
        languageVersion: 0,
        blocks: [
          {
            type: 'robot_set_speed',
            id: 'ch3_b1',
            x: 40,
            y: 30,
            fields: { SPEED: 70 },
            next: {
              block: {
                type: 'controls_repeat_ext',
                id: 'ch3_b2',
                inputs: {
                  TIMES: {
                    shadow: {
                      type: 'math_number',
                      id: 'ch3_b3',
                      fields: { NUM: 8 },
                    },
                  },
                  DO: {
                    block: {
                      type: 'controls_if',
                      id: 'ch3_b4',
                      mutation: { else: 1 },
                      inputs: {
                        IF0: {
                          block: {
                            type: 'robot_sensor_compare',
                            id: 'ch3_b5',
                            fields: { OP: '<', VALUE: 25 },
                          },
                        },
                        DO0: {
                          block: {
                            type: 'robot_turn_angle',
                            id: 'ch3_b6',
                            fields: { DIRECTION: 'right', ANGLE: 90 },
                          },
                        },
                        ELSE: {
                          block: {
                            type: 'robot_drive_distance',
                            id: 'ch3_b7',
                            fields: { DIRECTION: 'forward', DISTANCE: 25, UNIT: 'cm' },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
      },
    },
  },
  {
    id: 'ch4_detektif_warna',
    chapterNumber: 4,
    title: 'Detektif Karpet Warna-Warni',
    subtitle: 'Membaca Warna Lantai dengan Sensor Optik',
    mascotMood: 'detective',
    mascotQuote: 'Lantai ini seperti pelangi! Sensor optik bawahku bisa melihat warna merah, hijau, biru, dan kuning!',
    storyText:
      'Di persimpangan jalan kota virtual, terbentang jalur karpet warna-warni. Robo ditugaskan menjadi detektif patroli cilik! Dengan sensor optik di bagian bawah bodinya, Robo bisa membedakan warna lantai. Ketika mendeteksi warna Hijau (zona aman), Robo akan mencoretkan tinta hijau. Jika mendeteksi warna Merah (zona bahaya), Robo akan berhenti sejenak!',
    conceptBadge: 'Sensor Optik & Pengenalan Pola',
    arenaId: 'color_track',
    learningGoals: [
      'Memahami sensor cahaya/optik bawah untuk mendeteksi warna permukaan',
      'Menggabungkan pembacaan sensor warna dengan aksi pena atau motor',
      'Mengembangkan logika percabangan berdasarkan kondisi warna',
      'Simulasi dasar teknologi mobil otomatis (Autonomous Car / AGV Pabrik)',
    ],
    kidTip: '🔍 Mobil pintar di bandara dan pabrik menggunakan sensor garis warna ini untuk mengantar barang otomatis!',
    starterBlocksJson: {
      blocks: {
        languageVersion: 0,
        blocks: [
          {
            type: 'robot_set_speed',
            id: 'ch4_b1',
            x: 40,
            y: 30,
            fields: { SPEED: 65 },
            next: {
              block: {
                type: 'controls_repeat_ext',
                id: 'ch4_b2',
                inputs: {
                  TIMES: {
                    shadow: {
                      type: 'math_number',
                      id: 'ch4_b3',
                      fields: { NUM: 10 },
                    },
                  },
                  DO: {
                    block: {
                      type: 'robot_drive_distance',
                      id: 'ch4_b4',
                      fields: { DIRECTION: 'forward', DISTANCE: 15, UNIT: 'cm' },
                      next: {
                        block: {
                          type: 'controls_if',
                          id: 'ch4_b5',
                          inputs: {
                            IF0: {
                              block: {
                                type: 'robot_detect_color',
                                id: 'ch4_b6',
                                fields: { TARGET_COLOR: 'green' },
                              },
                            },
                            DO0: {
                              block: {
                                type: 'robot_set_pen_color',
                                id: 'ch4_b7',
                                fields: { COLOR: 'green' },
                                next: {
                                  block: {
                                    type: 'robot_pen_down',
                                    id: 'ch4_b8',
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
      },
    },
  },
  {
    id: 'ch5_jelajah_mars',
    chapterNumber: 5,
    title: 'Penjelajah Planet Mars',
    subtitle: 'Misi Puncak Penjelajahan Antariksa Rover',
    mascotMood: 'astronaut',
    mascotQuote: 'Houston, Robo siap mendarat di Mars! Mari kita jelajahi kawah berbatu dan kumpulkan sampel sains!',
    storyText:
      'Selamat! Kamu dan Robo telah sampai pada tantangan terbesar: Planet Mars! Di planet merah ini, tidak ada jalan aspal halus, melainkan tebing kawah dan batuan angkasa. Gabungkan semua ilmu yang telah kamu pelajari: mengatur laju motor, sensor ultrasonik untuk deteksi batu kawah, dan loop perulangan. Ayo pimpin penjelajahan robotika luar angkasa pertama sekolahmu!',
    conceptBadge: 'Integrasi Multi-Sistem & STEM Antariksa',
    arenaId: 'mars_rover',
    learningGoals: [
      'Mengintegrasikan seluruh sensor dan aktuator robot dalam satu misi utuh',
      'Menerapkan pemikiran komputasional dekomposisi masalah kompleks',
      'Mengenal aplikasi robotika nyata di dunia riset antariksa NASA / BRIN',
      'Menjadi pemrogram robotika cilik yang berani berinovasi',
    ],
    kidTip: '🚀 Kamu adalah insinyur robotika masa depan! Coba modifikasi warnamu menjadi putih astronot di menu Kustom Robot!',
    starterBlocksJson: {
      blocks: {
        languageVersion: 0,
        blocks: [
          {
            type: 'robot_set_speed',
            id: 'ch5_b1',
            x: 40,
            y: 30,
            fields: { SPEED: 85 },
            next: {
              block: {
                type: 'controls_repeat_ext',
                id: 'ch5_b2',
                inputs: {
                  TIMES: {
                    shadow: {
                      type: 'math_number',
                      id: 'ch5_b3',
                      fields: { NUM: 14 },
                    },
                  },
                  DO: {
                    block: {
                      type: 'controls_if',
                      id: 'ch5_b4',
                      mutation: { else: 1 },
                      inputs: {
                        IF0: {
                          block: {
                            type: 'robot_sensor_compare',
                            id: 'ch5_b5',
                            fields: { OP: '<', VALUE: 30 },
                          },
                        },
                        DO0: {
                          block: {
                            type: 'robot_turn_angle',
                            id: 'ch5_b6',
                            fields: { DIRECTION: 'right', ANGLE: 60 },
                          },
                        },
                        ELSE: {
                          block: {
                            type: 'robot_drive_distance',
                            id: 'ch5_b7',
                            fields: { DIRECTION: 'forward', DISTANCE: 25, UNIT: 'cm' },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
      },
    },
  },
];
