import { ArenaConfig, ArenaType } from '../../types/robot';

export const ARENAS: Record<ArenaType, ArenaConfig> = {
  grid: {
    id: 'grid',
    name: 'Grid Map (Peta Koordinat)',
    description: 'Arena berukuran 2000mm x 2000mm dengan petak 200mm untuk latihan navigasi dasar dan koordinat X-Y.',
    widthMm: 2000,
    depthMm: 2000,
    wallHeightMm: 80,
    startPose: { x: -600, y: -600, heading: 0 },
    walls: [
      // Outer perimeter borders
      { x: 0, y: 1000, width: 2040, depth: 40, height: 80, color: '#475569' },
      { x: 0, y: -1000, width: 2040, depth: 40, height: 80, color: '#475569' },
      { x: -1000, y: 0, width: 40, depth: 2040, height: 80, color: '#475569' },
      { x: 1000, y: 0, width: 40, depth: 2040, height: 80, color: '#475569' },
      // Optional obstacle cubes for sonar practice
      { x: 0, y: 200, width: 160, depth: 160, height: 120, color: '#dc2626' },
      { x: 400, y: -400, width: 160, depth: 160, height: 120, color: '#2563eb' },
    ],
    colorZones: [
      { x: -600, y: -600, radius: 150, colorName: 'green', hex: '#22c55e', label: 'START' },
      { x: 600, y: 600, radius: 150, colorName: 'yellow', hex: '#eab308', label: 'FINISH' },
      { x: 0, y: 200, width: 200, depth: 200, colorName: 'red', hex: '#ef4444', label: 'OBSTACLE 1' },
      { x: 400, y: -400, width: 200, depth: 200, colorName: 'blue', hex: '#3b82f6', label: 'OBSTACLE 2' },
    ],
  },

  maze: {
    id: 'maze',
    name: 'Maze / Labirin Rintangan',
    description: 'Labirin dengan koridor berdinding untuk eksplorasi sensor ultrasonik (jarak) dan algoritma penghindar dinding.',
    widthMm: 2000,
    depthMm: 2000,
    wallHeightMm: 120,
    startPose: { x: -750, y: -750, heading: 0 },
    walls: [
      // Outer perimeter borders
      { x: 0, y: 1000, width: 2040, depth: 40, height: 120, color: '#334155' },
      { x: 0, y: -1000, width: 2040, depth: 40, height: 120, color: '#334155' },
      { x: -1000, y: 0, width: 40, depth: 2040, height: 120, color: '#334155' },
      { x: 1000, y: 0, width: 40, depth: 2040, height: 120, color: '#334155' },
      // Interior Maze corridors
      { x: -500, y: -300, width: 40, depth: 900, height: 120, color: '#64748b' },
      { x: -200, y: 200, width: 640, depth: 40, height: 120, color: '#64748b' },
      { x: 100, y: -400, width: 40, depth: 800, height: 120, color: '#64748b' },
      { x: -100, y: -500, width: 440, depth: 40, height: 120, color: '#64748b' },
      { x: 500, y: 100, width: 40, depth: 1000, height: 120, color: '#64748b' },
      { x: 300, y: 600, width: 600, depth: 40, height: 120, color: '#64748b' },
      { x: -600, y: 600, width: 440, depth: 40, height: 120, color: '#64748b' },
    ],
    colorZones: [
      { x: -750, y: -750, radius: 160, colorName: 'green', hex: '#22c55e', label: 'START' },
      { x: 750, y: 750, radius: 180, colorName: 'yellow', hex: '#f59e0b', label: 'GOAL' },
      { x: -200, y: 0, radius: 120, colorName: 'red', hex: '#ef4444', label: 'TRAP' },
      { x: 300, y: -100, radius: 120, colorName: 'blue', hex: '#3b82f6', label: 'CHECKPOINT' },
    ],
  },

  art: {
    id: 'art',
    name: 'Art Canvas (Papan Gambar)',
    description: 'Kanvas putih bersih dengan garis derajat untuk berkreasi menggambar bentuk geometri, bintang, dan pola fraktal.',
    widthMm: 2400,
    depthMm: 2400,
    wallHeightMm: 60,
    startPose: { x: 0, y: 0, heading: 0 },
    walls: [
      // Outer perimeter borders
      { x: 0, y: 1200, width: 2440, depth: 40, height: 60, color: '#cbd5e1' },
      { x: 0, y: -1200, width: 2440, depth: 40, height: 60, color: '#cbd5e1' },
      { x: -1200, y: 0, width: 40, depth: 2440, height: 60, color: '#cbd5e1' },
      { x: 1200, y: 0, width: 40, depth: 2440, height: 60, color: '#cbd5e1' },
    ],
    colorZones: [
      { x: 0, y: 0, radius: 100, colorName: 'white', hex: '#f8fafc', label: 'CENTER' },
      { x: -800, y: 800, radius: 120, colorName: 'red', hex: '#ef4444', label: 'RED TILE' },
      { x: 800, y: 800, radius: 120, colorName: 'blue', hex: '#3b82f6', label: 'BLUE TILE' },
      { x: -800, y: -800, radius: 120, colorName: 'green', hex: '#10b981', label: 'GREEN TILE' },
      { x: 800, y: -800, radius: 120, colorName: 'yellow', hex: '#f59e0b', label: 'YELLOW TILE' },
    ],
  },

  color_track: {
    id: 'color_track',
    name: 'Color Detector & Line Track',
    description: 'Arena khusus dengan zona warna beragam dan lintasan garis gelap untuk menguji Eye/Color sensor robot.',
    widthMm: 2000,
    depthMm: 2000,
    wallHeightMm: 80,
    startPose: { x: -700, y: -700, heading: 0 },
    walls: [
      { x: 0, y: 1000, width: 2040, depth: 40, height: 80, color: '#334155' },
      { x: 0, y: -1000, width: 2040, depth: 40, height: 80, color: '#334155' },
      { x: -1000, y: 0, width: 40, depth: 2040, height: 80, color: '#334155' },
      { x: 1000, y: 0, width: 40, depth: 2040, height: 80, color: '#334155' },
    ],
    colorZones: [
      { x: -700, y: -700, radius: 180, colorName: 'white', hex: '#ffffff', label: 'START' },
      { x: -700, y: 0, width: 280, depth: 280, colorName: 'red', hex: '#ef4444', label: 'ZONE MERAH' },
      { x: -700, y: 700, width: 280, depth: 280, colorName: 'green', hex: '#10b981', label: 'ZONE HIJAU' },
      { x: 0, y: 700, width: 280, depth: 280, colorName: 'blue', hex: '#3b82f6', label: 'ZONE BIRU' },
      { x: 700, y: 700, width: 280, depth: 280, colorName: 'yellow', hex: '#f59e0b', label: 'ZONE KUNING' },
      { x: 700, y: 0, width: 280, depth: 280, colorName: 'red', hex: '#ef4444', label: 'ZONE MERAH 2' },
      { x: 700, y: -700, width: 280, depth: 280, colorName: 'green', hex: '#10b981', label: 'ZONE HIJAU 2' },
      { x: 0, y: -700, width: 280, depth: 280, colorName: 'black', hex: '#1e293b', label: 'ZONE HITAM' },
      { x: 0, y: 0, radius: 220, colorName: 'yellow', hex: '#facc15', label: 'PUSAT TARGET' },
    ],
  },

  mars_rover: {
    id: 'mars_rover',
    name: 'Mars Rover Exploration (Luar Angkasa)',
    description: 'Medan bebatuan planet Mars dengan batuan vulkanik, kawah meteor, dan zona mineral untuk navigasi sensor ultrasonik dan warna.',
    widthMm: 2400,
    depthMm: 2400,
    wallHeightMm: 100,
    startPose: { x: -800, y: -800, heading: 45 },
    walls: [
      // Perimeter Station Barriers
      { x: 0, y: 1200, width: 2440, depth: 40, height: 100, color: '#7c2d12' },
      { x: 0, y: -1200, width: 2440, depth: 40, height: 100, color: '#7c2d12' },
      { x: -1200, y: 0, width: 40, depth: 2440, height: 100, color: '#7c2d12' },
      { x: 1200, y: 0, width: 40, depth: 2440, height: 100, color: '#7c2d12' },
      // Martian Rock Boulders / Obstacles
      { x: 0, y: 200, width: 180, depth: 180, height: 140, color: '#9a3412' },
      { x: -400, y: 300, width: 220, depth: 200, height: 160, color: '#c2410c' },
      { x: 450, y: -300, width: 200, depth: 220, height: 150, color: '#9a3412' },
      { x: -200, y: -350, width: 160, depth: 160, height: 130, color: '#ea580c' },
      { x: 300, y: 600, width: 240, depth: 180, height: 180, color: '#7c2d12' },
      { x: -600, y: 200, width: 170, depth: 170, height: 120, color: '#9a3412' },
    ],
    colorZones: [
      { x: -800, y: -800, radius: 180, colorName: 'green', hex: '#10b981', label: 'BASE CAMP' },
      { x: 800, y: 800, radius: 190, colorName: 'yellow', hex: '#fbbf24', label: 'MINERAL ORE' },
      { x: 0, y: -700, radius: 150, colorName: 'blue', hex: '#38bdf8', label: 'WATER ICE' },
      { x: 600, y: 200, radius: 160, colorName: 'red', hex: '#ef4444', label: 'VOLCANIC SOIL' },
      { x: 0, y: 650, radius: 140, colorName: 'black', hex: '#0f172a', label: 'CRATER PIT' },
    ],
  },

  sumo_arena: {
    id: 'sumo_arena',
    name: 'Ring Pertempuran Sumo (Dohyo)',
    description: 'Arena kompetisi robot sumo melingkar dengan garis batas putih dan balok lawan. Gunakan sensor warna & jarak untuk bertahan di dalam ring!',
    widthMm: 2000,
    depthMm: 2000,
    wallHeightMm: 60,
    startPose: { x: -400, y: 0, heading: 90 },
    walls: [
      // Outer safety boundary
      { x: 0, y: 1000, width: 2040, depth: 40, height: 60, color: '#1e293b' },
      { x: 0, y: -1000, width: 2040, depth: 40, height: 60, color: '#1e293b' },
      { x: -1000, y: 0, width: 40, depth: 2040, height: 60, color: '#1e293b' },
      { x: 1000, y: 0, width: 40, depth: 2040, height: 60, color: '#1e293b' },
      // Opponent Sumo Robot Dummy Target (in center right)
      { x: 350, y: 0, width: 160, depth: 160, height: 130, color: '#dc2626' },
      // Corner referee pylons
      { x: -750, y: -750, width: 80, depth: 80, height: 160, color: '#f59e0b' },
      { x: 750, y: 750, width: 80, depth: 80, height: 160, color: '#f59e0b' },
      { x: -750, y: 750, width: 80, depth: 80, height: 160, color: '#f59e0b' },
      { x: 750, y: -750, width: 80, depth: 80, height: 160, color: '#f59e0b' },
    ],
    colorZones: [
      // Central Dohyo circle zone
      { x: 0, y: 0, radius: 750, colorName: 'black', hex: '#0f172a', label: 'DOHYO RING' },
      // Center start mark
      { x: 0, y: 0, radius: 120, colorName: 'red', hex: '#ef4444', label: 'CENTER' },
      // Player start line
      { x: -400, y: 0, width: 60, depth: 240, colorName: 'blue', hex: '#3b82f6', label: 'PLAYER' },
      // Opponent start line
      { x: 350, y: 0, width: 60, depth: 240, colorName: 'red', hex: '#dc2626', label: 'OPPONENT' },
      // Outer ring warning boundary tiles
      { x: 0, y: 750, width: 260, depth: 50, colorName: 'white', hex: '#ffffff', label: 'TAWARA N' },
      { x: 0, y: -750, width: 260, depth: 50, colorName: 'white', hex: '#ffffff', label: 'TAWARA S' },
      { x: 750, y: 0, width: 50, depth: 260, colorName: 'white', hex: '#ffffff', label: 'TAWARA E' },
      { x: -750, y: 0, width: 50, depth: 260, colorName: 'white', hex: '#ffffff', label: 'TAWARA W' },
    ],
  },
};

