import { ArenaType, RobotCustomizationConfig } from '../../types/robot';

export interface RoboVRProjectFile {
  format: 'robovr-project';
  version: 1;
  name: string;
  savedAt: string;
  arenaId: ArenaType;
  activeLanguage: 'block' | 'python';
  blocklyState?: any;
  pythonCode: string;
  robotCustomization?: RobotCustomizationConfig;
}

/**
 * Downloads the project data as a .robovr file to the user's computer.
 */
export function exportProjectToFile(
  projectName: string,
  projectData: {
    arenaId: ArenaType;
    activeLanguage: 'block' | 'python';
    blocklyState?: any;
    pythonCode: string;
    robotCustomization?: RobotCustomizationConfig;
  }
): string {
  const sanitizedName = (projectName || 'proyek-robotika-sd')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_');

  const fileName = sanitizedName.endsWith('.robovr')
    ? sanitizedName
    : `${sanitizedName}.robovr`;

  const payload: RoboVRProjectFile = {
    format: 'robovr-project',
    version: 1,
    name: projectName || 'Proyek Robotika SD',
    savedAt: new Date().toISOString(),
    arenaId: projectData.arenaId,
    activeLanguage: projectData.activeLanguage,
    blocklyState: projectData.blocklyState,
    pythonCode: projectData.pythonCode,
    robotCustomization: projectData.robotCustomization,
  };

  const jsonString = JSON.stringify(payload, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 1000);

  return fileName;
}

/**
 * Reads and validates a .robovr or .json project file from user input.
 */
export async function importProjectFromFile(file: File): Promise<RoboVRProjectFile> {
  const text = await file.text();
  let parsed: any;
  try {
    parsed = JSON.parse(text);
  } catch (err) {
    throw new Error('Format file tidak valid. Pastikan file berformat .robovr atau .json yang benar.');
  }

  // Basic validation
  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('Isi file proyek kosong atau tidak dikenali.');
  }

  // Validate or normalize fields
  const project: RoboVRProjectFile = {
    format: 'robovr-project',
    version: parsed.version || 1,
    name: parsed.name || file.name.replace(/\.(robovr|json)$/i, ''),
    savedAt: parsed.savedAt || new Date().toISOString(),
    arenaId: parsed.arenaId || 'grid',
    activeLanguage: parsed.activeLanguage === 'python' ? 'python' : 'block',
    blocklyState: parsed.blocklyState || parsed.blocks || null,
    pythonCode: typeof parsed.pythonCode === 'string' ? parsed.pythonCode : '',
    robotCustomization: parsed.robotCustomization || undefined,
  };

  return project;
}
