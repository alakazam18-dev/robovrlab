import * as THREE from 'three';
import { DEFAULT_ROBOT_CUSTOMIZATION, RobotCustomizationConfig } from '../../types/robot';

export interface Robot3DComponents {
  root: THREE.Group;
  leftWheel: THREE.Mesh;
  rightWheel: THREE.Mesh;
  penMesh: THREE.Group;
  sonarEyes: THREE.Group;
  sensorBeam: THREE.Mesh;
  statusLed: THREE.Mesh;
  colorSensorLens: THREE.Mesh;
  neonGlow?: THREE.Mesh;
  headlights?: THREE.Group;
}

/**
 * Creates a high-fidelity procedural STEM Robot model (THREE.Group)
 * Supports dynamic customization: Body Type (Cyber / Scout / Tank),
 * Chassis color, Top Plate color, Neon Underglow, and Headlights.
 */
export function createRobot3DModel(
  customization: RobotCustomizationConfig = DEFAULT_ROBOT_CUSTOMIZATION
): Robot3DComponents {
  const root = new THREE.Group();
  root.name = 'VirtualRobot';

  const chassisColorHex = new THREE.Color(customization.chassisColor);
  const topPlateColorHex = new THREE.Color(customization.topPlateColor);
  const neonColorHex = customization.neonUnderglowColor !== 'none'
    ? new THREE.Color(customization.neonUnderglowColor)
    : null;

  // 1. Chassis Main Base Hull
  const chassisGeo = new THREE.BoxGeometry(1.4, 0.35, 1.6);
  const chassisMat = new THREE.MeshStandardMaterial({
    color: chassisColorHex,
    roughness: 0.35,
    metalness: 0.3,
  });
  const chassis = new THREE.Mesh(chassisGeo, chassisMat);
  chassis.position.y = 0.45;
  chassis.castShadow = true;
  chassis.receiveShadow = true;
  root.add(chassis);

  // 1b. Top Cover Plate (Custom Accent Color)
  const topCoverGeo = new THREE.BoxGeometry(1.2, 0.1, 1.3);
  const topCoverMat = new THREE.MeshStandardMaterial({
    color: topPlateColorHex,
    roughness: 0.25,
    metalness: 0.7,
  });
  const topCover = new THREE.Mesh(topCoverGeo, topCoverMat);
  topCover.position.set(0, 0.65, -0.05);
  topCover.castShadow = true;
  root.add(topCover);

  // 1c. Microcontroller Brain Screen
  const screenGeo = new THREE.PlaneGeometry(0.7, 0.5);
  const screenMat = new THREE.MeshBasicMaterial({
    color: 0x0284c7,
  });
  const screen = new THREE.Mesh(screenGeo, screenMat);
  screen.rotation.x = -Math.PI / 2;
  screen.position.set(0, 0.71, -0.05);
  root.add(screen);

  // 2. Body-Type Specific Additions (Cyber vs Scout vs Tank)
  if (customization.bodyType === 'cyber') {
    // Cyber Cruiser: Aerodynamic rear spoiler + angular side skirts
    const spoilerWingGeo = new THREE.BoxGeometry(1.3, 0.05, 0.25);
    const spoilerWingMat = new THREE.MeshStandardMaterial({
      color: topPlateColorHex,
      metalness: 0.8,
      roughness: 0.2,
    });
    const spoiler = new THREE.Mesh(spoilerWingGeo, spoilerWingMat);
    spoiler.position.set(0, 0.95, -0.7);

    // Left & Right spoiler struts
    const strutGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.35);
    const strutMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9 });
    const strutL = new THREE.Mesh(strutGeo, strutMat);
    strutL.position.set(-0.45, 0.78, -0.7);
    const strutR = new THREE.Mesh(strutGeo, strutMat);
    strutR.position.set(0.45, 0.78, -0.7);

    root.add(spoiler);
    root.add(strutL);
    root.add(strutR);
  } else if (customization.bodyType === 'scout') {
    // Mars Scout Rover: Radar communication mast & solar array panel
    const mastGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.65, 8);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });
    const mast = new THREE.Mesh(mastGeo, mastMat);
    mast.position.set(0.4, 0.95, -0.4);
    root.add(mast);

    // Parabolic antenna dish
    const dishGeo = new THREE.SphereGeometry(0.2, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2);
    dishGeo.rotateX(Math.PI / 3);
    const dishMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.9,
      roughness: 0.2,
      side: THREE.DoubleSide,
    });
    const dish = new THREE.Mesh(dishGeo, dishMat);
    dish.position.set(0.4, 1.28, -0.4);
    root.add(dish);

    // Solar panel array on roof
    const solarGeo = new THREE.BoxGeometry(0.5, 0.04, 0.6);
    const solarMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a, // Deep solar blue
      roughness: 0.1,
      metalness: 0.9,
    });
    const solar = new THREE.Mesh(solarGeo, solarMat);
    solar.position.set(-0.25, 0.72, -0.05);
    root.add(solar);
  } else if (customization.bodyType === 'tank') {
    // Heavy Tank: Front wedge bulldozer pusher & heavy armor side guards
    const wedgeShape = new THREE.Shape();
    wedgeShape.moveTo(-0.7, 0);
    wedgeShape.lineTo(0.7, 0);
    wedgeShape.lineTo(0.5, 0.3);
    wedgeShape.lineTo(-0.5, 0.3);
    wedgeShape.closePath();

    const wedgeGeo = new THREE.BoxGeometry(1.5, 0.25, 0.2);
    const wedgeMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.8,
      roughness: 0.4,
    });
    const frontArmor = new THREE.Mesh(wedgeGeo, wedgeMat);
    frontArmor.position.set(0, 0.38, 0.88);
    root.add(frontArmor);

    // Side track guard plates
    const guardGeo = new THREE.BoxGeometry(0.08, 0.3, 1.5);
    const guardMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7 });
    const guardL = new THREE.Mesh(guardGeo, guardMat);
    guardL.position.set(-0.95, 0.45, 0.1);
    const guardR = new THREE.Mesh(guardGeo, guardMat);
    guardR.position.set(0.95, 0.45, 0.1);
    root.add(guardL);
    root.add(guardR);
  }

  // 3. Wheels (Left and Right Drive Wheels)
  const wheelRadius = 0.4;
  const wheelThickness = 0.18;
  const wheelGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelThickness, 24);
  wheelGeo.rotateZ(Math.PI / 2);

  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.85,
    metalness: 0.05,
  });

  const rimGeo = new THREE.CylinderGeometry(wheelRadius * 0.6, wheelRadius * 0.6, wheelThickness + 0.02, 16);
  rimGeo.rotateZ(Math.PI / 2);
  const rimMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.2,
    metalness: 0.85,
  });

  // Left Wheel Group
  const leftWheelGroup = new THREE.Group();
  const leftTire = new THREE.Mesh(wheelGeo, tireMat);
  leftTire.castShadow = true;
  const leftRim = new THREE.Mesh(rimGeo, rimMat);
  leftWheelGroup.add(leftTire);
  leftWheelGroup.add(leftRim);
  leftWheelGroup.position.set(-0.8, wheelRadius, 0.1);
  root.add(leftWheelGroup);

  // Right Wheel Group
  const rightWheelGroup = new THREE.Group();
  const rightTire = new THREE.Mesh(wheelGeo, tireMat);
  rightTire.castShadow = true;
  const rightRim = new THREE.Mesh(rimGeo, rimMat);
  rightWheelGroup.add(rightTire);
  rightWheelGroup.add(rightRim);
  rightWheelGroup.position.set(0.8, wheelRadius, 0.1);
  root.add(rightWheelGroup);

  // 4. Front Omni-Directional Caster Ball / Wheel
  const casterHousingGeo = new THREE.CylinderGeometry(0.18, 0.22, 0.2, 16);
  const casterHousingMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.4,
    metalness: 0.5,
  });
  const casterHousing = new THREE.Mesh(casterHousingGeo, casterHousingMat);
  casterHousing.position.set(0, 0.25, 0.7);
  root.add(casterHousing);

  const casterBallGeo = new THREE.SphereGeometry(0.15, 16, 16);
  const casterBallMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.1,
    metalness: 0.95,
  });
  const casterBall = new THREE.Mesh(casterBallGeo, casterBallMat);
  casterBall.position.set(0, 0.15, 0.7);
  casterBall.castShadow = true;
  root.add(casterBall);

  // 5. Ultrasonic Distance Sensor ("Sonar Eyes") on front bumper
  const sonarEyes = new THREE.Group();
  sonarEyes.position.set(0, 0.45, 0.82);

  const sonarBaseGeo = new THREE.BoxGeometry(0.7, 0.25, 0.1);
  const sonarBaseMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.4,
    metalness: 0.3,
  });
  const sonarBase = new THREE.Mesh(sonarBaseGeo, sonarBaseMat);
  sonarEyes.add(sonarBase);

  // Dual transducer cylinders
  const transducerGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.12, 16);
  transducerGeo.rotateX(Math.PI / 2);
  const transducerMat = new THREE.MeshStandardMaterial({
    color: 0xcbd5e1,
    roughness: 0.2,
    metalness: 0.9,
  });
  const leftEye = new THREE.Mesh(transducerGeo, transducerMat);
  leftEye.position.set(-0.2, 0, 0.05);
  sonarEyes.add(leftEye);

  const rightEye = new THREE.Mesh(transducerGeo, transducerMat);
  rightEye.position.set(0.2, 0, 0.05);
  sonarEyes.add(rightEye);
  root.add(sonarEyes);

  // 5b. Ultrasonic Sensing Cone Visualizer (Ray Beam)
  const beamGeo = new THREE.ConeGeometry(0.6, 2.5, 16, 1, true);
  beamGeo.rotateX(-Math.PI / 2);
  beamGeo.translate(0, 0, 1.25);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.18,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const sensorBeam = new THREE.Mesh(beamGeo, beamMat);
  sensorBeam.position.set(0, 0.45, 0.85);
  root.add(sensorBeam);

  // 6. Down-facing Optical / Color Sensor (Bottom Eye)
  const colorSensorHousingGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.15, 16);
  const colorSensorHousingMat = new THREE.MeshStandardMaterial({
    color: 0x020617,
    roughness: 0.5,
  });
  const colorSensor = new THREE.Mesh(colorSensorHousingGeo, colorSensorHousingMat);
  colorSensor.position.set(0, 0.12, 0.35);
  root.add(colorSensor);

  // Optical illuminated lens at the bottom
  const lensGeo = new THREE.CircleGeometry(0.09, 16);
  lensGeo.rotateX(Math.PI / 2);
  const colorSensorLensMat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
  });
  const colorSensorLens = new THREE.Mesh(lensGeo, colorSensorLensMat);
  colorSensorLens.position.set(0, 0.04, 0.35);
  root.add(colorSensorLens);

  // 7. Central Pen Mechanism
  const penGroup = new THREE.Group();
  penGroup.position.set(0, 0.5, -0.4);

  const sleeveGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.5, 16);
  const sleeveMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    metalness: 0.8,
    roughness: 0.2,
  });
  const sleeve = new THREE.Mesh(sleeveGeo, sleeveMat);
  penGroup.add(sleeve);

  const markerGeo = new THREE.CylinderGeometry(0.045, 0.02, 0.45, 16);
  const markerMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    roughness: 0.3,
  });
  const marker = new THREE.Mesh(markerGeo, markerMat);
  marker.name = 'penMarker';
  marker.position.y = -0.1;
  penGroup.add(marker);
  root.add(penGroup);

  // 8. Status LED on top
  const ledGeo = new THREE.SphereGeometry(0.07, 16, 16);
  const ledMat = new THREE.MeshStandardMaterial({
    color: 0x22c55e,
    emissive: 0x22c55e,
    emissiveIntensity: 0.8,
    roughness: 0.2,
  });
  const statusLed = new THREE.Mesh(ledGeo, ledMat);
  statusLed.position.set(0, 0.73, 0.45);
  root.add(statusLed);

  // 9. Direction Arrow Decal on roof
  const arrowShape = new THREE.Shape();
  arrowShape.moveTo(0, 0.25);
  arrowShape.lineTo(0.18, -0.15);
  arrowShape.lineTo(0.06, -0.1);
  arrowShape.lineTo(0.06, -0.25);
  arrowShape.lineTo(-0.06, -0.25);
  arrowShape.lineTo(-0.06, -0.1);
  arrowShape.lineTo(-0.18, -0.15);
  arrowShape.closePath();

  const arrowGeo = new THREE.ShapeGeometry(arrowShape);
  arrowGeo.rotateX(-Math.PI / 2);
  const arrowMat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
  });
  const arrow = new THREE.Mesh(arrowGeo, arrowMat);
  arrow.position.set(0, 0.71, 0.15);
  root.add(arrow);

  // 10. Neon Underglow (Emissive Belly Tray)
  let neonGlowMesh: THREE.Mesh | undefined;
  if (neonColorHex) {
    const neonTrayGeo = new THREE.PlaneGeometry(1.3, 1.5);
    neonTrayGeo.rotateX(-Math.PI / 2);
    const neonTrayMat = new THREE.MeshBasicMaterial({
      color: neonColorHex,
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide,
    });
    neonGlowMesh = new THREE.Mesh(neonTrayGeo, neonTrayMat);
    neonGlowMesh.position.y = 0.08;
    root.add(neonGlowMesh);

    // Soft point light below robot
    const neonLight = new THREE.PointLight(neonColorHex.getHex(), 1.2, 3);
    neonLight.position.set(0, 0.15, 0);
    root.add(neonLight);
  }

  // 11. Headlights Accessories (Dual Forward Beams)
  let headlightsGroup: THREE.Group | undefined;
  if (customization.headlightsEnabled) {
    headlightsGroup = new THREE.Group();
    headlightsGroup.position.set(0, 0.45, 0.85);

    const bulbGeo = new THREE.SphereGeometry(0.06, 12, 12);
    const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const bulbL = new THREE.Mesh(bulbGeo, bulbMat);
    bulbL.position.set(-0.48, 0, 0);
    const bulbR = new THREE.Mesh(bulbGeo, bulbMat);
    bulbR.position.set(0.48, 0, 0);
    headlightsGroup.add(bulbL);
    headlightsGroup.add(bulbR);

    // Projected light cones
    const beamConeGeo = new THREE.ConeGeometry(0.45, 2.8, 16, 1, true);
    beamConeGeo.rotateX(-Math.PI / 2);
    beamConeGeo.translate(0, 0, 1.4);
    const beamConeMat = new THREE.MeshBasicMaterial({
      color: 0xfef08a, // Soft warm white beam
      transparent: true,
      opacity: 0.15,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const beamConeL = new THREE.Mesh(beamConeGeo, beamConeMat);
    beamConeL.position.set(-0.48, 0, 0);
    const beamConeR = new THREE.Mesh(beamConeGeo, beamConeMat);
    beamConeR.position.set(0.48, 0, 0);
    headlightsGroup.add(beamConeL);
    headlightsGroup.add(beamConeR);

    root.add(headlightsGroup);
  }

  // 12. Contact Ground Shadow
  const shadowGeo = new THREE.PlaneGeometry(1.8, 2.0);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.35,
    depthWrite: false,
  });
  const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
  contactShadow.position.y = 0.01;
  root.add(contactShadow);

  return {
    root,
    leftWheel: leftTire,
    rightWheel: rightTire,
    penMesh: penGroup,
    sonarEyes,
    sensorBeam,
    statusLed,
    colorSensorLens,
    neonGlow: neonGlowMesh,
    headlights: headlightsGroup,
  };
}
