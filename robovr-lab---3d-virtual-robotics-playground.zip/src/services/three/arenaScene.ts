import * as THREE from 'three';
import { ArenaConfig, PenTrailPoint } from '../../types/robot';

export class ArenaSceneBuilder {
  private arenaGroup: THREE.Group;
  private wallsGroup: THREE.Group;
  private floorMesh!: THREE.Mesh;
  private penTrailsGroup: THREE.Group;

  constructor() {
    this.arenaGroup = new THREE.Group();
    this.arenaGroup.name = 'ArenaGroup';

    this.wallsGroup = new THREE.Group();
    this.arenaGroup.add(this.wallsGroup);

    this.penTrailsGroup = new THREE.Group();
    this.arenaGroup.add(this.penTrailsGroup);
  }

  public getGroup(): THREE.Group {
    return this.arenaGroup;
  }

  public buildArena(config: ArenaConfig, maxAnisotropy: number = 4) {
    // Clear previous walls & pen
    while (this.wallsGroup.children.length > 0) {
      const child = this.wallsGroup.children[0] as THREE.Mesh;
      child.geometry.dispose();
      if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
      else child.material.dispose();
      this.wallsGroup.remove(child);
    }
    this.clearPenTrails();

    if (this.floorMesh) {
      this.floorMesh.geometry.dispose();
      if (Array.isArray(this.floorMesh.material)) this.floorMesh.material.forEach((m) => m.dispose());
      else this.floorMesh.material.dispose();
      this.arenaGroup.remove(this.floorMesh);
    }

    // 1. Build Floor
    const widthUnits = config.widthMm / 100; // 1 unit = 100mm = 10cm
    const depthUnits = config.depthMm / 100;
    const floorGeo = new THREE.PlaneGeometry(widthUnits, depthUnits);
    floorGeo.rotateX(-Math.PI / 2);

    const floorTexture = this.generateFloorTexture(config, maxAnisotropy);
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTexture,
      roughness: config.id === 'mars_rover' ? 0.9 : config.id === 'art' ? 0.4 : 0.65,
      metalness: config.id === 'mars_rover' ? 0.05 : 0.15,
    });
    this.floorMesh = new THREE.Mesh(floorGeo, floorMat);
    this.floorMesh.receiveShadow = true;
    this.arenaGroup.add(this.floorMesh);

    // 2. Build Walls / Obstacles with specialized geometry
    for (const wall of config.walls) {
      const w = wall.width / 100;
      const d = wall.depth / 100;
      const h = wall.height / 100;
      const posX = wall.x / 100;
      const posY = h / 2;
      const posZ = -wall.y / 100;

      // Special procedural rocky boulder mesh for Mars Rover interior obstacles
      const isPerimeter = Math.abs(wall.x) >= config.widthMm / 2 - 40 || Math.abs(wall.y) >= config.depthMm / 2 - 40;
      if (config.id === 'mars_rover' && !isPerimeter) {
        // Procedural rock boulder
        const radius = Math.max(w, d) * 0.55;
        const boulderGeo = new THREE.DodecahedronGeometry(radius, 1);
        const boulderMat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(wall.color || '#9a3412'),
          roughness: 0.95,
          metalness: 0.05,
          flatShading: true,
        });
        const boulder = new THREE.Mesh(boulderGeo, boulderMat);
        boulder.position.set(posX, radius * 0.85, posZ);
        boulder.rotation.set((posX % 2) * 0.5, (posZ % 3) * 0.8, (posX * posZ) % 1);
        boulder.scale.set(1, 0.8, 1);
        boulder.castShadow = true;
        boulder.receiveShadow = true;
        this.wallsGroup.add(boulder);
      } else if (config.id === 'sumo_arena' && !isPerimeter && wall.color === '#dc2626') {
        // Sumo Robot Dummy Target (Aggressive metallic combat block)
        const dummyGeo = new THREE.BoxGeometry(w, h, d);
        const dummyMat = new THREE.MeshStandardMaterial({
          color: 0xdc2626,
          roughness: 0.3,
          metalness: 0.7,
        });
        const dummy = new THREE.Mesh(dummyGeo, dummyMat);
        dummy.position.set(posX, posY, posZ);
        dummy.castShadow = true;
        dummy.receiveShadow = true;

        // Add warning stripes on top
        const capGeo = new THREE.BoxGeometry(w * 0.8, 0.05, d * 0.8);
        const capMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.9, roughness: 0.2 });
        const cap = new THREE.Mesh(capGeo, capMat);
        cap.position.set(posX, posY + h / 2 + 0.02, posZ);
        this.wallsGroup.add(dummy);
        this.wallsGroup.add(cap);
      } else {
        // Standard wall with beveled appearance
        const geo = new THREE.BoxGeometry(w, h, d);
        const mat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(wall.color || '#475569'),
          roughness: 0.35,
          metalness: isPerimeter ? 0.6 : 0.3,
        });
        const wallMesh = new THREE.Mesh(geo, mat);
        wallMesh.position.set(posX, posY, posZ);
        wallMesh.castShadow = true;
        wallMesh.receiveShadow = true;
        this.wallsGroup.add(wallMesh);
      }
    }

    // 3. Build Color Zones (rendered slightly above floor to prevent z-fighting)
    for (const zone of config.colorZones) {
      if (zone.radius) {
        const rUnits = zone.radius / 100;
        const discGeo = new THREE.CircleGeometry(rUnits, 48);
        discGeo.rotateX(-Math.PI / 2);
        const discMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color(zone.hex),
          depthWrite: false,
          transparent: true,
          opacity: 0.85,
        });
        discMat.polygonOffset = true;
        discMat.polygonOffsetFactor = -1;
        discMat.polygonOffsetUnits = -1;

        const disc = new THREE.Mesh(discGeo, discMat);
        disc.position.set(zone.x / 100, 0.015, -zone.y / 100);
        this.wallsGroup.add(disc);
      } else if (zone.width && zone.depth) {
        const wUnits = zone.width / 100;
        const dUnits = zone.depth / 100;
        const rectGeo = new THREE.PlaneGeometry(wUnits, dUnits);
        rectGeo.rotateX(-Math.PI / 2);
        const rectMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color(zone.hex),
          depthWrite: false,
          transparent: true,
          opacity: 0.85,
        });
        rectMat.polygonOffset = true;
        rectMat.polygonOffsetFactor = -1;
        rectMat.polygonOffsetUnits = -1;

        const rectMesh = new THREE.Mesh(rectGeo, rectMat);
        rectMesh.position.set(zone.x / 100, 0.015, -zone.y / 100);
        this.wallsGroup.add(rectMesh);
      }
    }
  }

  public updatePenTrails(trails: PenTrailPoint[]) {
    // Clear existing
    this.clearPenTrails();
    if (trails.length < 2) return;

    // Group contiguous segments by color
    let currentSegment: THREE.Vector3[] = [];
    let currentColor = trails[0]?.color || 'red';

    const renderSegment = (pts: THREE.Vector3[], color: string) => {
      if (pts.length < 2) return;
      const curve = new THREE.CatmullRomCurve3(pts);
      const tubeGeo = new THREE.TubeGeometry(curve, Math.max(pts.length * 2, 4), 0.045, 8, false);
      const tubeMat = new THREE.MeshBasicMaterial({
        color: this.parseColorToHex(color),
      });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      this.penTrailsGroup.add(tube);
    };

    for (let i = 0; i < trails.length; i++) {
      const pt = trails[i];
      const pos = new THREE.Vector3(pt.x / 100, 0.035, -pt.y / 100);

      if (pt.isNewSegment || (pt.color !== currentColor && currentSegment.length > 0)) {
        if (currentSegment.length >= 2) {
          renderSegment(currentSegment, currentColor);
        }
        currentSegment = [pos];
        currentColor = pt.color;
      } else {
        currentSegment.push(pos);
      }
    }

    if (currentSegment.length >= 2) {
      renderSegment(currentSegment, currentColor);
    }
  }

  public clearPenTrails() {
    while (this.penTrailsGroup.children.length > 0) {
      const child = this.penTrailsGroup.children[0] as THREE.Mesh;
      child.geometry.dispose();
      if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
      else child.material.dispose();
      this.penTrailsGroup.remove(child);
    }
  }

  private parseColorToHex(colorName: string): number {
    switch (colorName.toLowerCase()) {
      case 'red':
        return 0xef4444;
      case 'blue':
        return 0x3b82f6;
      case 'green':
        return 0x10b981;
      case 'yellow':
        return 0xf59e0b;
      case 'purple':
        return 0x9333ea;
      case 'black':
        return 0x1e293b;
      case 'orange':
        return 0xf97316;
      default:
        return 0xef4444;
    }
  }

  private generateFloorTexture(config: ArenaConfig, maxAnisotropy: number): THREE.CanvasTexture {
    const size = 1024;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    if (config.id === 'mars_rover') {
      // 🚀 MARS ROVER EXPLORATION TERRAIN
      // Base reddish terra-cotta Martian regolith
      const grad = ctx.createRadialGradient(size / 2, size / 2, 50, size / 2, size / 2, size * 0.7);
      grad.addColorStop(0, '#c2410c');
      grad.addColorStop(0.5, '#9a3412');
      grad.addColorStop(1, '#7c2d12');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, size, size);

      // Procedural fine dust / crater rings
      ctx.strokeStyle = 'rgba(254, 215, 170, 0.15)';
      ctx.lineWidth = 2;
      for (let r = 80; r < size; r += 90) {
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Crater rings
      const craters = [
        { x: size * 0.3, y: size * 0.35, r: 65 },
        { x: size * 0.75, y: size * 0.25, r: 85 },
        { x: size * 0.25, y: size * 0.75, r: 50 },
        { x: size * 0.65, y: size * 0.7, r: 75 },
      ];

      for (const cr of craters) {
        ctx.beginPath();
        ctx.arc(cr.x, cr.y, cr.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(67, 20, 7, 0.45)';
        ctx.fill();
        ctx.strokeStyle = 'rgba(234, 88, 12, 0.4)';
        ctx.lineWidth = 4;
        ctx.stroke();
      }

      // Rover coordinate landing grid (thin futuristic HUD lines)
      ctx.strokeStyle = 'rgba(254, 215, 170, 0.22)';
      ctx.lineWidth = 1;
      const step = size / 12;
      for (let x = 0; x <= size; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, size);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, x);
        ctx.lineTo(size, x);
        ctx.stroke();
      }

      // Base camp landing pad markings
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.strokeRect(size * 0.08, size * 0.08, size * 0.2, size * 0.2);

      ctx.fillStyle = '#fed7aa';
      ctx.font = 'bold 16px monospace';
      ctx.fillText('MARS EXPEDITION ZONE - QUADRANT A-4', 30, size - 25);
    } else if (config.id === 'sumo_arena') {
      // 🥋 SUMO BATTLE RING (DOHYO)
      // Dark perimeter floor outside the ring
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, size, size);

      // Dohyo Ring Clay Platform
      const cx = size / 2;
      const cy = size / 2;
      const ringRadius = (750 / 1000) * (size / 2); // 750mm radius out of 1000mm half-width

      // Central Dohyo base
      const dohyoGrad = ctx.createRadialGradient(cx, cy, 30, cx, cy, ringRadius);
      dohyoGrad.addColorStop(0, '#1e293b');
      dohyoGrad.addColorStop(0.85, '#0f172a');
      dohyoGrad.addColorStop(1, '#020617');
      ctx.fillStyle = dohyoGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius, 0, Math.PI * 2);
      ctx.fill();

      // Outer White Warning Tawara Ring (Ring boundary)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius, 0, Math.PI * 2);
      ctx.stroke();

      // Inner danger zone indicator
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius - 20, 0, Math.PI * 2);
      ctx.stroke();

      // Shikiri-sen (Start Lines for 2 sumo robots)
      ctx.fillStyle = '#ffffff';
      // Left player start line
      ctx.fillRect(cx - 180, cy - 40, 15, 80);
      // Right player start line
      ctx.fillRect(cx + 165, cy - 40, 15, 80);

      // Center red circle
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(cx, cy, 22, 0, Math.PI * 2);
      ctx.fill();

      // Header Labels
      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 15px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🥋 ROBOT SUMO DOHYO RING', cx, 40);
      ctx.font = '12px sans-serif';
      ctx.fillText('BAHAYA JATUH DI LUAR GARIS PUTIH (OUT OF BOUNDS)', cx, size - 35);
    } else if (config.id === 'art') {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, size, size);

      // Light grid
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      const step = size / 24;
      for (let x = 0; x <= size; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, size);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, x);
        ctx.lineTo(size, x);
        ctx.stroke();
      }

      // Compass degrees concentric rings in center
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(size / 2, size / 2, 80, 0, Math.PI * 2);
      ctx.arc(size / 2, size / 2, 160, 0, Math.PI * 2);
      ctx.arc(size / 2, size / 2, 240, 0, Math.PI * 2);
      ctx.stroke();

      // Degree tick marks
      ctx.fillStyle = '#64748b';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('0° N', size / 2, size / 2 - 175);
      ctx.fillText('90° E', size / 2 + 180, size / 2);
      ctx.fillText('180° S', size / 2, size / 2 + 175);
      ctx.fillText('270° W', size / 2 - 180, size / 2);
    } else {
      // Dark Slate Arena (VEX VR Style)
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, size, size);

      // Grid squares (200mm each)
      const numCells = 10;
      const cellSize = size / numCells;

      for (let r = 0; r < numCells; r++) {
        for (let c = 0; c < numCells; c++) {
          const isEven = (r + c) % 2 === 0;
          ctx.fillStyle = isEven ? '#1e293b' : '#182234';
          ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);

          // Grid lines
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(c * cellSize, r * cellSize, cellSize, cellSize);
        }
      }

      // Axis lines in center
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(size / 2, 0);
      ctx.lineTo(size / 2, size);
      ctx.moveTo(0, size / 2);
      ctx.lineTo(size, size / 2);
      ctx.stroke();

      // Coordinate indicators
      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('(0, 0)', size / 2 + 25, size / 2 + 20);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = maxAnisotropy;
    return texture;
  }
}
