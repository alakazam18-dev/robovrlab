/**
 * Lightweight client-side Python transpiler for educational robotics code.
 * Transforms Python robot instructions, loops, conditions, functions, and variables into runnable async JS.
 */
export function transpilePythonToAsyncJS(pythonCode: string): string {
  const lines = pythonCode.split('\n');
  const jsLines: string[] = [];
  const indentStack: number[] = [0];
  const declaredVariables = new Set<string>();
  const definedFunctions = new Set<string>();

  // Pass 1: collect user-defined functions
  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    const funcMatch = trimmed.match(/^def\s+([a-zA-Z_]\w*)\s*\(/);
    if (funcMatch) {
      definedFunctions.add(funcMatch[1]);
    }
  }

  for (let rawLine of lines) {
    const trimmedRight = rawLine.trimEnd();
    if (!trimmedRight.trim()) {
      continue; // Skip empty lines
    }

    const leadingSpaces = rawLine.search(/\S/);
    const line = trimmedRight.trim();

    // Ignore comment-only lines
    if (line.startsWith('#')) {
      jsLines.push(`// ${line.substring(1).trim()}`);
      continue;
    }

    // Check if indentation decreased -> close blocks
    while (indentStack.length > 1 && leadingSpaces < indentStack[indentStack.length - 1]) {
      indentStack.pop();
      jsLines.push('}');
    }

    // Transpile line contents
    let converted = convertPythonStatement(line, declaredVariables, definedFunctions);

    // If line ended with colon (Python block header like for/while/if/def/else)
    if (line.endsWith(':')) {
      indentStack.push(leadingSpaces + 4);
      converted += ' {';
    }

    jsLines.push(converted);
  }

  // Close any remaining open blocks
  while (indentStack.length > 1) {
    indentStack.pop();
    jsLines.push('}');
  }

  return jsLines.join('\n');
}

function convertPythonStatement(
  line: string,
  declaredVars: Set<string>,
  definedFuncs: Set<string>
): string {
  let s = line;

  const isBlockHeader = s.endsWith(':');
  if (isBlockHeader) {
    s = s.slice(0, -1).trim();
  }

  // Common Python replacements
  s = s.replace(/\bTrue\b/g, 'true');
  s = s.replace(/\bFalse\b/g, 'false');
  s = s.replace(/\band\b/g, '&&');
  s = s.replace(/\bor\b/g, '||');
  s = s.replace(/\bnot\s+/g, '!');

  // Handle for loop: for i in range(N): or for i in range(start, stop):
  const forRangeMatch = s.match(/^for\s+([a-zA-Z_]\w*)\s+in\s+range\(([^)]+)\)$/);
  if (forRangeMatch) {
    const varName = forRangeMatch[1];
    declaredVars.add(varName);
    const args = forRangeMatch[2].split(',').map((x) => x.trim());
    if (args.length === 1) {
      return `for (let ${varName} = 0; ${varName} < ${args[0]}; ${varName}++)`;
    } else if (args.length === 2) {
      return `for (let ${varName} = ${args[0]}; ${varName} < ${args[1]}; ${varName}++)`;
    }
  }

  // Handle while loop
  if (s.startsWith('while ')) {
    const cond = s.substring(6).trim();
    return `while (${convertExpressions(cond)})`;
  }

  // Handle elif
  if (s.startsWith('elif ')) {
    const cond = s.substring(5).trim();
    return `} else if (${convertExpressions(cond)})`;
  }

  // Handle if
  if (s.startsWith('if ')) {
    const cond = s.substring(3).trim();
    return `if (${convertExpressions(cond)})`;
  }

  // Handle else
  if (s === 'else') {
    return `} else`;
  }

  // Handle def my_func():
  if (s.startsWith('def ')) {
    const funcRest = s.substring(4).trim();
    const funcNameMatch = funcRest.match(/^([a-zA-Z_]\w*)/);
    if (funcNameMatch) {
      definedFuncs.add(funcNameMatch[1]);
    }
    return `async function ${funcRest}`;
  }

  // Handle pass / break / continue / return
  if (s === 'pass') return '// pass';
  if (s === 'break') return 'break;';
  if (s === 'continue') return 'continue;';
  if (s.startsWith('return ') || s === 'return') return `${s};`;

  // Handle variable assignment: var_name = expression
  const assignMatch = s.match(/^([a-zA-Z_]\w*)\s*=\s*(.+)$/);
  if (assignMatch && !s.startsWith('robot.') && !s.startsWith('return')) {
    const varName = assignMatch[1];
    const valExpr = convertRobotCalls(convertExpressions(assignMatch[2]));
    if (!declaredVars.has(varName)) {
      declaredVars.add(varName);
      return `let ${varName} = ${valExpr};`;
    } else {
      return `${varName} = ${valExpr};`;
    }
  }

  // Handle user defined function calls: my_func() -> await my_func()
  for (const fn of definedFuncs) {
    const fnRegex = new RegExp(`^${fn}\\s*\\((.*)\\)$`);
    if (fnRegex.test(s)) {
      s = `await ${s}`;
      break;
    }
  }

  // Convert robot action calls to async calls
  s = convertRobotCalls(s);

  if (!s.endsWith(';') && !isBlockHeader && !s.startsWith('//') && !s.startsWith('}')) {
    s += ';';
  }

  return s;
}

function convertRobotCalls(statement: string): string {
  let s = statement;

  // robot.move_forward(50, "cm") -> await robot.moveForward(500)
  s = s.replace(/robot\.move_forward\(\s*([^,\)]+)(?:,\s*["'](cm|mm)["'])?\s*\)/g, (_, dist, unit) => {
    const multiplier = unit === 'mm' ? 1 : 10;
    return `await robot.moveForward((${dist}) * ${multiplier})`;
  });

  // robot.move_backward(50, "cm") -> await robot.moveBackward(500)
  s = s.replace(/robot\.move_backward\(\s*([^,\)]+)(?:,\s*["'](cm|mm)["'])?\s*\)/g, (_, dist, unit) => {
    const multiplier = unit === 'mm' ? 1 : 10;
    return `await robot.moveBackward((${dist}) * ${multiplier})`;
  });

  // robot.turn_right(90) -> await robot.turnRight(90)
  s = s.replace(/robot\.turn_right\(\s*([^)]+)\)/g, 'await robot.turnRight($1)');

  // robot.turn_left(90) -> await robot.turnLeft(90)
  s = s.replace(/robot\.turn_left\(\s*([^)]+)\)/g, 'await robot.turnLeft($1)');

  // robot.sleep(sec) or time.sleep(sec)
  s = s.replace(/(?:robot|time)\.sleep\(\s*([^)]+)\)/g, 'await robot.sleep($1)');

  // robot.drive_forward()
  s = s.replace(/robot\.drive_forward\(\)/g, "robot.startDriving('forward')");
  s = s.replace(/robot\.drive_backward\(\)/g, "robot.startDriving('backward')");

  // robot.set_speed(x)
  s = s.replace(/robot\.set_speed\(\s*([^)]+)\)/g, 'robot.setSpeed($1)');

  // robot.pen_down()
  s = s.replace(/robot\.pen_down\(\)/g, 'robot.penDown()');

  // robot.pen_up()
  s = s.replace(/robot\.pen_up\(\)/g, 'robot.penUp()');

  // robot.set_pen_color("red")
  s = s.replace(/robot\.set_pen_color\(\s*([^)]+)\)/g, 'robot.setPenColor($1)');

  // robot.clear_pen()
  s = s.replace(/robot\.clear_pen\(\)/g, 'robot.clearPen()');

  // robot.stop()
  s = s.replace(/robot\.stop\(\)/g, 'robot.stop()');

  return s;
}

function convertExpressions(expr: string): string {
  let e = expr;
  e = e.replace(/robot\.get_distance\(\)/g, 'robot.getDistance()');
  e = e.replace(/robot\.get_heading\(\)/g, 'robot.getHeading()');
  e = e.replace(/robot\.get_color\(\)/g, 'robot.getColor()');
  return e;
}
