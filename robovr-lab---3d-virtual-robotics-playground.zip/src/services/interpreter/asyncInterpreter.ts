import { ArenaConfig, PenTrailPoint, RobotPose, RobotTelemetry, SimulationSpeed } from '../../types/robot';
import { serialBridge } from '../arduino/webSerialBridge';
import { soundEffects } from '../audio/soundEffects';

export class RobotSimulationEngine {
  private pose: RobotPose;
  private targetPose: RobotPose;
  private arena: ArenaConfig;
  private speedPercent: number = 75; // 10 to 100
  private simulationSpeed: SimulationSpeed = 1;
  private penDown: boolean = false;
  private penColor: string = 'red';
  private penWidth: number = 3;
  private penTrails: PenTrailPoint[] = [];

  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private isCancelled: boolean = false;
  private pauseResolver: (() => void) | null = null;

  private continuousDriveDirection: 'forward' | 'backward' | null = null;
  private continuousInterval: any = null;
  private distanceMm: number = 1000;
  private detectedColor: string = 'white';
  private colorHex: string = '#ffffff';
  private isColliding: boolean = false;
  private lastChimedColor: string = 'white';

  private onTelemetryUpdate?: (telemetry: RobotTelemetry) => void;
  private onPenUpdate?: (trails: PenTrailPoint[]) => void;
  private onStateChange?: (state: 'idle' | 'running' | 'paused' | 'stopped' | 'completed' | 'error', errorMsg?: string) => void;

  constructor(arena: ArenaConfig) {
    this.arena = arena;
    this.pose = { ...arena.startPose };
    this.targetPose = { ...arena.startPose };
    this.updateSensors();
  }

  public setArena(arena: ArenaConfig) {
    this.arena = arena;
    this.resetPose();
  }

  public resetPose() {
    this.stop();
    soundEffects.playReset();
    this.pose = { ...this.arena.startPose };
    this.targetPose = { ...this.arena.startPose };
    this.continuousDriveDirection = null;
    this.penTrails = [];
    this.updateSensors();
    this.broadcastTelemetry();
    this.broadcastPen();
  }

  public setSpeedMultiplier(speed: SimulationSpeed) {
    this.simulationSpeed = speed;
  }

  public setCallbacks(
    onTelemetry: (telemetry: RobotTelemetry) => void,
    onPen: (trails: PenTrailPoint[]) => void,
    onState: (state: 'idle' | 'running' | 'paused' | 'stopped' | 'completed' | 'error', errorMsg?: string) => void
  ) {
    this.onTelemetryUpdate = onTelemetry;
    this.onPenUpdate = onPen;
    this.onStateChange = onState;
    this.broadcastTelemetry();
    this.broadcastPen();
  }

  public getTelemetry(): RobotTelemetry {
    return {
      pose: { ...this.pose },
      speedPercent: this.speedPercent,
      distanceMm: Math.round(this.distanceMm),
      detectedColor: this.detectedColor,
      colorHex: this.colorHex,
      penDown: this.penDown,
      penColor: this.penColor,
      penWidth: this.penWidth,
      isColliding: this.isColliding,
      leftMotorSpeed: this.speedPercent,
      rightMotorSpeed: this.speedPercent,
    };
  }

  public getTrails(): PenTrailPoint[] {
    return this.penTrails;
  }

  private broadcastTelemetry() {
    if (this.onTelemetryUpdate) {
      this.onTelemetryUpdate(this.getTelemetry());
    }
  }

  private broadcastPen() {
    if (this.onPenUpdate) {
      this.onPenUpdate([...this.penTrails]);
    }
  }

  public pause() {
    if (this.isRunning && !this.isPaused) {
      this.isPaused = true;
      if (this.onStateChange) this.onStateChange('paused');
    }
  }

  public resume() {
    if (this.isRunning && this.isPaused) {
      this.isPaused = false;
      if (this.pauseResolver) {
        this.pauseResolver();
        this.pauseResolver = null;
      }
      if (this.onStateChange) this.onStateChange('running');
    }
  }

  public stop() {
    soundEffects.stopMotor();
    if (this.continuousInterval) {
      clearInterval(this.continuousInterval);
      this.continuousInterval = null;
    }
    if (this.isRunning) {
      soundEffects.playRobotHalt();
    }
    this.isCancelled = true;
    this.isRunning = false;
    this.isPaused = false;
    this.continuousDriveDirection = null;
    if (this.pauseResolver) {
      this.pauseResolver();
      this.pauseResolver = null;
    }
    if (this.onStateChange) this.onStateChange('stopped');
  }

  private async checkYield(): Promise<void> {
    if (this.isCancelled) {
      throw new Error('EXECUTION_HALTED');
    }
    if (this.isPaused) {
      await new Promise<void>((resolve) => {
        this.pauseResolver = resolve;
      });
      if (this.isCancelled) throw new Error('EXECUTION_HALTED');
    }
  }

  // --- Robot Action API Methods (Called by interpreter) ---

  public async moveForward(distanceMm: number): Promise<void> {
    if (serialBridge.getConnected()) {
      serialBridge.sendCommand(`FORWARD ${Math.round(distanceMm)}`);
    }
    await this.driveLinear(distanceMm, 1);
  }

  public async moveBackward(distanceMm: number): Promise<void> {
    if (serialBridge.getConnected()) {
      serialBridge.sendCommand(`BACKWARD ${Math.round(distanceMm)}`);
    }
    await this.driveLinear(distanceMm, -1);
  }

  public async turnAngle(degrees: number): Promise<void> {
    if (serialBridge.getConnected()) {
      if (degrees > 0) serialBridge.sendCommand(`RIGHT ${Math.round(degrees)}`);
      else serialBridge.sendCommand(`LEFT ${Math.abs(Math.round(degrees))}`);
    }
    await this.turnAngular(degrees);
  }

  public setSpeed(speed: number) {
    this.speedPercent = Math.max(10, Math.min(100, Math.round(speed)));
    this.broadcastTelemetry();
  }

  public startDriving(direction: 'forward' | 'backward') {
    this.continuousDriveDirection = direction;
    soundEffects.startMotor(this.speedPercent, this.simulationSpeed);
    if (serialBridge.getConnected()) {
      serialBridge.sendCommand(direction === 'forward' ? 'FORWARD 2000' : 'BACKWARD 2000');
    }

    if (this.continuousInterval) {
      clearInterval(this.continuousInterval);
      this.continuousInterval = null;
    }

    const sign = direction === 'forward' ? 1 : -1;
    let lastTime = performance.now();

    this.continuousInterval = setInterval(() => {
      if (this.isPaused || !this.continuousDriveDirection) return;

      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      const baseSpeedMmPerSec = 220;
      const currentSpeed = (this.speedPercent / 100) * baseSpeedMmPerSec;
      const stepDist = currentSpeed * dt * this.simulationSpeed;

      const rad = (this.pose.heading * Math.PI) / 180;
      const dx = Math.sin(rad) * stepDist * sign;
      const dy = Math.cos(rad) * stepDist * sign;

      const newX = this.pose.x + dx;
      const newY = this.pose.y + dy;

      if (this.checkWallCollision(newX, newY, 80)) {
        this.isColliding = true;
        soundEffects.playCollisionFeedback();
        this.stopRobot();
        return;
      }

      this.isColliding = false;
      this.pose.x = newX;
      this.pose.y = newY;

      if (this.penDown) {
        const lastPt = this.penTrails[this.penTrails.length - 1];
        if (!lastPt || Math.hypot(lastPt.x - newX, lastPt.y - newY) > 8) {
          this.penTrails.push({
            x: newX,
            y: newY,
            color: this.penColor,
            width: this.penWidth,
          });
          this.broadcastPen();
        }
      }

      this.updateSensors();
      this.broadcastTelemetry();
    }, 20);
  }

  public stopRobot() {
    this.continuousDriveDirection = null;
    if (this.continuousInterval) {
      clearInterval(this.continuousInterval);
      this.continuousInterval = null;
    }
    soundEffects.stopMotor();
    if (serialBridge.getConnected()) {
      serialBridge.sendCommand('STOP');
    }
  }

  public setPenDown(down: boolean) {
    if (this.penDown !== down) {
      soundEffects.playPenServo(down);
    }
    this.penDown = down;
    if (serialBridge.getConnected()) {
      serialBridge.sendCommand(down ? 'PEN_DOWN' : 'PEN_UP');
    }
    if (down) {
      // Add initial point for new segment
      this.penTrails.push({
        x: this.pose.x,
        y: this.pose.y,
        color: this.penColor,
        width: this.penWidth,
        isNewSegment: true,
      });
      this.broadcastPen();
    }
    this.broadcastTelemetry();
  }

  public setPenColor(color: string) {
    this.penColor = color;
    if (this.penDown) {
      this.penTrails.push({
        x: this.pose.x,
        y: this.pose.y,
        color: this.penColor,
        width: this.penWidth,
        isNewSegment: true,
      });
      this.broadcastPen();
    }
    this.broadcastTelemetry();
  }

  public clearPenTrails() {
    this.penTrails = [];
    this.broadcastPen();
  }

  public getDistanceCm(): number {
    return Math.round(this.distanceMm / 10);
  }

  public getHeadingDegrees(): number {
    let h = Math.round(this.pose.heading) % 360;
    if (h < 0) h += 360;
    return h;
  }

  public getDetectedColor(): string {
    return this.detectedColor;
  }

  public async sleep(seconds: number): Promise<void> {
    const totalMs = (seconds * 1000) / this.simulationSpeed;
    const stepMs = 20;
    let elapsed = 0;
    while (elapsed < totalMs) {
      await this.checkYield();
      await new Promise((r) => setTimeout(r, stepMs));
      elapsed += stepMs;
    }
  }

  // --- Physics & Kinematics Steps ---

  private async driveLinear(distanceMm: number, sign: number): Promise<void> {
    const baseSpeedMmPerSec = 220; // 220 mm/s at 100%
    const currentSpeed = (this.speedPercent / 100) * baseSpeedMmPerSec;
    let remaining = Math.abs(distanceMm);

    let lastTime = performance.now();
    soundEffects.startMotor(this.speedPercent, this.simulationSpeed);

    try {
      while (remaining > 0.5) {
        await this.checkYield();

        const now = performance.now();
        const dt = Math.min((now - lastTime) / 1000, 0.05); // cap delta
        lastTime = now;

        const stepDist = Math.min(remaining, currentSpeed * dt * this.simulationSpeed);
        if (stepDist <= 0) {
          await new Promise((r) => setTimeout(r, 16));
          continue;
        }

        // Calculate move vector based on current heading
        // 0 deg = North (+Y in 2D math, -Z in Three.js)
        // 90 deg = East (+X in 2D math, +X in Three.js)
        const rad = (this.pose.heading * Math.PI) / 180;
        const dx = Math.sin(rad) * stepDist * sign;
        const dy = Math.cos(rad) * stepDist * sign;

        const newX = this.pose.x + dx;
        const newY = this.pose.y + dy;

        // Check collision with walls / arena boundaries
        const collision = this.checkWallCollision(newX, newY, 80); // robot radius ~80mm
        if (collision) {
          this.isColliding = true;
          soundEffects.playCollisionFeedback();
          this.updateSensors();
          this.broadcastTelemetry();
          // Stop forward motion on impact
          break;
        } else {
          this.isColliding = false;
        }

        this.pose.x = newX;
        this.pose.y = newY;
        remaining -= stepDist;

        // If pen is down, record trail
        if (this.penDown) {
          const lastPt = this.penTrails[this.penTrails.length - 1];
          if (!lastPt || Math.hypot(lastPt.x - newX, lastPt.y - newY) > 8) {
            this.penTrails.push({
              x: newX,
              y: newY,
              color: this.penColor,
              width: this.penWidth,
            });
            this.broadcastPen();
          }
        }

        this.updateSensors();
        this.broadcastTelemetry();

        await new Promise((r) => setTimeout(r, 16));
      }
    } finally {
      if (!this.continuousDriveDirection) {
        soundEffects.stopMotor();
      }
    }
  }

  private async turnAngular(degrees: number): Promise<void> {
    const baseRotDegPerSec = 140; // 140 deg/s at 100%
    const currentRotSpeed = (this.speedPercent / 100) * baseRotDegPerSec;
    const sign = degrees >= 0 ? 1 : -1;
    let remaining = Math.abs(degrees);

    let lastTime = performance.now();
    soundEffects.startMotor(this.speedPercent, this.simulationSpeed);

    try {
      while (remaining > 0.2) {
        await this.checkYield();

        const now = performance.now();
        const dt = Math.min((now - lastTime) / 1000, 0.05);
        lastTime = now;

        const stepAngle = Math.min(remaining, currentRotSpeed * dt * this.simulationSpeed);
        if (stepAngle <= 0) {
          await new Promise((r) => setTimeout(r, 16));
          continue;
        }

        this.pose.heading = (this.pose.heading + stepAngle * sign) % 360;
        if (this.pose.heading < 0) this.pose.heading += 360;
        remaining -= stepAngle;

        this.updateSensors();
        this.broadcastTelemetry();

        await new Promise((r) => setTimeout(r, 16));
      }
    } finally {
      if (!this.continuousDriveDirection) {
        soundEffects.stopMotor();
      }
    }
  }

  private checkWallCollision(px: number, py: number, radius: number): boolean {
    const halfW = this.arena.widthMm / 2 - radius;
    const halfD = this.arena.depthMm / 2 - radius;

    // Check boundary walls
    if (px < -halfW || px > halfW || py < -halfD || py > halfD) {
      return true;
    }

    // Check interior walls
    for (const wall of this.arena.walls) {
      const hw = wall.width / 2;
      const hd = wall.depth / 2;
      // Closest point on box
      const closestX = Math.max(wall.x - hw, Math.min(px, wall.x + hw));
      const closestY = Math.max(wall.y - hd, Math.min(py, wall.y + hd));
      const dist = Math.hypot(px - closestX, py - closestY);
      if (dist < radius) {
        return true;
      }
    }

    return false;
  }

  private updateSensors() {
    // 1. Ultrasonic Distance Raycast forward
    const rad = (this.pose.heading * Math.PI) / 180;
    const dirX = Math.sin(rad);
    const dirY = Math.cos(rad);

    let minDistance = 2500; // max sensing range 2.5 meters (2500mm)

    // Raycast vs Arena boundary box
    const halfW = this.arena.widthMm / 2;
    const halfD = this.arena.depthMm / 2;

    if (dirX > 0) {
      const dist = (halfW - this.pose.x) / dirX;
      if (dist > 0 && dist < minDistance) minDistance = dist;
    } else if (dirX < 0) {
      const dist = (-halfW - this.pose.x) / dirX;
      if (dist > 0 && dist < minDistance) minDistance = dist;
    }

    if (dirY > 0) {
      const dist = (halfD - this.pose.y) / dirY;
      if (dist > 0 && dist < minDistance) minDistance = dist;
    } else if (dirY < 0) {
      const dist = (-halfD - this.pose.y) / dirY;
      if (dist > 0 && dist < minDistance) minDistance = dist;
    }

    // Raycast vs Interior Walls (AABB Ray intersection)
    for (const wall of this.arena.walls) {
      const minX = wall.x - wall.width / 2;
      const maxX = wall.x + wall.width / 2;
      const minY = wall.y - wall.depth / 2;
      const maxY = wall.y + wall.depth / 2;

      let tmin = -Infinity;
      let tmax = Infinity;

      if (dirX !== 0) {
        const tx1 = (minX - this.pose.x) / dirX;
        const tx2 = (maxX - this.pose.x) / dirX;
        tmin = Math.max(tmin, Math.min(tx1, tx2));
        tmax = Math.min(tmax, Math.max(tx1, tx2));
      }

      if (dirY !== 0) {
        const ty1 = (minY - this.pose.y) / dirY;
        const ty2 = (maxY - this.pose.y) / dirY;
        tmin = Math.max(tmin, Math.min(ty1, ty2));
        tmax = Math.min(tmax, Math.max(ty1, ty2));
      }

      if (tmax >= tmin && tmin > 0 && tmin < minDistance) {
        minDistance = tmin;
      }
    }

    // Subtract sensor offset from robot center (~60mm)
    this.distanceMm = Math.max(0, minDistance - 60);

    // 2. Optical Eye/Color sensor downward (at robot center or front eye)
    let detected = 'white';
    let hex = '#f8fafc';

    for (const zone of this.arena.colorZones) {
      if (zone.radius) {
        const dist = Math.hypot(this.pose.x - zone.x, this.pose.y - zone.y);
        if (dist <= zone.radius) {
          detected = zone.colorName;
          hex = zone.hex;
          break;
        }
      } else if (zone.width && zone.depth) {
        const hw = zone.width / 2;
        const hd = zone.depth / 2;
        if (
          this.pose.x >= zone.x - hw &&
          this.pose.x <= zone.x + hw &&
          this.pose.y >= zone.y - hd &&
          this.pose.y <= zone.y + hd
        ) {
          detected = zone.colorName;
          hex = zone.hex;
          break;
        }
      }
    }

    // Ultrasonic sonar audio trigger when obstacle is near during motion
    if (this.distanceMm < 350 && (this.isRunning || this.continuousDriveDirection)) {
      soundEffects.playSonarPing(this.distanceMm / 10);
    }

    // Color sensor chime when entering a distinct colored zone
    if (detected !== 'white' && detected !== this.lastChimedColor) {
      soundEffects.playColorChime(detected);
      this.lastChimedColor = detected;
    } else if (detected === 'white') {
      this.lastChimedColor = 'white';
    }

    this.detectedColor = detected;
    this.colorHex = hex;
  }

  // --- High-level Async Script Runner ---

  public async executeScript(code: string): Promise<void> {
    if (this.isRunning) {
      this.stop();
      await new Promise((r) => setTimeout(r, 50));
    }

    this.isRunning = true;
    this.isPaused = false;
    this.isCancelled = false;
    soundEffects.playRobotBoot();
    if (this.onStateChange) this.onStateChange('running');

    // Create the scoped API object
    const robot = {
      // Drivetrain
      moveForward: (dist: number) => this.moveForward(dist),
      moveBackward: (dist: number) => this.moveBackward(dist),
      turnAngle: (deg: number) => this.turnAngle(deg),
      turnRight: (deg: number) => this.turnAngle(deg),
      turnLeft: (deg: number) => this.turnAngle(-deg),
      setSpeed: (speed: number) => this.setSpeed(speed),
      startDriving: (dir: 'forward' | 'backward') => this.startDriving(dir),
      stop: () => this.stopRobot(),

      // Pen
      setPenDown: (down: boolean) => this.setPenDown(down),
      penDown: () => this.setPenDown(true),
      penUp: () => this.setPenDown(false),
      setPenColor: (color: string) => this.setPenColor(color),
      clearPenTrails: () => this.clearPenTrails(),
      clearPen: () => this.clearPenTrails(),

      // Sensors
      getDistanceCm: () => this.getDistanceCm(),
      getDistance: () => this.getDistanceCm(),
      getHeadingDegrees: () => this.getHeadingDegrees(),
      getHeading: () => this.getHeadingDegrees(),
      getDetectedColor: () => this.getDetectedColor(),
      getColor: () => this.getDetectedColor(),

      // Time & yield
      sleep: (sec: number) => this.sleep(sec),
      wait: (sec: number) => this.sleep(sec),
    };

    try {
      // Wrap code in async runner function
      const asyncFunction = new Function('robot', `return (async () => {\n${code}\n})();`);
      await asyncFunction(robot);

      if (this.isRunning && !this.isCancelled) {
        this.isRunning = false;
        soundEffects.stopMotor();
        soundEffects.playMissionSuccess();
        soundEffects.playSuccessChime();
        if (this.onStateChange) this.onStateChange('completed');
      }
    } catch (err: any) {
      soundEffects.stopMotor();
      if (err?.message === 'EXECUTION_HALTED' || this.isCancelled) {
        this.isRunning = false;
        if (this.onStateChange) this.onStateChange('stopped');
      } else {
        this.isRunning = false;
        console.error('Robot Script Execution Error:', err);
        if (this.onStateChange) {
          this.onStateChange('error', err?.message || 'Terjadi kesalahan eksekusi kode');
        }
      }
    }
  }
}
