import { Mission } from '../../types/robot';

export const SAMPLE_MISSIONS: Mission[] = [
  {
    id: 'square_art',
    title: 'Misi 1: Menggambar Persegi Presisi',
    badge: 'Pemula (Beginner)',
    description: 'Turunkan pena (Pen Down), atur warna merah, dan gerakkan robot membentuk persegi sempurna dengan sisi 50 cm.',
    arena: 'art',
    goalExplanation: 'Pelajari konsep perulangan (loop) 4 kali: Maju 500 mm (50 cm), lalu belok kanan 90 derajat.',
    starterCodePython: `# Misi 1: Menggambar Persegi
robot.set_speed(80)
robot.set_pen_color("red")
robot.pen_down()

for i in range(4):
    robot.move_forward(50, "cm")
    robot.turn_right(90)

robot.pen_up()
`,
    solutionHint: 'Gunakan blok "ulangi 4 kali" -> Maju 500 mm -> Belok Kanan 90 derajat -> Selesai.',
  },
  {
    id: 'maze_escape',
    title: 'Misi 2: Navigasi Labirin & Sensor Jarak',
    badge: 'Menengah (Sensors)',
    description: 'Gunakan sensor jarak ultrasonik di depan robot untuk mendeteksi dinding labirin dan berbelok secara otomatis sebelum menabrak.',
    arena: 'maze',
    goalExplanation: 'Robot harus maju terus jika jarak ke dinding depan > 250 mm. Jika mendeteksi dinding (<= 250 mm), robot belok kanan 90 derajat.',
    starterCodePython: `# Misi 2: Penjelajah Labirin Otomatis
robot.set_speed(60)

for step in range(12):
    # Cek sensor jarak
    if robot.get_distance() < 25:
        robot.turn_right(90)
    else:
        robot.move_forward(20, "cm")
`,
    solutionHint: 'Gunakan blok "jika sensor_jarak < 25 cm, belok kanan 90, jika tidak maju 20 cm".',
  },
  {
    id: 'color_zone_hunt',
    title: 'Misi 3: Detektor Zona Warna (Eye Sensor)',
    badge: 'Sensor Optik',
    description: 'Manfaatkan sensor warna bawah robot untuk menjelajahi arena dan berhenti tepat ketika mendeteksi zona target.',
    arena: 'color_track',
    goalExplanation: 'Robot bergerak maju menyusuri arena. Nyalakan pena hijau saat berada di luar, dan berhenti ketika sensor melihat warna "blue" atau "red".',
    starterCodePython: `# Misi 3: Deteksi Warna Bawah
robot.set_speed(50)
robot.set_pen_color("green")
robot.pen_down()

while True:
    color = robot.get_color()
    if color == "blue" or color == "red":
        robot.stop()
        break
    robot.move_forward(10, "cm")
`,
    solutionHint: 'Gunakan blok "ulangi sampai sensor_warna mendeteksi warna Biru".',
  },
  {
    id: 'flower_spiral',
    title: 'Misi 4: Pola Geometri Fraktal / Bintang',
    badge: 'Kreatif STEM',
    description: 'Buat karya seni robotika yang indah menggunakan matematika derajat sudut dan perulangan multi-warna.',
    arena: 'art',
    goalExplanation: 'Eksperimen dengan sudut 144 derajat (Bintang 5 sudut) atau pola spirograf 8 kelopak bunga.',
    starterCodePython: `# Misi 4: Pola Bintang Seni
robot.set_speed(90)
robot.set_pen_color("blue")
robot.pen_down()

# Menggambar Bintang 5 Sudut
for i in range(5):
    robot.move_forward(60, "cm")
    robot.turn_right(144)

robot.pen_up()
`,
    solutionHint: 'Sudut belok 144 derajat pada 5 langkah maju akan membentuk bintang emas 5 sudut!',
  },
  {
    id: 'mars_survey',
    title: 'Misi 5: Eksplorasi Luar Angkasa Mars Rover',
    badge: 'Luar Angkasa (Prosedur)',
    description: 'Jelajahi medan bebatuan planet Mars. Gunakan logika multi-kondisi dan fungsi modular untuk mendeteksi mineral langka tanpa menabrak batu kawah.',
    arena: 'mars_rover',
    goalExplanation: 'Maju menjelajah planet Mars. Jika sensor jarak mendeteksi batu (< 30 cm), robot berbelok secara acak atau 60 derajat untuk melanjutkan survei geologi.',
    starterCodePython: `# Misi 5: Penjelajah Planet Mars
robot.set_speed(70)
robot.set_pen_color("yellow")
robot.pen_down()

# Algoritma survei rover mandiri
for step in range(16):
    jarak = robot.get_distance()
    warna = robot.get_color()
    
    # Cek rintangan batu Mars
    if jarak < 30:
        robot.turn_right(75)
    elif warna == "yellow" or warna == "blue":
        # Temuan mineral deposit!
        robot.sleep(0.5)
        robot.turn_left(45)
    else:
        robot.move_forward(25, "cm")

robot.pen_up()
robot.stop()
`,
    solutionHint: 'Gunakan fungsi atau blok "jika jarak < 30 cm -> belok kanan 75 derajat, jika melihat deposit mineral -> berhenti sejenak".',
  },
  {
    id: 'sumo_combat',
    title: 'Misi 6: Ring Pertempuran Robot Sumo (Dohyo)',
    badge: 'Kompetisi WRO / Sumo',
    description: 'Bertahan di dalam ring dohyo! Gunakan sensor garis bawah untuk mendeteksi batas putih (Tawara) dan mundur berbalik sebelum terjatuh.',
    arena: 'sumo_arena',
    goalExplanation: 'Cari lawan robot dummy di depan. Jika sensor optik melihat garis putih atau trap tepi, segera mundur dan berputar 180 derajat!',
    starterCodePython: `# Misi 6: Robot Sumo Taktis
robot.set_speed(85)

for putaran in range(20):
    warna_lantai = robot.get_color()
    jarak_lawan = robot.get_distance()
    
    # Prioritas 1: Jika menyentuh garis putih batas ring, mundur!
    if warna_lantai == "white":
        robot.move_backward(20, "cm")
        robot.turn_right(120)
    # Prioritas 2: Jika mendeteksi robot lawan di depan, seruduk maju!
    elif jarak_lawan < 40:
        robot.set_speed(100)
        robot.move_forward(30, "cm")
    else:
        robot.set_speed(65)
        robot.move_forward(15, "cm")

robot.stop()
`,
    solutionHint: 'Prioritas tertinggi dalam robot sumo adalah bertahan: Cek garis putih -> jika ya, mundur & putar balik. Jika aman -> dorong lawan!',
  },
];

