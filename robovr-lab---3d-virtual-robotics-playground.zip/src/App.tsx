import React, { useState, useRef, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  ArenaType,
  CameraViewMode,
  DEFAULT_ROBOT_CUSTOMIZATION,
  ExecutionState,
  Mission,
  PenTrailPoint,
  RobotCustomizationConfig,
  RobotTelemetry,
  SimulationSpeed,
} from './types/robot';
import { ARENAS } from './services/arenas/arenaData';
import { SAMPLE_MISSIONS } from './services/missions/sampleMissions';
import { RobotSimulationEngine } from './services/interpreter/asyncInterpreter';
import { transpilePythonToAsyncJS } from './services/interpreter/pythonRunner';
import { HeaderNavbar } from './components/navbar/HeaderNavbar';
import { SplitPane } from './components/editor/SplitPane';
import { BlocklyEditor, BlocklyEditorHandle } from './components/editor/BlocklyEditor';
import { PythonEditor } from './components/editor/PythonEditor';
import { ThreePlayground } from './components/playground/ThreePlayground';
import { RobotHUD } from './components/playground/RobotHUD';
import { TouchRemoteControl } from './components/playground/TouchRemoteControl';
import { MissionsModal } from './components/modals/MissionsModal';
import { HelpModal } from './components/modals/HelpModal';
import { ArduinoModal } from './components/modals/ArduinoModal';
import { RobotCustomizerModal } from './components/modals/RobotCustomizerModal';
import { RoboAdventureModal } from './components/modals/RoboAdventureModal';
import { ProjectStorageModal } from './components/modals/ProjectStorageModal';
import { ThemeSelectorModal } from './components/modals/ThemeSelectorModal';
import { StoryChapter } from './services/story/storyData';
import { RoboVRProjectFile } from './services/storage/projectFileManager';
import { AppThemeId, APP_THEMES } from './types/theme';
import { serialBridge } from './services/arduino/webSerialBridge';
import { soundEffects } from './services/audio/soundEffects';
import { AlertCircle, CheckCircle2, Trophy, Lightbulb, X, Sparkles } from 'lucide-react';

export default function App() {
  const [currentArenaId, setCurrentArenaId] = useState<ArenaType>('grid');
  const [activeLanguage, setActiveLanguage] = useState<'block' | 'python'>('block');
  const [speed, setSpeed] = useState<SimulationSpeed>(1);
  const [viewMode, setViewMode] = useState<CameraViewMode>('orbit');
  const [executionState, setExecutionState] = useState<ExecutionState>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active mission & modals
  const [currentMission, setCurrentMission] = useState<Mission | null>(SAMPLE_MISSIONS[0]);
  const [isMissionsOpen, setIsMissionsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isArduinoOpen, setIsArduinoOpen] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [isAdventureOpen, setIsAdventureOpen] = useState(false);
  const [isProjectStorageOpen, setIsProjectStorageOpen] = useState(false);
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<AppThemeId>(() => {
    try {
      const saved = localStorage.getItem('robovr_app_theme');
      if (saved && saved in APP_THEMES) return saved as AppThemeId;
    } catch {}
    return 'cyber'; // Cosmic Cyber Dark Theme as default
  });
  const [projectToast, setProjectToast] = useState<string | null>(null);
  const [isSerialConnected, setIsSerialConnected] = useState(false);
  const [showHint, setShowHint] = useState(false);

  // Ref to Blockly editor
  const blocklyEditorRef = useRef<BlocklyEditorHandle | null>(null);

  // Robot character customization (loaded from localStorage)
  const [robotCustomization, setRobotCustomization] = useState<RobotCustomizationConfig>(() => {
    try {
      const saved = localStorage.getItem('robovr_customization');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_ROBOT_CUSTOMIZATION;
  });


  // Setup serial listener
  useEffect(() => {
    serialBridge.setCallbacks((connected) => {
      setIsSerialConnected(connected);
    });
  }, []);

  const handleConnectSerial = async () => {
    try {
      await serialBridge.connect(115200);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Gagal menghubungkan port USB Arduino');
    }
  };

  const handleDisconnectSerial = async () => {
    await serialBridge.disconnect();
  };

  // Code buffers
  const [blocklyJsCode, setBlocklyJsCode] = useState<string>('');
  const [pythonCode, setPythonCode] = useState<string>(SAMPLE_MISSIONS[0].starterCodePython);

  // Simulation Engine instance
  const arena = ARENAS[currentArenaId];
  const engineRef = useRef<RobotSimulationEngine | null>(null);

  // Telemetry & Pen state
  const [telemetry, setTelemetry] = useState<RobotTelemetry>(() => ({
    pose: { ...arena.startPose },
    speedPercent: 75,
    distanceMm: 1000,
    detectedColor: 'white',
    colorHex: '#ffffff',
    penDown: false,
    penColor: 'red',
    penWidth: 3,
    isColliding: false,
    leftMotorSpeed: 75,
    rightMotorSpeed: 75,
  }));

  const [penTrails, setPenTrails] = useState<PenTrailPoint[]>([]);

  // Initialize engine once
  useEffect(() => {
    const engine = new RobotSimulationEngine(arena);
    engine.setCallbacks(
      (telem) => setTelemetry(telem),
      (trails) => setPenTrails(trails),
      (state, err) => {
        setExecutionState(state);
        if (state === 'completed') {
          // Trigger celebratory confetti
          confetti({
            particleCount: 80,
            spread: 60,
            origin: { y: 0.6 },
          });
        }
        if (state === 'error' && err) {
          setErrorMessage(err);
        } else {
          setErrorMessage(null);
        }
      }
    );
    engineRef.current = engine;

    return () => {
      engine.stop();
    };
  }, []);

  // Update arena in engine when arena changes
  const handleArenaChange = (newArenaId: ArenaType) => {
    setCurrentArenaId(newArenaId);
    if (engineRef.current) {
      engineRef.current.setArena(ARENAS[newArenaId]);
    }
  };

  // Speed multiplier update
  const handleSpeedChange = (newSpeed: SimulationSpeed) => {
    setSpeed(newSpeed);
    if (engineRef.current) {
      engineRef.current.setSpeedMultiplier(newSpeed);
    }
  };

  // Execution actions
  const handleRun = async () => {
    if (!engineRef.current) return;
    setErrorMessage(null);

    let scriptToRun = '';
    if (activeLanguage === 'block') {
      scriptToRun = blocklyJsCode;
    } else {
      // Transpile Python to Async JS
      try {
        scriptToRun = transpilePythonToAsyncJS(pythonCode);
      } catch (err: any) {
        setExecutionState('error');
        setErrorMessage('Gagal memproses kode Python: ' + (err?.message || 'Syntax error'));
        return;
      }
    }

    await engineRef.current.executeScript(scriptToRun);
  };

  const handlePause = () => {
    soundEffects.playUiClick();
    soundEffects.stopMotor();
    if (engineRef.current) engineRef.current.pause();
  };

  const handleResume = () => {
    soundEffects.playUiClick();
    if (engineRef.current) engineRef.current.resume();
  };

  const handleStop = () => {
    soundEffects.playUiClick();
    if (engineRef.current) engineRef.current.stop();
  };

  const handleReset = () => {
    soundEffects.playUiClick();
    if (engineRef.current) engineRef.current.resetPose();
    setExecutionState('idle');
    setErrorMessage(null);
  };

  const handleClearPen = () => {
    soundEffects.playReset();
    if (engineRef.current) engineRef.current.clearPenTrails();
  };

  // Code generation callback from Blockly
  const handleBlocklyCodeChange = useCallback((js: string, py: string) => {
    setBlocklyJsCode(js);
    // If not actively editing python directly, keep python view synced
    setPythonCode((prev) => (activeLanguage === 'block' ? py : prev));
  }, [activeLanguage]);

  // Mission selection handler
  const handleSelectMission = (mission: Mission) => {
    soundEffects.playUiClick();
    setCurrentMission(mission);
    handleArenaChange(mission.arena);
    setPythonCode(mission.starterCodePython);
    handleReset();
    setShowHint(false);
  };

  const handleLoadChapterCode = (chapter: StoryChapter) => {
    handleArenaChange(chapter.arenaId);
    setActiveLanguage('block');
    setTimeout(() => {
      blocklyEditorRef.current?.loadWorkspaceJson(chapter.starterBlocksJson);
    }, 150);
    setIsAdventureOpen(false);
    setProjectToast(`Bab ${chapter.chapterNumber}: "${chapter.title}" berhasil dipasang ke kanvas! Tekan Jalankan untuk melihat aksi Robo.`);
    setTimeout(() => {
      setProjectToast(null);
    }, 6000);
  };

  const handleLoadProject = (project: RoboVRProjectFile) => {
    if (project.arenaId && ARENAS[project.arenaId]) {
      handleArenaChange(project.arenaId);
    }
    if (project.robotCustomization) {
      setRobotCustomization(project.robotCustomization);
      try {
        localStorage.setItem('robovr_customization', JSON.stringify(project.robotCustomization));
      } catch {}
    }
    if (project.activeLanguage) {
      setActiveLanguage(project.activeLanguage);
    }
    if (project.pythonCode) {
      setPythonCode(project.pythonCode);
    }
    if (project.blocklyState) {
      setTimeout(() => {
        blocklyEditorRef.current?.loadWorkspaceJson(project.blocklyState);
      }, 150);
    }
    setProjectToast(`Proyek "${project.name}" berhasil dimuat dari komputer!`);
    setTimeout(() => {
      setProjectToast(null);
    }, 5000);
  };

  // Mobile responsive layout mode: 'split' | 'code' | '3d'
  const [mobilePane, setMobilePane] = useState<'split' | 'code' | '3d'>('split');

  // Offline detection per PWA skill guidelines
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div className="flex flex-col w-screen h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Offline Toast Banner */}
      {!isOnline && (
        <div className="bg-amber-600 text-white text-xs px-3 py-1 flex items-center justify-center gap-2 font-medium z-50">
          <span className="w-2 h-2 rounded-full bg-white animate-ping" />
          <span>Mode Offline — Aplikasi RoboVR Lab tetap dapat digunakan secara lokal tanpa internet.</span>
        </div>
      )}

      {/* Top Navigation Bar */}
      <HeaderNavbar
        executionState={executionState}
        onRun={handleRun}
        onPause={handlePause}
        onResume={handleResume}
        onStop={handleStop}
        onReset={handleReset}
        speed={speed}
        onSpeedChange={handleSpeedChange}
        currentArena={currentArenaId}
        onArenaChange={handleArenaChange}
        activeLanguage={activeLanguage}
        onLanguageChange={setActiveLanguage}
        selectedMissionId={currentMission?.id}
        onSelectMission={(id) => {
          const m = SAMPLE_MISSIONS.find((x) => x.id === id);
          if (m) handleSelectMission(m);
        }}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenMissions={() => setIsMissionsOpen(true)}
        onOpenArduino={() => setIsArduinoOpen(true)}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        onOpenAdventure={() => setIsAdventureOpen(true)}
        onOpenProjectStorage={() => setIsProjectStorageOpen(true)}
        currentTheme={currentTheme}
        onOpenThemeSelector={() => setIsThemeOpen(true)}
        isSerialConnected={isSerialConnected}
        mobilePane={mobilePane}
        onMobilePaneChange={setMobilePane}
      />

      {/* Mission Banner Notification (Dismissible) */}
      {currentMission && (
        <div className="bg-gradient-to-r from-blue-950/80 via-slate-900 to-indigo-950/80 border-b border-slate-800 px-4 py-1.5 flex flex-wrap items-center justify-between text-xs select-none">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-amber-500/20 text-amber-400">
              <Trophy className="w-3.5 h-3.5" />
            </span>
            <span className="font-bold text-white">{currentMission.title}:</span>
            <span className="text-slate-300 hidden sm:inline">{currentMission.goalExplanation}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowHint(!showHint)}
              className="flex items-center gap-1 text-[11px] text-amber-300 hover:text-amber-200 cursor-pointer font-medium"
            >
              <Lightbulb className="w-3.5 h-3.5" />
              <span>{showHint ? 'Tutup Petunjuk' : 'Petunjuk Solusi'}</span>
            </button>
            <button
              onClick={() => setCurrentMission(null)}
              className="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer"
              title="Tutup banner"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Mission Hint Drawer */}
      {showHint && currentMission && (
        <div className="bg-amber-950/40 border-b border-amber-500/30 px-4 py-2 text-xs text-amber-200 flex items-center justify-between animate-in slide-in-from-top-2 duration-150">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Petunjuk Algoritma:</strong> {currentMission.solutionHint}
            </span>
          </div>
          <button
            onClick={() => setShowHint(false)}
            className="text-amber-400 hover:text-amber-200 font-bold px-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Execution Error Banner */}
      {errorMessage && (
        <div className="bg-rose-950/80 border-b border-rose-500/40 px-4 py-2 text-xs text-rose-200 flex items-center justify-between animate-in slide-in-from-top-1 duration-150">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>
              <strong>Peringatan Eksekusi:</strong> {errorMessage}
            </span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-rose-400 hover:text-rose-200 font-bold px-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Project Toast Banner */}
      {projectToast && (
        <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-950 border-b border-emerald-500/40 px-4 py-2 text-xs text-emerald-200 flex items-center justify-between animate-in slide-in-from-top-1 duration-150 z-40">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{projectToast}</span>
          </div>
          <button
            onClick={() => setProjectToast(null)}
            className="text-emerald-400 hover:text-emerald-200 font-bold px-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Split View: Left = Visual / Code Editor, Right = 3D Playground */}
      <SplitPane
        mobilePane={mobilePane}
        left={
          activeLanguage === 'block' ? (
            <BlocklyEditor
              ref={blocklyEditorRef}
              onCodeChange={handleBlocklyCodeChange}
              initialMissionId={currentMission?.id}
            />
          ) : (
            <PythonEditor
              code={pythonCode}
              onChange={setPythonCode}
              onSyncFromBlockly={() => {
                if (blocklyJsCode) {
                  setActiveLanguage('block');
                }
              }}
            />
          )
        }
        right={
          <div className="relative w-full h-full">
            {/* 3D WebGL Canvas */}
            <ThreePlayground
              arena={arena}
              telemetry={telemetry}
              penTrails={penTrails}
              executionState={executionState}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              customization={robotCustomization}
            />

            {/* Manual Touch Remote Control D-Pad (Touchscreen & Mobile friendly) */}
            <TouchRemoteControl
              engine={engineRef.current}
              telemetry={telemetry}
            />

            {/* Collapsible Telemetry HUD Overlay (Pinned to Bottom Center) */}
            <RobotHUD
              telemetry={telemetry}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              onClearTrails={handleClearPen}
            />
          </div>
        }
      />

      {/* Petualangan Robo Story & Illustrated SD Tutorial Modal */}
      <RoboAdventureModal
        isOpen={isAdventureOpen}
        onClose={() => setIsAdventureOpen(false)}
        onLoadChapterCode={handleLoadChapterCode}
        currentArenaId={currentArenaId}
      />

      {/* Project Storage Modal: Export & Import .robovr to local computer */}
      <ProjectStorageModal
        isOpen={isProjectStorageOpen}
        onClose={() => setIsProjectStorageOpen(false)}
        currentArenaId={currentArenaId}
        activeLanguage={activeLanguage}
        pythonCode={pythonCode}
        robotCustomization={robotCustomization}
        getWorkspaceJson={() => blocklyEditorRef.current?.getWorkspaceJson()}
        onLoadProject={handleLoadProject}
      />

      {/* STEM Missions Selection Modal */}
      <MissionsModal
        isOpen={isMissionsOpen}
        onClose={() => setIsMissionsOpen(false)}
        onSelectMission={handleSelectMission}
        currentMissionId={currentMission?.id}
      />

      {/* Help & API Reference Modal */}
      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />

      {/* Arduino & Driver Motor L298N / L293D Hardware Modal */}
      <ArduinoModal
        isOpen={isArduinoOpen}
        onClose={() => setIsArduinoOpen(false)}
        currentCode={activeLanguage === 'block' ? blocklyJsCode : pythonCode}
        isPython={activeLanguage === 'python'}
        isSerialConnected={isSerialConnected}
        onConnectSerial={handleConnectSerial}
        onDisconnectSerial={handleDisconnectSerial}
      />

      {/* 3D Robot Character Customizer Modal */}
      <RobotCustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        currentConfig={robotCustomization}
        onSaveConfig={setRobotCustomization}
      />

      {/* Fresh Kids Theme Selector Modal */}
      <ThemeSelectorModal
        isOpen={isThemeOpen}
        onClose={() => setIsThemeOpen(false)}
        currentTheme={currentTheme}
        onSelectTheme={(theme) => {
          setCurrentTheme(theme);
          try {
            localStorage.setItem('robovr_app_theme', theme);
          } catch {}
        }}
      />
    </div>
  );
}

