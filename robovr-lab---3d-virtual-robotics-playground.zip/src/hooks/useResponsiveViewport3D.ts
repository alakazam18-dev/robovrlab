import { useState, useEffect, RefObject } from 'react';

export interface Viewport3DConfig {
  fov: number;
  aspect: number;
  isPortrait: boolean;
  scaleMultiplier: number;
  cameraDistanceFactor: number;
  width: number;
  height: number;
}

/**
 * Hook to dynamically calculate Three.js perspective camera FOV,
 * aspect ratio, and object scale based on the container viewport dimensions.
 * Ensures the 3D robotics arena remains completely in view on both portrait
 * (mobile/vertical split) and landscape (desktop/tablet) screens.
 */
export function useResponsiveViewport3D(containerRef: RefObject<HTMLElement | null>): Viewport3DConfig {
  const [config, setConfig] = useState<Viewport3DConfig>({
    fov: 45,
    aspect: 16 / 9,
    isPortrait: false,
    scaleMultiplier: 1.0,
    cameraDistanceFactor: 1.0,
    width: 800,
    height: 450,
  });

  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;

    const updateDimensions = () => {
      const width = element.clientWidth || 800;
      const height = element.clientHeight || 450;
      const aspect = width / Math.max(height, 1);
      const isPortrait = aspect < 1.05;

      // Base FOV for standard landscape display (16:9 ~ 1.77 aspect ratio)
      const baseLandscapeFov = 45;
      const standardAspect = 1.6;

      let fov = baseLandscapeFov;
      let cameraDistanceFactor = 1.0;
      let scaleMultiplier = 1.0;

      if (isPortrait) {
        // In portrait mode, horizontal angle gets constrained.
        // We dynamically widen the vertical FOV so the full arena width is preserved.
        const baseHalfFovRad = ((baseLandscapeFov / 2) * Math.PI) / 180;
        const targetHalfHorizontalAngle = Math.tan(baseHalfFovRad) * standardAspect;
        
        // Invert tangent with current aspect ratio
        const dynamicVerticalHalfFovRad = Math.atan(targetHalfHorizontalAngle / Math.max(aspect, 0.45));
        const calculatedFov = (dynamicVerticalHalfFovRad * 2 * 180) / Math.PI;

        // Clamp between 45 and 75 degrees for natural perspective without distortion
        fov = Math.min(75, Math.max(45, Math.round(calculatedFov)));

        // On very narrow screens, pull camera back slightly and scale robot to fit
        cameraDistanceFactor = Math.min(1.35, 1.0 + (1.05 - aspect) * 0.4);
        scaleMultiplier = Math.max(0.9, Math.min(1.15, 1.0 + (1.0 - aspect) * 0.15));
      } else {
        // Landscape or square
        fov = baseLandscapeFov;
        cameraDistanceFactor = 1.0;
        scaleMultiplier = 1.0;
      }

      setConfig({
        fov,
        aspect,
        isPortrait,
        scaleMultiplier,
        cameraDistanceFactor,
        width,
        height,
      });
    };

    // Initial calculation
    updateDimensions();

    const resizeObserver = new ResizeObserver(() => {
      updateDimensions();
    });
    resizeObserver.observe(element);

    window.addEventListener('resize', updateDimensions);
    window.addEventListener('orientationchange', updateDimensions);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateDimensions);
      window.removeEventListener('orientationchange', updateDimensions);
    };
  }, [containerRef]);

  return config;
}
