export type AppThemeId = 'cyber' | 'fresh' | 'forest' | 'candy' | 'mars';

export interface AppThemeConfig {
  id: AppThemeId;
  name: string;
  badge: string;
  description: string;
  iconEmoji: string;
  colors: {
    primaryGradient: string;
    headerBg: string;
    headerBorder: string;
    accentPill: string;
    brandText: string;
    navBtnHover: string;
  };
}

export const APP_THEMES: Record<AppThemeId, AppThemeConfig> = {
  cyber: {
    id: 'cyber',
    name: 'Cosmic Cyber',
    badge: 'Futuristik',
    description: 'Nuansa keren robot masa depan penjelajah luar angkasa berteknologi tinggi.',
    iconEmoji: '🚀',
    colors: {
      primaryGradient: 'from-blue-600 to-cyan-500',
      headerBg: 'bg-slate-900',
      headerBorder: 'border-slate-800',
      accentPill: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      brandText: 'text-white',
      navBtnHover: 'hover:bg-slate-800',
    },
  },
  fresh: {
    id: 'fresh',
    name: 'Ceria Edukasi',
    badge: 'Segar & Semangat',
    description: 'Warna langit cerah dan sinar mentari kuning hangat yang membangkitkan rasa ingin tahu.',
    iconEmoji: '☀️',
    colors: {
      primaryGradient: 'from-sky-500 via-amber-400 to-emerald-400',
      headerBg: 'bg-sky-950',
      headerBorder: 'border-sky-800/80',
      accentPill: 'bg-amber-400/25 text-amber-200 border-amber-400/40',
      brandText: 'text-amber-100',
      navBtnHover: 'hover:bg-sky-900',
    },
  },
  forest: {
    id: 'forest',
    name: 'Petualang Rimba',
    badge: 'Eksplorasi Alam',
    description: 'Sensasi petualangan robot cilik melintasi hutan rimba hijau yang asri dan penuh misteri.',
    iconEmoji: '🌿',
    colors: {
      primaryGradient: 'from-emerald-500 via-teal-500 to-lime-400',
      headerBg: 'bg-emerald-950',
      headerBorder: 'border-emerald-800/70',
      accentPill: 'bg-emerald-400/20 text-emerald-200 border-emerald-400/40',
      brandText: 'text-emerald-50',
      navBtnHover: 'hover:bg-emerald-900',
    },
  },
  candy: {
    id: 'candy',
    name: 'Candy Pop & Berry',
    badge: 'Permen Manis',
    description: 'Paduan warna manis fuchsia, lavender, dan permen lolipop yang ceria dan seru.',
    iconEmoji: '🍭',
    colors: {
      primaryGradient: 'from-fuchsia-500 via-pink-500 to-violet-500',
      headerBg: 'bg-purple-950',
      headerBorder: 'border-purple-800/70',
      accentPill: 'bg-pink-500/25 text-pink-200 border-pink-400/40',
      brandText: 'text-pink-50',
      navBtnHover: 'hover:bg-purple-900',
    },
  },
  mars: {
    id: 'mars',
    name: 'Ekspedisi Mars',
    badge: 'Api Antariksa',
    description: 'Semangat petualang rover di gurun merah Planet Mars dengan bara kawah yang berani.',
    iconEmoji: '🔥',
    colors: {
      primaryGradient: 'from-orange-500 via-rose-500 to-amber-500',
      headerBg: 'bg-stone-950',
      headerBorder: 'border-orange-800/60',
      accentPill: 'bg-orange-500/25 text-orange-200 border-orange-500/40',
      brandText: 'text-orange-50',
      navBtnHover: 'hover:bg-stone-900',
    },
  },
};
