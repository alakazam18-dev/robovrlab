export type MotorDriverType = 'L298N' | 'L293D_SHIELD' | 'L293D_IC';

export interface ArduinoPinConfig {
  driverType: MotorDriverType;
  // Left Motor
  leftPwmPin: number; // ENA or PWM
  leftIn1Pin: number;
  leftIn2Pin: number;
  // Right Motor
  rightPwmPin: number; // ENB or PWM
  rightIn1Pin: number;
  rightIn2Pin: number;
  // Ultrasonic HC-SR04
  trigPin: number;
  echoPin: number;
  // Line / Eye Color Sensor
  sensorPin: number; // Analog or Digital
  // Pen Lifter Servo (SG90)
  servoPin: number;
  // Baud rate for Serial communication
  baudRate: 9600 | 115200;
}

export const DEFAULT_ARDUINO_CONFIG: ArduinoPinConfig = {
  driverType: 'L298N',
  leftPwmPin: 5,   // ENA (PWM)
  leftIn1Pin: 6,   // IN1
  leftIn2Pin: 7,   // IN2
  rightPwmPin: 10, // ENB (PWM)
  rightIn1Pin: 8,  // IN3
  rightIn2Pin: 9,  // IN4
  trigPin: 11,     // HC-SR04 Trig
  echoPin: 12,     // HC-SR04 Echo
  sensorPin: 14,   // A0 for line/floor optical sensor
  servoPin: 3,     // SG90 Servo for Pen lifter
  baudRate: 115200,
};

export const L293D_IC_CONFIG: ArduinoPinConfig = {
  driverType: 'L293D_IC',
  leftPwmPin: 3,   // Enable 1,2 (PWM)
  leftIn1Pin: 4,   // Input 1
  leftIn2Pin: 5,   // Input 2
  rightPwmPin: 6,  // Enable 3,4 (PWM)
  rightIn1Pin: 7,  // Input 3
  rightIn2Pin: 8,  // Input 4
  trigPin: 11,
  echoPin: 12,
  sensorPin: 14,
  servoPin: 9,
  baudRate: 115200,
};

export const L293D_SHIELD_CONFIG: ArduinoPinConfig = {
  driverType: 'L293D_SHIELD',
  leftPwmPin: 11, // AFMotor M1
  leftIn1Pin: 12,
  leftIn2Pin: 8,
  rightPwmPin: 3, // AFMotor M2
  rightIn1Pin: 4,
  rightIn2Pin: 7,
  trigPin: 14, // A0
  echoPin: 15, // A1
  sensorPin: 16, // A2
  servoPin: 10, // Servo 1 header on shield
  baudRate: 115200,
};
