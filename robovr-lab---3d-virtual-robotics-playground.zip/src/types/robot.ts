export type ArenaType = 'grid' | 'maze' | 'art' | 'color_track' | 'mars_rover' | 'sumo_arena';

export type CameraViewMode = 'orbit' | 'top' | 'chase';

export type SimulationSpeed = 1 | 2 | 5 | 10;

export type RobotBodyType = 'cyber' | 'scout' | 'tank';

export interface RobotCustomizationConfig {
  bodyType: RobotBodyType;
  chassisColor: string;
  topPlateColor: string;
  neonUnderglowColor: string; // hex or 'none'
  headlightsEnabled: boolean;
}

export const DEFAULT_ROBOT_CUSTOMIZATION: RobotCustomizationConfig = {
  bodyType: 'cyber',
  chassisColor: '#1e293b',
  topPlateColor: '#2563eb',
  neonUnderglowColor: '#00f5ff',
  headlightsEnabled: true,
};


export interface RobotPose {
  x: number; // in millimeters (centered at 0, 0 in arena)
  y: number; // in millimeters (Z in 3D scene)
  heading: number; // in degrees, 0 = north (+Y), 90 = east (+X), 180 = south, 270 = west
}

export interface RobotTelemetry {
  pose: RobotPose;
  speedPercent: number; // 1 to 100
  distanceMm: number; // Front distance sensor reading
  detectedColor: string; // 'red' | 'green' | 'blue' | 'yellow' | 'black' | 'white'
  colorHex: string;
  penDown: boolean;
  penColor: string;
  penWidth: number;
  isColliding: boolean;
  leftMotorSpeed: number;
  rightMotorSpeed: number;
}

export interface PenTrailPoint {
  x: number; // mm
  y: number; // mm
  color: string;
  width: number;
  isNewSegment?: boolean;
}

export interface WallObstacle {
  x: number; // mm center
  y: number; // mm center
  width: number; // mm in X
  depth: number; // mm in Y
  height: number; // mm in Z
  color?: string;
}

export interface ColorZone {
  x: number; // mm center
  y: number; // mm center
  radius?: number;
  width?: number;
  depth?: number;
  colorName: 'red' | 'green' | 'blue' | 'yellow' | 'black' | 'white';
  hex: string;
  label?: string;
}

export interface ArenaConfig {
  id: ArenaType;
  name: string;
  description: string;
  widthMm: number;
  depthMm: number;
  wallHeightMm: number;
  startPose: RobotPose;
  walls: WallObstacle[];
  colorZones: ColorZone[];
}

export type ExecutionState = 'idle' | 'running' | 'paused' | 'stopped' | 'completed' | 'error';

export interface Mission {
  id: string;
  title: string;
  badge: string;
  description: string;
  arena: ArenaType;
  goalExplanation: string;
  starterCodeBlockly?: string;
  starterCodePython: string;
  solutionHint: string;
}
