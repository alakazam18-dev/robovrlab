# Rencana Implementasi: Fitur Robotika Edukatif untuk Siswa Sekolah Dasar (SD)

Berdasarkan kebutuhan pembelajaran siswa SD dan kemudahan proses mengajar di kelas, kami akan menambahkan dua modul utama:
1. **Petualangan Robo: Tutorial Interaktif Bergambar & Cerita Petualangan** (Story-Driven Illustrated Learning for Elementary Kids).
2. **Fitur Simpan & Muat Proyek Lokal ke Komputer** (.robovr / .json) agar siswa dan guru dapat menyimpan pekerjaan, mengumpulkan tugas, serta membuka kembali proyek di sesi berikutnya.

---

## 1. Modul Petualangan Robo (Tutorial Cerita Bergambar Interaktif)

Modul ini dirancang khusus dengan gaya komik petualangan edukatif ramah anak yang memperkenalkan konsep logika komputasional (*computational thinking*) langkah demi langkah:

### Bab Cerita Petualangan:
- **Bab 1: Kebangkitan Si Robo**
  - *Misi*: Mengenal arah mata angin, mengatur kecepatan, dan menggerakkan robot maju/mundur serta belok.
  - *Konsep*: Sekuensial dasar (instruksi berurutan).
- **Bab 2: Kuas Ajaib & Seni Geometri**
  - *Misi*: Mengaktifkan pena robot dan melukis bangun datar (Persegi 4 sisi, Segitiga, Jejak Rumah).
  - *Konsep*: Pengulangan (*repeat loops*) dan koordinat sederhana.
- **Bab 3: Mata Kelelawar Ultrasonik**
  - *Misi*: Membantu Robo mendeteksi dinding di depannya sebelum menabrak.
  - *Konsep*: Logika kondisi (*if obstacle < 25 cm then stop/turn*).
- **Bab 4: Detektif Warna-Warni**
  - *Misi*: Menemukan karpet zona target merah, hijau, dan biru menggunakan sensor optik bawah.
  - *Konsep*: Percabangan warna (*conditional branching*).
- **Bab 5: Pengelana Labirin Mandiri**
  - *Misi*: Menggabungkan sensor ultrasonik dan gyro kompas agar Robo dapat keluar dari labirin secara otomatis.

### Fitur Interaktif pada Setiap Bab:
- Ilustrasi ramah anak dan dialog cerita petualangan.
- Tombol **"Coba Kode Petualangan Ini"** yang langsung memuat susunan blok Scratch ke kanvas dengan 1 klik sehingga anak dapat langsung melihat aksinya di arena 3D.
- Pertanyaan refleksi interaktif dan kartu tantangan kreatif (*Tantangan Siswa Kreatif*).

---

## 2. Fitur Simpan & Muat Proyek Lokal (.robovr / .json)

Memudahkan siswa dan guru di laboratorium komputer sekolah tanpa perlu koneksi internet atau akun rumit:

- **Simpan Proyek (*Save / Export*)**:
  - Menyimpan status blok Scratch (XML/JSON), kode Python, nama proyek, tanggal, konfigurasi arena, dan kustomisasi warna robot ke dalam satu file berkas `.robovr` atau `.json`.
  - Siswa dapat menamai file dengan nama mereka (misal: `Misi_Robo_Budi_Kelas4A.robovr`).
- **Muat Proyek (*Load / Import*)**:
  - Membuka file dari komputer siswa melalui dialog berkas ramah anak atau *drag-and-drop*.
  - Otomatis memvalidasi dan merestorasi seluruh susunan blok ke kanvas kerja secara instan.
  - Notifikasi suara dan visual yang menyenangkan saat proyek berhasil dimuat.

---

## 3. Integrasi Tombol Header & Antarmuka Kelas
- Menambahkan tombol **"Petualangan Robo"** (ikon Buku Petualangan / Bintang) di bilah navigasi atas dengan badge warna menarik.
- Menambahkan tombol cepat **"Simpan Proyek"** dan **"Buka Proyek"** di bilah menu atas dekat tombol jalankan program.

---

## Verifikasi & Pengujian
1. Pengujian simpan dan muat proyek antar sesi (memastikan blok Blockly, parameter kecepatan, dan posisi robot tersimpan tanpa data yang hilang).
2. Pengujian interaktivitas tombol "Coba Kode Ini" pada seluruh bab cerita agar langsung tampil dan dapat dijalankan di arena 3D.
3. Menjalankan `compile_applet` dan `lint_applet` untuk menjamin stabilitas aplikasi.
